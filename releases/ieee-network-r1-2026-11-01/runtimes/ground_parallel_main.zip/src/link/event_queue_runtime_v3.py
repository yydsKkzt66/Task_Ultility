"""Actual insertion/service owner with a shared causal, unitful event kernel.

No interval-average thermal capacity is used. Quotation owns detached state;
execution alone mutates DownlinkQueue bytes and the single thermal state.
The legacy macro executor cannot concurrently own this queue.
"""
from __future__ import annotations

from copy import deepcopy
from collections import OrderedDict
from bisect import bisect_right
from dataclasses import asdict, dataclass, replace
import hashlib
import json
import math
import pickle

from src.energy.battery_update import compute_battery_transition
from src.energy.celsius_thermal_network_v1 import NODES, POTHER, ThermalPowerV1
from src.link.net_utility_insertion_v2 import (
    IndependentQueueStageV2, QueueRemainingNetProjectionV2, best_legal_insertion_v2,
    NET_TOLERANCE_V2, best_net_trial_v2, queue_tie_key_v2)
from src.link.conditional_preemption_v1 import empty_service_context_v1


def identity(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, default=str,
        allow_nan=False, separators=(',', ':')).encode()).hexdigest()


def whole_service_bits_v3(start_s, end_s, rate_bit_s, demand_bits):
    """Invert the represented event clock without subtractive one-bit loss.

    A recorded end may be round(start + bits/rate). Subtracting start and
    flooring its product with rate can lose a whole bit. Check the forward
    endpoint instead; no completion-time tolerance or extra bytes are used.
    """
    if end_s <= start_s or rate_bit_s <= 0 or demand_bits <= 0:
        return 0
    bits=min(int(demand_bits),max(0,int(math.floor((end_s-start_s)*rate_bit_s))))
    while bits and start_s+bits/rate_bit_s > end_s:
        bits-=1
    while bits < demand_bits and start_s+(bits+1)/rate_bit_s <= end_s:
        bits+=1
    return bits


class _UnsafePriceContinuationV3(Exception):
    """A rejected fixed-schedule prefix cannot define a macro-end price."""

    def __init__(self, reason, certificate=None, segment=None):
        super().__init__(reason);self.certificate=certificate;self.segment=segment


def merge_service_slices_v3(rows):
    merged=[]
    for a,b,bits in rows:
        if merged and abs(merged[-1][1]-a)<=1e-7:
            start,_end,count=merged[-1];merged[-1]=(start,b,count+bits)
        else:merged.append((a,b,bits))
    return merged


def service_slices_equal_v3(left, right):
    """Same exact business bits at the existing 1e-7s service tolerance.

    Integer-bit event segmentation can leave sub-tolerance empty gaps. This
    changes only comparison canonicalization, never bytes, TX or billing.
    """
    left=merge_service_slices_v3(left);right=merge_service_slices_v3(right)
    return len(left)==len(right) and all(abs(a[0]-b[0])<=1e-7 and abs(a[1]-b[1])<=1e-7
        and a[2]==b[2] for a,b in zip(left,right))


@dataclass(frozen=True)
class EventLinkIntervalV3:
    start_s: float
    end_s: float
    business_rate_bit_s: float
    tx_dc_power_w: float
    solar_power_w: float
    absorbed_external_w: float
    window_id: str = ''
    window_capacity_bits: float = 0.
    scene_id: str = ''
    scene_dc_power_w: float = 0.
    scene_heat_power_w: float = 0.

    def __post_init__(self):
        vals = tuple(v for k,v in asdict(self).items() if k not in {'window_id','scene_id'})
        if not all(math.isfinite(v) and v >= 0 for v in vals) or self.end_s <= self.start_s:
            raise ValueError('INVALID_EVENT_LINK_UNITS')
        if self.business_rate_bit_s == 0 and self.tx_dc_power_w != 0:
            raise ValueError('NO_CONTACT_MUST_HAVE_ZERO_TX_POWER')
        if (self.scene_dc_power_w or self.scene_heat_power_w) and (
                not self.scene_id or self.scene_dc_power_w != 1100. or self.scene_heat_power_w != 1100.):
            raise ValueError('EXPLICIT_AUTHOR_SCENE_UPPER_HEAT_ENVELOPE_REQUIRED')


@dataclass(frozen=True)
class ComputeIntervalV3:
    event_id: str
    task_id: str
    kind: str
    start_s: float
    end_s: float
    incremental_power_w: float

    def __post_init__(self):
        if not self.event_id or not self.task_id or self.kind not in {'inference','encoding','cropping'}:
            raise ValueError('INVALID_COMPUTE_IDENTITY')
        if self.start_s < 0 or self.end_s <= self.start_s or not all(math.isfinite(v) for v in
                (self.start_s,self.end_s,self.incremental_power_w)) or self.incremental_power_w < 0:
            raise ValueError('INVALID_COMPUTE_INTERVAL')


class EventQueueKernelV3:
    def __init__(self, *, network, pricing, links, numerical_service_step_s=1.,preemption_contract=None):
        self.network, self.pricing, self.links = network, pricing, tuple(links)
        if not self.links or any(a.end_s != b.start_s for a,b in zip(self.links,self.links[1:])):
            raise ValueError('CONTIGUOUS_EXPLICIT_LINK_AND_ENVIRONMENT_REQUIRED')
        if numerical_service_step_s <= 0 or not math.isfinite(numerical_service_step_s):
            raise ValueError('INVALID_NUMERICAL_SERVICE_STEP')
        self.step_s = numerical_service_step_s
        self.preemption_contract=preemption_contract
        self.projection_cache_size=32
        self._projection_cache=OrderedDict()
        self.projection_cache_hits=0
        self.projection_calls=0
        self.projection_misses=0
        self._links_identity=identity([asdict(x) for x in self.links])
        self._links_object=self.links
        self._link_starts=tuple(x.start_s for x in self.links)

    def link_at(self, t):
        if self.links is not self._links_object:
            self._links_identity=identity([asdict(x) for x in self.links]);self._links_object=self.links
            self._link_starts=tuple(x.start_s for x in self.links)
        starts=getattr(self,'_link_starts',None)
        if starts is None:self._link_starts=starts=tuple(x.start_s for x in self.links)
        index=bisect_right(starts,t+1e-10)-1
        if index < 0 or not self.links[index].start_s-1e-10 <= t < self.links[index].end_s-1e-10:
            raise ValueError('UNKNOWN_LINK_OR_EXTERNAL_THERMAL_BOUNDARY')
        return self.links[index]

    def offered_bits_between(self, start, end):
        self.link_at(min(start,self.links[-1].end_s-1e-8))
        if getattr(self,'_capacity_links',None) is not self.links:
            prefix=[0.]
            for x in self.links:prefix.append(prefix[-1]+(x.end_s-x.start_s)*x.business_rate_bit_s)
            self._capacity_prefix=tuple(prefix);self._capacity_links=self.links
        def primitive(t):
            if t>=self.links[-1].end_s:return self._capacity_prefix[-1]
            i=max(0,bisect_right(self._link_starts,t)-1);x=self.links[i]
            return self._capacity_prefix[i]+max(0.,t-x.start_s)*x.business_rate_bit_s
        return max(0.,primitive(end)-primitive(start))

    def constant_environment_end(self, t):
        link=self.link_at(t)
        if getattr(self,'_constant_links',None) is not self.links:
            ends=[0.]*len(self.links);previous=None;until=None
            for i in reversed(range(len(self.links))):
                x=self.links[i]
                key=(x.business_rate_bit_s,x.tx_dc_power_w,x.solar_power_w,x.absorbed_external_w,
                     x.window_id,x.window_capacity_bits,x.scene_id,x.scene_dc_power_w,x.scene_heat_power_w)
                if key!=previous:until=x.end_s
                ends[i]=until;previous=key
            self._constant_ends=tuple(ends);self._constant_links=self.links
        return self._constant_ends[bisect_right(self._link_starts,t+1e-10)-1]

    def project(self, **kwargs):
        # Exact inputs only: no rounding, pressure bins, or cached policy
        # across differing states/dependencies/prices. Return detached data.
        self.projection_calls=getattr(self,'projection_calls',0)+1
        if self.links is not self._links_object:
            self._links_identity=identity([asdict(x) for x in self.links]);self._links_object=self.links
            self._link_starts=tuple(x.start_s for x in self.links)
        repricer=getattr(self.pricing,'reprice_fixed_schedule_bill',None)
        price_independent=repricer is not None or kwargs.get('bill') is False
        key=identity(dict(arguments=kwargs,network=asdict(self.network.p),
            heat_contract=asdict(self.pricing.h),kappa=self.pricing.kappa,refs=self.pricing.refs,
            beta=self.pricing.beta,lambda_enabled=None if price_independent else getattr(self.pricing,'lambda_enabled',True),
            candidate_price_identity=None if price_independent else getattr(self.pricing,'candidate_price_identity',None),
            pricing_type=type(self.pricing).__module__+'.'+type(self.pricing).__qualname__,
            gamma=self.pricing.gamma,battery_capacity_j=self.pricing.battery_capacity_j,
            charge_efficiency=self.pricing.charge_efficiency,discharge_efficiency=self.pricing.discharge_efficiency,
            links=self._links_identity,step_s=self.step_s,numerical_max_step_s=self.network.max_step_s,
            preemption=None if self.preemption_contract is None else asdict(self.preemption_contract)))
        if self.projection_cache_size and key in self._projection_cache:
            self.projection_cache_hits+=1
            self._projection_cache.move_to_end(key)
            cached=self._projection_cache[key]
            result=pickle.loads(cached) if isinstance(cached,bytes) else deepcopy(cached)
            if repricer is not None and kwargs.get('bill',True):
                # deepcopy preserves shared references between costs and flows.
                # Reprice each bill once and preserve every physical record.
                seen=set()
                for row in result['compute_bills']+result['flows']:
                    b=row.get('bill')
                    if b is not None and id(b) not in seen:
                        seen.add(id(b));b.update(repricer(b))
                self.price_basis_cache_hits=getattr(self,'price_basis_cache_hits',0)+1
            return result
        self.projection_misses=getattr(self,'projection_misses',0)+1
        result=self._project(**kwargs)
        if self.projection_cache_size:
            self._projection_cache[key]=(pickle.dumps(result,protocol=pickle.HIGHEST_PROTOCOL)
                if getattr(self,'projection_cache_codec','deepcopy')=='pickle' else deepcopy(result))
            while len(self._projection_cache)>self.projection_cache_size:self._projection_cache.popitem(last=False)
        return result

    @staticmethod
    def ai_after(ai_budget,solar_energy_j,compute_j):
        return ai_budget+(solar_energy_j*.05-compute_j)/100.

    def ai_prefix_admissible(self,*,now_s,ai_budget,work,end_s):
        """Historical interface retained; synthetic100J balance is diagnostic only."""
        return True

    def _project(self, *, thermal_state, soc, order, completed, work=(), end_s, ai_budget=.92,
                bill=True, window_transmitted_bits=None, reserved_slices=(), contingent_encodings=None,
                service_context=None,allow_preemption=True,stop_when_single_complete=False):
        """Both execution and forecasts call this method from identical state.

        Scan eligible entries in chosen order; a not-ready entry does not
        freeze service of already-ready entries. Reservations protect actual
        dated airtime, not a spread of bytes over an interval.
        """
        order = tuple(order)
        work = tuple(work)
        if stop_when_single_complete and (bill or len(order)!=1 or reserved_slices
                or contingent_encodings or service_context or self.preemption_contract is not None):
            raise ValueError('SINGLETON_PREFIX_REQUIRES_DETACHED_UNRESERVED_UNBILLED_FORECAST')
        contingent_encodings = dict(contingent_encodings or {})
        ready = {x.product_id:x.ready_time_s for x in order}
        # A soft plan is quoted causally, never materialized by a forecast.
        # Recompute encoding after its parent's ACK for each candidate order.
        for pid in contingent_encodings:ready[pid] = end_s + 1.
        scheduled_contingent = set()
        remaining = {x.product_id:float(x.remaining_bits) for x in order}
        initial_remaining=dict(remaining)
        context=deepcopy(service_context or empty_service_context_v1())
        suspended=set(context['suspended_products']);preemptions=[]
        starts = {x.product_id:max(thermal_state.time_s,x.ready_time_s) for x in order}
        finishes = {x.product_id:None for x in order}
        done = dict(completed)
        flows, trajectory, compute_bills = [], [], []
        protection_events=[]
        costs = {x.product_id:[] for x in order}
        active_started = set()
        nodes=getattr(self.network,'nodes',NODES)
        peak = dict(zip(nodes,thermal_state.temperatures_c))
        state = thermal_state
        tx_by_window = dict(window_transmitted_bits or {})
        initial_work_ids = [x.event_id for x in work]
        if len(initial_work_ids) != len(set(initial_work_ids)):
            raise ValueError('DUPLICATE_COMPUTE_WORK_IDENTITY')
        reason = 'COMPLETE_KNOWN_STATE_PROJECTION'
        while state.time_s < end_s-1e-10:
            t = state.time_s
            for pid,c in contingent_encodings.items():
                if pid in scheduled_contingent or c['parent'] not in done:continue
                start=max([t,done[c['parent']]]+[w.end_s for w in work if w.end_s>t])
                stop=start+c['encoding_s']
                deadline=next(x.deadline_s for x in order if x.product_id==pid)
                if stop<deadline:
                    work += (ComputeIntervalV3('contingent:'+pid,c['task_id'],'encoding',start,stop,
                                              c['encoding_j']/c['encoding_s']),)
                    ready[pid]=stop;starts[pid]=stop
                scheduled_contingent.add(pid)
            link = self.link_at(t)
            active_work = [w for w in work if w.start_s-1e-10 <= t < w.end_s-1e-10]
            if len(active_work)>1:
                raise ValueError('FROZEN_SINGLE_COMPUTE_CHANNEL_OVERLAP')
            boundaries = [end_s,link.end_s]
            boundaries += [z for x in order for z in (ready[x.product_id],x.deadline_s) if z>t+1e-10]
            boundaries += [z for w in work for z in (w.start_s,w.end_s) if z>t+1e-10]
            boundaries += [z for _pid,a,b in reserved_slices for z in (a,b) if z>t+1e-10]
            stop = min(boundaries)
            board_power = sum(w.incremental_power_w for w in active_work)
            shared = ThermalPowerV1(board_incremental_w=board_power,
                                     absorbed_external_w=link.absorbed_external_w,
                                     payload_incremental_w=link.scene_heat_power_w)
            eligible = [x for x in order if remaining[x.product_id] > .5 and
                ready[x.product_id] <= t+1e-10 and x.deadline_s>t+1e-10 and
                all(dep in done and done[dep]<=t+1e-10 for dep in x.dependencies)]
            reserved_now = [pid for pid,a,b in reserved_slices if a-1e-10<=t<b-1e-10]
            if reserved_now:
                eligible = [x for x in eligible if x.product_id in reserved_now]
            item = eligible[0] if eligible and link.business_rate_bit_s>0 else None
            if len(nodes)==5 and not active_work and item is None:
                # R06 exact event batching: integrate idle physics through
                # identical environment, retaining every ready/work/deadline
                # boundary. No cost-bearing action or macro price is skipped.
                boundaries[1]=self.constant_environment_end(t)
                stop=min(boundaries)
            if item is not None and self.preemption_contract is not None and not allow_preemption:
                # Continue the current resumable product until its completion
                # or deadline. A temporary contact/cooling gap keeps ownership.
                active=next((x for x in eligible if x.product_id==context['active_product_id']),None)
                if active is not None:item=active
            phase='TX'
            if item is not None and self.preemption_contract is not None:
                pid=item.product_id;previous=context['active_product_id']
                pause=bool(previous and previous!=pid and remaining.get(previous,0.)>.5
                    and next(x.deadline_s for x in order if x.product_id==previous)>t+1e-10)
                resume=previous!=pid and pid in suspended
                if pause:suspended.add(previous)
                if resume:suspended.discard(pid)
                if pause or resume:
                    sent=item.sent_bits+initial_remaining[pid]-remaining[pid]
                    context['overhead']=dict(product_id=pid,
                        remaining_switch_s=self.preemption_contract.switch_seconds,
                        retransmission_remaining_bits=min(int(sent),self.preemption_contract.resume_retransmit_bits) if resume else 0)
                    preemptions.append(dict(time_s=t,from_product=previous,to_product=pid,
                        pause=pause,resume=resume,paid_switch_s=self.preemption_contract.switch_seconds,
                        planned_retransmission_bits=context['overhead']['retransmission_remaining_bits'],
                        contract=asdict(self.preemption_contract),actual=False))
                context['active_product_id']=pid
                context['suspended_products']=sorted(suspended)
                debt=context['overhead']
                if debt.get('product_id')==pid:
                    if debt['remaining_switch_s']>1e-10:phase='PREEMPTION_SWITCH'
                    elif debt['retransmission_remaining_bits']>0:phase='RETRANSMISSION'
                    else:context['overhead']={}
            base_cert = self.network.advance(state,stop,shared)
            if not base_cert.safe:
                # Compute admission is rejected without mutation. A later
                # observation can reschedule remaining work; it cannot execute
                # an unsafe historical authorization behind the shield.
                reason = 'UNSAFE_COMPUTE_OR_BACKGROUND_REQUIRES_READMISSION'
                return dict(state=state,soc=soc,order=order,flows=flows,trajectory=trajectory,
                    starts=starts,finishes=finishes,remaining=remaining,costs=costs,
                    completed=done,peaks_c=peak,safe=False,reason=reason,compute_bills=compute_bills,
                    transmitted_by_window=tx_by_window,service_context=context,preemptions=preemptions,
                    unsafe_certificate=base_cert.to_dict(),unsafe_segment=dict(start_s=t,end_s=stop,
                        active_work=[asdict(w) for w in active_work],power=asdict(shared)))
            cert = base_cert
            bits = 0
            progress_bits=0
            thermal_blocked_product=None
            if item is not None:
                pid = item.product_id
                requested=(context['overhead']['remaining_switch_s'] if phase=='PREEMPTION_SWITCH' else
                    (context['overhead']['retransmission_remaining_bits'] if phase=='RETRANSMISSION' else remaining[pid])/link.business_rate_bit_s)
                stop=min(stop,t+requested)
                power = ThermalPowerV1(board_incremental_w=board_power,
                    rf_incremental_dc_w=link.tx_dc_power_w,absorbed_external_w=link.absorbed_external_w,
                    payload_incremental_w=link.scene_heat_power_w)
                trial = self.network.advance(state,stop,power)
                if not trial.safe:
                    lo,hi=0.,stop-t
                    for _ in range(40):
                        mid=(lo+hi)/2
                        if self.network.advance(state,t+mid,power).safe:lo=mid
                        else:hi=mid
                        if (getattr(self,'whole_bit_search_certificate',False) and
                                phase=='TX' and self.preemption_contract is None):
                            # The remaining bisection can only move lo inside
                            # [lo,hi]. If BOTH endpoints map to the same exact
                            # whole-bit result, all remaining iterations have
                            # the same bytes and final represented event time.
                            # No threshold, tolerance or physical step changes.
                            demand=int(remaining[pid])
                            if whole_service_bits_v3(t,t+lo,link.business_rate_bit_s,demand)==whole_service_bits_v3(t,t+hi,link.business_rate_bit_s,demand):
                                break
                    duration=lo
                else:
                    duration=stop-t
                if phase=='PREEMPTION_SWITCH':
                    useful=duration>1e-9
                else:
                    demand=context['overhead']['retransmission_remaining_bits'] if phase=='RETRANSMISSION' else int(remaining[pid])
                    bits=whole_service_bits_v3(t,t+duration,link.business_rate_bit_s,demand)
                    useful=bits>0;duration=bits/link.business_rate_bit_s
                if useful:
                    stop=t+duration
                    cert=self.network.advance(state,stop,power)
                    if phase=='PREEMPTION_SWITCH':
                        context['overhead']['remaining_switch_s']=max(0.,context['overhead']['remaining_switch_s']-duration)
                    elif phase=='RETRANSMISSION':context['overhead']['retransmission_remaining_bits']-=bits
                    else:progress_bits=bits
                    paused=context.get('thermal_paused_products',{}).pop(pid,None)
                    if paused is not None:
                        protection_events.append(dict(kind='TX_SAFE_RESUMPTION',time_s=t,product_id=pid,
                            cooling_duration_s=t-paused,safe_segment_end_s=stop,peaks_c=cert.peaks_c,
                            whole_network_safe=cert.safe,selector_scope='COMMON_WHOLE_KNOWN_QUEUE_SCHEDULE'))
                    if not trial.safe and remaining[pid]-progress_bits>.5:
                        context.setdefault('thermal_paused_products',{})[pid]=stop
                        protection_events.append(dict(kind='TX_SAFE_PREFIX_LIMIT',time_s=stop,product_id=pid,
                            preserved_sent_bits=item.sent_bits+initial_remaining[pid]-remaining[pid]+progress_bits,
                            safe_prefix_start_s=t,safe_prefix_end_s=stop,peaks_c=cert.peaks_c,
                            whole_network_safe=cert.safe))
                else:
                    if not trial.safe:thermal_blocked_product=pid
                    item=None
                    # A numerical recheck interval, without an invented
                    # restart temperature. Actual idle cooling is integrated.
                    stop=min(min(boundaries),(math.floor(t/self.step_s+1e-9)+1)*self.step_s)
                    cert=self.network.advance(state,stop,shared)
            # The physical power intervals, not averaged service capacity,
            # drive both battery and temperatures.
            dt=stop-t
            tx_j=link.tx_dc_power_w*dt if item is not None else 0.
            compute_j=board_power*dt
            scene_j=link.scene_dc_power_w*dt
            battery=compute_battery_transition(soc,link.solar_power_w*dt,
                self.network.p.frozen_background_power_w,dt,compute_j+scene_j,tx_j,
                self.pricing.battery_capacity_j,self.pricing.charge_efficiency,
                self.pricing.discharge_efficiency)
            next_ai=self.ai_after(ai_budget,link.solar_power_w*dt,compute_j)
            if battery.soc_after<.55-1e-9 or battery.unserved_load_energy_j>1e-9:
                return dict(state=state,soc=soc,ai_budget=ai_budget,order=order,flows=flows,trajectory=trajectory,
                    starts=starts,finishes=finishes,remaining=remaining,costs=costs,completed=done,peaks_c=peak,
                    safe=False,reason='FROZEN_BATTERY_RESERVE_VIOLATION',compute_bills=compute_bills,
                    transmitted_by_window=tx_by_window,service_context=context,preemptions=preemptions)
            def cost(raw,direction,base_power):
                observation=min(math.ceil((stop-1e-10)/20.)*20.,self.links[-1].end_s)
                history_start=max(0.,observation-200.)
                denominator=min(200.,observation)
                busy=sum(max(0.,min(observation,w.end_s)-max(history_start,w.start_s)) for w in work)
                covered=max(0.,min(observation,stop)-max(history_start,t))
                if raw['Ccmp']:busy=max(0.,busy-covered)
                baseline_battery=compute_battery_transition(soc,link.solar_power_w*dt,
                    self.network.p.frozen_background_power_w,dt,
                    (max(0.,compute_j-raw['E']) if raw['Ccmp'] else compute_j)+scene_j,
                    max(0.,tx_j-raw['E']) if not raw['Ccmp'] else tx_j,
                    self.pricing.battery_capacity_j,self.pricing.charge_efficiency,self.pricing.discharge_efficiency)
                # Continue the exact known schedule to the same macro-slot
                # price observation used by LC01. H perturbs heat along that
                # fixed schedule, not a discrete reoptimization gradient.
                shadow_done=dict(done);shadow_remaining=dict(remaining)
                if item is not None:
                    shadow_remaining[item.product_id]-=progress_bits
                    if shadow_remaining[item.product_id]<.5:shadow_done[item.product_id]=stop
                shadow_rows=tuple(replace(x,remaining_bits=int(round(shadow_remaining[x.product_id])),
                    sent_bits=int(round(x.sent_bits+initial_remaining[x.product_id]-shadow_remaining[x.product_id])),
                    ready_time_s=ready[x.product_id])
                    for x in order if shadow_remaining[x.product_id]>.5)
                future=self.project(thermal_state=cert.after,soc=battery.soc_after,order=shadow_rows,
                    completed=shadow_done,work=work,end_s=observation,ai_budget=max(0.,min(1.,next_ai)),
                    bill=False,window_transmitted_bits=tx_by_window,reserved_slices=reserved_slices,
                    contingent_encodings={pid:c for pid,c in contingent_encodings.items()
                        if pid not in scheduled_contingent},service_context=context,allow_preemption=allow_preemption)
                if not future['safe']:
                    raise _UnsafePriceContinuationV3(future['reason'],future.get('unsafe_certificate'),future.get('unsafe_segment'))
                continuation=[];base_soc=baseline_battery.soc_after
                for row in future['trajectory']:
                    a,b=row['start_s'],row['end_s'];future_link=self.link_at(a)
                    wp=row['board_incremental_w']
                    rp=future_link.tx_dc_power_w if row['tx_product'] is not None else 0.
                    continuation.append((b,ThermalPowerV1(board_incremental_w=wp,rf_incremental_dc_w=rp,
                        absorbed_external_w=future_link.absorbed_external_w,payload_incremental_w=future_link.scene_heat_power_w)))
                    base_soc=compute_battery_transition(base_soc,future_link.solar_power_w*(b-a),
                        self.network.p.frozen_background_power_w,b-a,(wp+future_link.scene_dc_power_w)*(b-a),rp*(b-a),
                        self.pricing.battery_capacity_j,self.pricing.charge_efficiency,
                        self.pricing.discharge_efficiency).soc_after
                outstanding=0.
                for _pid,a,b in reserved_slices:
                    for z in self.links:
                        if z.window_id==link.window_id:
                            outstanding+=max(0.,min(b,z.end_s)-max(t,a,z.start_s))*z.business_rate_bit_s
                return self.pricing.bill(raw=raw,baseline_state=state,shared_power=base_power,end_s=stop,
                    baseline_soc=base_soc,compute_pressure=busy/denominator if denominator else 0.,compute_derivative=
                        self.pricing.refs['Ccmp']*covered/dt/denominator if raw['Ccmp'] and denominator else 0.,
                    window_pressure=((tx_by_window.get(link.window_id,0.)+outstanding)/link.window_capacity_bits
                        if link.window_capacity_bits else None),window_bits=link.window_capacity_bits,
                    observation_end_s=observation,continuation=continuation,
                    node_heat_direction=direction,energy_response=self.pricing.charge_efficiency
                        if baseline_battery.net_bus_energy_j>0 else 1/self.pricing.discharge_efficiency)
            tx_bill=None;cb=None
            try:
                if item is not None and bill:
                    raw=dict(E=tx_j,H=tx_j*(1-self.network.p.rf_escaped_fraction),Ccmp=0.,B=float(bits))
                    tx_bill=cost(raw,dict(rf=1.),shared)
                if active_work and bill:
                    raw_compute=dict(E=compute_j,H=compute_j,Ccmp=dt,B=0.)
                    idle=self.network.p.board_idle_power_w
                    chip=max(0.,min(board_power,max(idle+board_power-POTHER,0.)-max(idle-POTHER,0.)))
                    direction=dict(chip=chip/board_power if board_power else 0.,
                                   board=(board_power-chip)/board_power if board_power else 0.)
                    cb=cost(raw_compute,direction,ThermalPowerV1(rf_incremental_dc_w=link.tx_dc_power_w if item else 0.,
                        absorbed_external_w=link.absorbed_external_w,payload_incremental_w=link.scene_heat_power_w))
            except _UnsafePriceContinuationV3 as failure:
                # Reject this candidate before appending the current segment.
                # No truncated continuation, invented price or physical charge.
                return dict(state=state,soc=soc,ai_budget=ai_budget,order=order,flows=flows,trajectory=trajectory,
                    starts=starts,finishes=finishes,remaining=remaining,costs=costs,completed=done,peaks_c=peak,
                    safe=False,reason='UNSAFE_PRICE_CONTINUATION:'+str(failure),compute_bills=compute_bills,
                    transmitted_by_window=tx_by_window,service_context=context,preemptions=preemptions,
                    unsafe_certificate=failure.certificate,unsafe_segment=failure.segment)
            if item is not None:
                pid=item.product_id
                if progress_bits and pid not in active_started:starts[pid]=t;active_started.add(pid)
                raw=dict(E=tx_j,H=tx_j*(1-self.network.p.rf_escaped_fraction),Ccmp=0.,B=float(bits))
                if tx_bill is not None:costs[pid].append(tx_bill)
                remaining[pid]-=progress_bits
                tx_by_window[link.window_id]=tx_by_window.get(link.window_id,0.)+bits
                flows.append(dict(product_id=pid,task_id=item.task_id,start_s=t,end_s=stop,
                    business_bits=bits,energy_j=tx_j,heat_j=raw['H'],bill=tx_bill,
                    progress_bits=progress_bits,service_kind=phase,
                    concurrent_compute_event_ids=[w.event_id for w in active_work]))
                if remaining[pid]<.5:
                    remaining[pid]=0.;finishes[pid]=stop;done[pid]=stop
            if active_work and bill:
                w=active_work[0]
                compute_bills.append(dict(event_id=w.event_id,task_id=w.task_id,kind=w.kind,
                    start_s=t,end_s=stop,bill=cb))
            trajectory.append(dict(start_s=t,end_s=stop,thermal=cert.to_dict(),battery=battery.to_log_dict(),
                ai_budget_before=ai_budget,ai_budget_after=max(0.,min(1.,next_ai)),
                ai_budget_role='HISTORICAL_100J_DIAGNOSTIC_ONLY_NO_ADMISSION_EFFECT',
                board_incremental_w=board_power,rf_incremental_dc_w=link.tx_dc_power_w if item else 0.,
                active_compute=[w.event_id for w in active_work],tx_product=None if item is None else item.product_id,
                thermal_blocked_product=thermal_blocked_product))
            if link.scene_id:
                trajectory[-1].update(scene_id=link.scene_id,scene_electrical_j=scene_j,
                    scene_retained_heat_j=link.scene_heat_power_w*dt,
                    payload_incremental_w=link.scene_heat_power_w)
            for n in nodes:peak[n]=max(peak[n],cert.peaks_c[n])
            state=cert.after;soc=battery.soc_after;ai_budget=max(0.,min(1.,next_ai))
            if stop_when_single_complete and finishes[order[0].product_id] is not None:
                reason='SINGLETON_COMPLETE_PREFIX_REQUIRES_SEPARATE_TAIL_SAFETY'
                break
        return dict(state=state,soc=soc,ai_budget=ai_budget,order=order,flows=flows,trajectory=trajectory,
            starts=starts,finishes=finishes,remaining=remaining,costs=costs,completed=done,peaks_c=peak,
            safe=True,reason=reason,compute_bills=compute_bills,transmitted_by_window=tx_by_window,
            service_context=context,preemptions=preemptions,protection_events=protection_events)


class EventQueueRuntimeV3:
    def __init__(self, *, queue, kernel, thermal_state, soc, horizon_s, reward_by_product):
        self.queue,self.kernel=queue,kernel
        self.state,self.soc=thermal_state,soc
        self.ai_budget=.92
        self.horizon_s=horizon_s
        self.reward_by_product=reward_by_product
        self.pending={};self.completed={};self.work=();self.reserved_slices=()
        self.future_materialized_products={}
        self.committed_service_proof={}
        self.consumed_committed_service={}
        self.contingent_products={}
        self.service_context=empty_service_context_v1();self.actual_preemptions=[]
        self.actual_policy_comparisons=[]
        self.actual_thermal_protection=[]
        self.reachability_only=False
        self.alpha=.5
        self.fifo_products=[]
        self.executing=False;self.consumed_receipt_ids=set()
        self.insertion_log=[];self.actual_flows=[];self.actual_trajectory=[];self.compute_bills=[]
        self.transmitted_by_window={};self.last_admission_status=''
        self.actual_fixed_cost=0.;self._reevaluating=False
        queue.bind_net_utility_owner_v3(self)

    @property
    def now(self):return self.state.time_s

    def stage(self,item):
        return IndependentQueueStageV2(self.queue._payload_id(item),str(item.task_id),
            str(item.product_type or item.payload_type),float(item.ready_time_s),float(item.deadline_time_s),
            int(round(item.remaining_mb*8e6)),tuple(item.metadata.get('queue_dependencies',())),
            item.remaining_mb<item.payload_size_mb-1e-12,
            int(round((item.payload_size_mb-item.remaining_mb)*8e6)))

    def snapshot_identity(self):
        return identity(dict(state=self.state.to_dict(),soc=self.soc,ai_budget=self.ai_budget,
            queue=[asdict(x) for x in self.queue.items],work=[asdict(w) for w in self.work],
            completed=self.completed,reserved=self.reserved_slices,
            authorized_future={pid:asdict(p) for pid,p in self.future_materialized_products.items()},
            commitment_proof=self.committed_service_proof,
            consumed_commitment_prefix=self.consumed_committed_service,
            contingent={pid:dict(payload=asdict(c['payload']),encoding_s=c['encoding_s'],encoding_j=c['encoding_j'])
                        for pid,c in self.contingent_products.items()},
            transmitted=self.transmitted_by_window,rewards=self.reward_by_product,
            service_context=self.service_context,beta=self.kernel.pricing.beta,alpha=self.alpha,
            fifo_products=self.fifo_products,
            preemption_contract=None if self.kernel.preemption_contract is None else asdict(self.kernel.preemption_contract)))

    def project(self,order,*,end_s=None,work=None,bill=True,include_committed_future=True,exclude_future_ids=()):
        # Opt-in R06 cache of the complete policy forecast, above physical
        # integration. Exact causal state, dependencies and price identity
        # are required; no approximation or future-task key is used.
        k=self.kernel;size=getattr(k,'policy_projection_cache_size',0)
        if not size:return self._project_uncached(order,end_s=end_s,work=work,bill=bill,
            include_committed_future=include_committed_future,exclude_future_ids=exclude_future_ids)
        k.link_at(min(self.now,k.links[-1].end_s-1e-8))
        k.policy_projection_calls=getattr(k,'policy_projection_calls',0)+1
        key=identity(dict(snapshot=self.snapshot_identity(),order=tuple(order),end_s=end_s,
            work=work,bill=bill,include_committed_future=include_committed_future,exclude_future_ids=exclude_future_ids,
            reachability_only=self.reachability_only,horizon_s=self.horizon_s,links=k._links_identity,
            network=asdict(k.network.p),heat_contract=asdict(k.pricing.h),kappa=k.pricing.kappa,refs=k.pricing.refs,
            gamma=k.pricing.gamma,lambda_enabled=k.pricing.lambda_enabled,
            candidate_price_identity=getattr(k.pricing,'candidate_price_identity',None),
            battery_capacity_j=k.pricing.battery_capacity_j,charge_efficiency=k.pricing.charge_efficiency,
            discharge_efficiency=k.pricing.discharge_efficiency,step_s=k.step_s,numerical_max_step_s=k.network.max_step_s))
        cache=getattr(k,'_policy_projection_cache',None)
        if cache is None:k._policy_projection_cache=cache=OrderedDict()
        if key in cache:
            k.policy_projection_hits=getattr(k,'policy_projection_hits',0)+1
            cache.move_to_end(key);return deepcopy(cache[key])
        result=self._project_uncached(order,end_s=end_s,work=work,bill=bill,
            include_committed_future=include_committed_future,exclude_future_ids=exclude_future_ids)
        cache[key]=deepcopy(result)
        while len(cache)>size:cache.popitem(last=False)
        return result

    def _project_uncached(self,order,*,end_s=None,work=None,bill=True,include_committed_future=True,exclude_future_ids=()):
        order=tuple(order)
        if include_committed_future:
            present={s.product_id for s in order}
            order += tuple(self.stage(self.queue._make_queue_item(p)) for pid,p in self.future_materialized_products.items()
                           if pid not in present and pid not in self.completed and pid not in exclude_future_ids)
        known_work=self.work if work is None else tuple(work)
        accepted_contingent={}
        def run(rows,contingent):
            stop=self.horizon_s if end_s is None else end_s
            present={r.product_id for r in rows}
            policy_rows=rows+tuple(self.stage(self.queue._make_queue_item(p))
                for pid,p in self.future_materialized_products.items() if pid not in present and pid not in self.completed
                and pid not in exclude_future_ids)
            def physical(until,charged,allowed,policy=False):
                p=self.kernel.project(thermal_state=self.state,soc=self.soc,order=policy_rows if policy else rows,completed=self.completed,
                    ai_budget=self.ai_budget,work=known_work,end_s=until,bill=charged,
                    window_transmitted_bits=self.transmitted_by_window,reserved_slices=self.reserved_slices,
                    contingent_encodings=contingent,service_context=self.service_context,allow_preemption=allowed)
                p['contingent_encoding_online_cost']={pid:sum(b['bill']['online_total'] for b in p['compute_bills']
                    if b['event_id']=='contingent:'+pid) for pid in contingent}
                return p
            allow=False;comparison=None
            competing=any(a.product_id not in b.dependencies and b.product_id not in a.dependencies
                and max(a.ready_time_s,b.ready_time_s)<min(a.deadline_s,b.deadline_s,self.horizon_s)
                for i,a in enumerate(policy_rows) for b in policy_rows[i+1:])
            if self.kernel.preemption_contract is not None and competing:
                # Policy uses the entire known queue through its horizon even
                # when the actuator is executing a short event prefix.
                continuing=physical(self.horizon_s,True,False,True)
                # Fixed ready order with no unresolved dependency/reservation
                # cannot create a later higher-priority ready product. Both
                # resumable policies therefore traverse the identical service
                # sequence, including thermal pauses, work and expiry edges.
                live_rows=[r for r in policy_rows if r.remaining_bits>0 and r.deadline_s>self.now+1e-10]
                active=self.service_context.get('active_product_id')
                identical_order=(not contingent
                    and not any(b>self.now+1e-10 for _,_,b in self.reserved_slices)
                    and all(r.ready_time_s<=self.now+1e-10 and set(r.dependencies)<=set(self.completed) for r in live_rows)
                    and (not active or not live_rows or active==live_rows[0].product_id
                         or active not in {r.product_id for r in live_rows}))
                if identical_order:
                    self.kernel.equivalent_preemption_proofs=getattr(self.kernel,'equivalent_preemption_proofs',0)+1
                    interrupting=continuing
                else:
                    interrupting=physical(self.horizon_s,True,True,True)
                def slices(p,pid):
                    out=[]
                    for f in p['flows']:
                        if f['product_id']!=pid:continue
                        if out and abs(out[-1][1]-f['start_s'])<1e-8:
                            a,b,v=out[-1];out[-1]=(a,f['end_s'],v+f['business_bits'])
                        else:out.append((f['start_s'],f['end_s'],f['business_bits']))
                    return out
                protected={self.queue._payload_id(x) for x in self.queue.items if x.metadata.get('committed_hv') or x.metadata.get('reservation_committed')}
                protected.update(self.future_materialized_products)
                preserve=all(service_slices_equal_v3(slices(continuing,pid),slices(interrupting,pid)) for pid in protected)
                cn=self.remaining_net(continuing);pn=self.remaining_net(interrupting)
                allow=interrupting['safe'] and preserve and pn>cn+1e-10
                comparison=dict(continue_remaining_net=cn,pause_resume_remaining_net=pn,
                    preemption_selected=allow,commitments_preserved=preserve,
                    scope='ENTIRE_KNOWN_AFFECTED_QUEUE_REMAINING_HORIZON')
                if stop==self.horizon_s and bill and not self.reachability_only and include_committed_future:
                    p=interrupting if allow else continuing
                else:p=physical(stop,bill and not self.reachability_only,allow)
            else:p=physical(stop,bill and not self.reachability_only,self.kernel.preemption_contract is None)
            p['preemption_comparison']=comparison
            return p
        result=run(order,accepted_contingent)
        if not include_committed_future or not result['safe']:return result
        for parent,c in self.contingent_products.items():
            child=self.queue._payload_queue_id(c['payload'])
            if child in {x.product_id for x in result['order']} or child in self.completed or child in exclude_future_ids:
                continue
            if parent not in {x.product_id for x in result['order']} and parent not in self.completed:continue
            payload=deepcopy(c['payload'])
            item=self.queue._make_queue_item(payload);stage=self.stage(item)
            contingent=dict(accepted_contingent,**{child:dict(parent=parent,task_id=stage.task_id,
                encoding_s=c['encoding_s'],encoding_j=c['encoding_j'])})
            existing=result['order'];base=self.remaining_net(result)
            continuation_floor=1+max((i for i,x in enumerate(existing) if x.partially_served),default=-1)
            floor=0 if self.kernel.preemption_contract is not None else continuation_floor
            trials=[]
            protected={self.queue._payload_id(x) for x in self.queue.items if x.metadata.get('committed_hv') or x.metadata.get('reservation_committed')}
            protected.update(self.future_materialized_products)
            for index in range(floor,len(existing)+1):
                rows=existing[:index]+(stage,)+existing[index:]
                known=set(self.completed);legal=True
                for s in rows:
                    if not set(s.dependencies)<=known:legal=False;break
                    known.add(s.product_id)
                if not legal:continue
                trial=run(rows,contingent)
                if not trial['safe']:continue
                def merged(p,pid):
                    out=[]
                    for f in p['flows']:
                        if f['product_id']!=pid:continue
                        if out and abs(out[-1][1]-f['start_s'])<1e-8:
                            a,b,v=out[-1];out[-1]=(a,f['end_s'],v+f['business_bits'])
                        else:out.append((f['start_s'],f['end_s'],f['business_bits']))
                    return out
                if any(not service_slices_equal_v3(merged(trial,pid),merged(result,pid)) for pid in protected):continue
                net=self.remaining_net(trial)
                if trial['finishes'].get(child) is not None:
                    trials.append((net,trial,index<continuation_floor))
            if trials:
                cb=max((x[0] for x in trials if not x[2]),default=base)
                winners=[x for x in trials if x[0]>base and (not x[2] or x[0]>cb+1e-10)]
                if winners:
                    result=best_net_trial_v2(winners,net=lambda r:r[0],
                        tie=lambda r:queue_tie_key_v2(r[1]['order'],self.fifo_products+[child]))[1]
                    accepted_contingent=contingent
        return result

    def projection_net(self,projection):
        values={}
        for item in projection['order']:
            pid=item.product_id; finish=projection['finishes'][pid]
            reward=self.reward_by_product[pid]
            gross=0. if finish is None else sum(float(v['gross']) for v in reward
                if finish<=float(v['deadline_s'])+1e-9)
            values[pid]=(gross-sum(b['online_total'] for b in projection['costs'][pid])-
                projection.get('contingent_encoding_online_cost',{}).get(pid,0.))
        return values

    def remaining_compute_cost(self,projection):
        # Virtual encoding is already assigned once to its child product.
        # All other still-future work belongs to the whole-queue baseline.
        return sum(b['bill']['online_total'] for b in projection['compute_bills']
                   if not b['event_id'].startswith('contingent:'))

    def remaining_net(self,projection):
        return sum(self.projection_net(projection).values())-self.remaining_compute_cost(projection)

    def remaining_fixed_net(self,projection):
        gross=sum(v['gross'] for pid,vs in self.reward_by_product.items() for v in vs
            if projection['finishes'].get(pid) is not None and projection['finishes'][pid]<=v['deadline_s']+1e-9)
        return gross-sum(b['bill']['fixed_total_scaled'] for b in projection['compute_bills'])-sum(
            b['fixed_total_scaled'] for costs in projection['costs'].values() for b in costs)

    def quote_item(self,item,*,existing=None):
        order=tuple(self.stage(x) for x in (self.queue.items if existing is None else existing))
        candidate=self.stage(item);snapshot=self.snapshot_identity()
        baseline=self.project(order,exclude_future_ids=(candidate.product_id,))
        if not baseline['safe']:
            return dict(status='WAIT',baseline_remaining_net=None,selected_order=None,trials=[],
                reason=baseline['reason'],snapshot_identity=snapshot,prediction_is_not_actual_service=True,
                physical_trials=[dict(physical_feasible=False,deadline_reachable=None,commitment_legal=None,
                    reason=baseline['reason'],unsafe_certificate=baseline.get('unsafe_certificate'),
                    unsafe_segment=baseline.get('unsafe_segment'),scope='EXISTING_BASELINE')])
        protected={self.queue._payload_id(x) for x in self.queue.items if x.metadata.get('committed_hv',False)
                   or x.metadata.get('reservation_committed',False)}
        protected.update(pid for pid in self.future_materialized_products if pid not in self.completed)
        def slices(p,pid):
            merged=[]
            for f in p['flows']:
                if f['product_id']!=pid:continue
                if merged and abs(merged[-1][1]-f['start_s'])<1e-9:
                    a,b,c=merged[-1];merged[-1]=(a,f['end_s'],c+f['business_bits'])
                else:merged.append((f['start_s'],f['end_s'],f['business_bits']))
            return merged
        physical_trials=[]
        def project(rows):
            p=baseline if rows==order else self.project(rows,exclude_future_ids=(candidate.product_id,))
            def preserved_product(pid):
                expected=slices(baseline,pid)
                if pid in self.committed_service_proof:
                    expected=self.committed_service_proof[pid]
                future=self.future_materialized_products.get(pid)
                if (not expected and future is not None and
                        candidate.product_id in future.metadata.get('queue_dependencies',())):
                    # Materializing the already committed parent restores its
                    # dependent service; compare to the original entitlement,
                    # rather than forbidding a no-service -> service change.
                    expected=self.committed_service_proof.get(pid,[])
                actual=slices(p,pid)
                if pid in self.committed_service_proof:
                    actual=merge_service_slices_v3(self.consumed_committed_service.get(pid,[])+actual)
                return service_slices_equal_v3(actual,expected)
            preserved=p['safe'] and (rows==order or all(preserved_product(pid)
                for pid in protected))
            net=self.projection_net(p);ids={x.product_id for x in rows}
            if rows!=order:
                public_increment=self.remaining_fixed_net(p)-self.remaining_fixed_net(baseline)
                online_increment=self.remaining_net(p)-self.remaining_net(baseline)
                physical_trials.append(dict(order=[x.product_id for x in rows],
                    physical_feasible=p['safe'],deadline_reachable=(p['finishes'].get(candidate.product_id) is not None
                        if p['safe'] else None),commitment_legal=preserved if p['safe'] else None,
                    public_increment=public_increment if p['safe'] else None,
                    dynamic_increment=online_increment-public_increment if p['safe'] else None,
                    online_increment=online_increment if p['safe'] else None,
                    public_remaining_net=self.remaining_fixed_net(p) if p['safe'] else None,
                    online_remaining_net=self.remaining_net(p) if p['safe'] else None,
                    candidate_future_bills=[b['bill'] for b in p['compute_bills'] if b['task_id']==candidate.task_id],
                    reason=p['reason'],unsafe_certificate=p.get('unsafe_certificate'),
                    unsafe_segment=p.get('unsafe_segment'),predicted_ground_s=p['finishes'].get(candidate.product_id)))
            return QueueRemainingNetProjectionV2(snapshot,identity(dict(snapshot=snapshot,
                order=[x.product_id for x in rows],flows=p['flows'])),{k:v for k,v in net.items() if k in ids},
                {k:v for k,v in p['starts'].items() if k in ids},{k:v for k,v in p['finishes'].items() if k in ids},
                {x.product_id:int(round(x.remaining_bits-p['remaining'][x.product_id])) for x in rows},preserved,
                sum(v for k,v in net.items() if k not in ids)-self.remaining_compute_cost(p))
        quote=best_legal_insertion_v2(existing=order,candidate=candidate,now_s=self.now,
            snapshot_identity=snapshot,completed_dependency_times=self.completed,project=project,
            allow_conditional_preemption=self.kernel.preemption_contract is not None,
            require_positive_gain=not self.reachability_only,require_candidate_completion=self.reachability_only,
            fifo_order=self.fifo_products+[candidate.product_id])
        quote['physical_trials']=physical_trials
        return quote

    def admit_materialized_payload(self,payload):
        item=self.queue._make_queue_item(payload)
        pid=self.queue._payload_id(item)
        if pid in self.completed:
            self.last_admission_status='ALREADY_DELIVERED';return False
        if pid not in self.reward_by_product:
            raise ValueError('MISSING_REMAINING_GROUND_REWARD_PROVENANCE')
        if pid not in self.fifo_products:self.fifo_products.append(pid)
        if self.queue.queue_mb+payload.payload_mb>self.queue.queue_max_mb+1e-9:
            self.last_admission_status='WAIT';self.pending[pid]=deepcopy(payload)
            self.insertion_log.append(dict(time_s=self.now,product_id=pid,status='WAIT',reason='FROZEN_QUEUE_CAPACITY'))
            return False
        quote=self.quote_item(item)
        self.last_admission_status=quote['status']
        self.insertion_log.append(dict(time_s=self.now,product_id=pid,**quote))
        if quote['status']!='INSERT':
            if quote['status']=='WAIT':self.pending[pid]=deepcopy(payload)
            return False
        by_id={self.queue._payload_id(x):x for x in self.queue.items};by_id[pid]=item
        self.queue.items=[by_id[k] for k in quote['selected_order']]
        self.pending.pop(pid,None)
        self.queue._touch_effective_service_revision_v1()
        return True

    def reevaluate(self,now_s):
        if abs(now_s-self.now)>1e-8:
            raise ValueError('QUEUE_REEVALUATION_REQUIRES_CURRENT_EVENT_STATE')
        if self._reevaluating:return
        if not self.queue.items and not self.pending:return
        self._reevaluating=True
        try:
            for pid,payload in tuple(self.pending.items()):
                if self.queue._make_queue_item(payload).deadline_time_s<self.now-1e-9:
                    self.pending.pop(pid);self.insertion_log.append(dict(time_s=self.now,product_id=pid,status='EXPIRED'))
                else:self.queue.enqueue(payload)
            # Reinsert an uncommitted, unstarted queued product only when its
            # best legal position improves the current *whole* queue.
            before=self.project(tuple(self.stage(x) for x in self.queue.items))
            current=self.remaining_net(before)
            for item in tuple(self.queue.items):
                if (item.remaining_mb<item.payload_size_mb-1e-12 and self.kernel.preemption_contract is None) or item.metadata.get('committed_hv') or item.metadata.get('reservation_committed'):
                    continue
                existing=[x for x in self.queue.items if x is not item]
                quote=self.quote_item(item,existing=existing)
                if quote['status']=='INSERT':
                    best=next(x for x in quote['trials'] if x.get('order')==quote['selected_order'])
                    tied=abs(best['net']-current)<=NET_TOLERANCE_V2
                    selected=tuple(self.stage(next(x for x in self.queue.items if self.queue._payload_id(x)==pid))
                        for pid in quote['selected_order'])
                    original=tuple(self.stage(x) for x in self.queue.items)
                    improves_tie=tied and not best.get('conditional_preemption') and (
                        queue_tie_key_v2(selected,self.fifo_products)<queue_tie_key_v2(original,self.fifo_products))
                    if best['net']>current+NET_TOLERANCE_V2 or improves_tie:
                        by_id={self.queue._payload_id(x):x for x in self.queue.items}
                        self.queue.items=[by_id[k] for k in quote['selected_order']]
                        self.queue._touch_effective_service_revision_v1();current=best['net']
                        self.insertion_log.append(dict(time_s=self.now,product_id=self.queue._payload_id(item),reevaluation=True,**quote))
        finally:self._reevaluating=False

    def execute_until(self,end_s):
        if end_s<self.now or end_s>self.horizon_s+1e-9:
            raise ValueError('INVALID_EXECUTION_HORIZON')
        snapshot=self.snapshot_identity()
        projection=self.project(tuple(self.stage(x) for x in self.queue.items),end_s=end_s,include_committed_future=False)
        if not projection['safe']:
            raise ValueError(projection['reason'])
        if snapshot!=self.snapshot_identity():
            raise ValueError('FORECAST_MUTATED_ACTUAL_STATE')
        self.executing=True
        completions=[]
        try:
            for i,flow in enumerate(projection['flows']):
                receipt=identity(dict(snapshot=snapshot,index=i,flow=flow))
                progress=flow.get('progress_bits',flow['business_bits'])
                if progress:
                    item,complete=self.queue.consume_event_bytes_v3(product_id=flow['product_id'],
                        start_s=flow['start_s'],end_s=flow['end_s'],business_bits=progress,receipt_id=receipt)
                else:
                    if receipt in self.consumed_receipt_ids:raise ValueError('DUPLICATE_PREEMPTION_OVERHEAD_RECEIPT')
                    self.consumed_receipt_ids.add(receipt);complete=False
                self.actual_flows.append(dict(flow,receipt_id=receipt,actual=True))
                if flow['product_id'] in self.committed_service_proof:
                    pid=flow['product_id']
                    self.consumed_committed_service[pid]=merge_service_slices_v3(
                        self.consumed_committed_service.get(pid,[])+[(flow['start_s'],flow['end_s'],flow['business_bits'])])
                self.actual_fixed_cost+=flow['bill']['fixed_total']
                if complete:
                    self.completed[flow['product_id']]=flow['end_s']
                    self.future_materialized_products.pop(flow['product_id'],None)
                    self.contingent_products.pop(flow['product_id'],None)
                    completions.append(dict(product_id=flow['product_id'],task_id=item.task_id,
                        product_type=item.product_type,ground_time_s=flow['end_s'],metadata=deepcopy(item.metadata),
                        tx_receipt_id=receipt))
            for b in projection['compute_bills']:
                self.actual_fixed_cost+=b['bill']['fixed_total']
            self.compute_bills.extend(projection['compute_bills'])
            self.actual_trajectory.extend(projection['trajectory'])
            self.state=projection['state'];self.soc=projection['soc'];self.ai_budget=projection['ai_budget']
            self.transmitted_by_window=projection['transmitted_by_window']
            self.service_context=projection['service_context']
            self.actual_preemptions.extend(dict(p,actual=True) for p in projection['preemptions'])
            if not hasattr(self,'actual_thermal_protection'):self.actual_thermal_protection=[]
            self.actual_thermal_protection.extend(dict(p,actual=True) for p in projection.get('protection_events',[]))
            if projection.get('preemption_comparison') is not None:
                self.actual_policy_comparisons.append(dict(time_s=self.state.time_s,
                    decision_scope='WHOLE_KNOWN_QUEUE_NOT_SHORT_ACTUATOR_PREFIX',
                    **projection['preemption_comparison']))
        finally:self.executing=False
        return completions
