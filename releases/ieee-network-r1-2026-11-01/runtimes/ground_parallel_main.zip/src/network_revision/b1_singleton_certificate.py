"""Positive-only singleton service proof; never an execution trajectory.

With no unfinished compute, dependencies or preemption, unthrottled singleton
bytes depend only on the original clock and whole-bit rule. A cooperative
thermal comparison with continuous maximum TX power proves that no throttle
can occur; the existing idle bound then covers the remaining horizon. Failure
to prove any condition returns None and requires the original integrator.
"""
from dataclasses import replace
import math
from src.link.event_queue_runtime_v3 import whole_service_bits_v3
from src.network_revision.b1_tail_certificate import _certify_idle_interval,certify_idle_tail


def certify_singleton(kernel,state,soc,item,window_end_s,horizon_s,work=()):
    start=state.time_s
    if (item.dependencies or kernel.preemption_contract is not None or
            item.ready_time_s>start+1e-10 or item.deadline_s<window_end_s or
            any(w.end_s>start+1e-10 for w in work) or window_end_s<=start):return None
    t=start;remaining=int(item.remaining_bits);maximum_tx=0.;steps=0
    while remaining>0 and t<window_end_s-1e-10:
        steps+=1
        if steps>4*len(kernel.links)+8:return None
        link=kernel.link_at(t)
        boundary=min(window_end_s,link.end_s)
        if boundary<=t:return None
        rate=link.business_rate_bit_s
        if rate>0:
            maximum_tx=max(maximum_tx,link.tx_dc_power_w)
            end=min(boundary,t+remaining/rate)
            bits=whole_service_bits_v3(t,end,rate,remaining)
            if bits:
                t=t+bits/rate;remaining-=bits
                continue
        t=min(boundary,(math.floor(t/kernel.step_s+1e-9)+1)*kernel.step_s)
    if remaining:return None
    prefix=_certify_idle_interval(kernel,state,soc,t,(),rf_incremental_dc_w=maximum_tx)
    if prefix is None:return None
    upper=replace(state,time_s=t,temperatures_c=prefix['upper_terminal_c'])
    tail=certify_idle_tail(kernel,upper,prefix['soc_lower'],horizon_s,())
    if tail is None:return None
    return dict(kind='POSITIVE_ONLY_SINGLETON_SERVICE_BOUND',finish_s=t,
        prefix=prefix,tail=tail,actual_trajectory=False)
