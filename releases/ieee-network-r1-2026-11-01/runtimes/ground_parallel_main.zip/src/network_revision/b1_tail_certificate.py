"""Sufficient safety certificate for an empty, idle four-node forecast tail.

Never supplies physical service, a trajectory, or an unsafe verdict. Failure to
certify means the unchanged numerical forecast must run. Radiation is convex
above absolute zero; its tangent is a lower heat-loss bound. The resulting
cooperative linear thermal system, driven by maximum known external heat,
upper-bounds the original idle thermal state componentwise.
"""
from functools import lru_cache
from dataclasses import replace
import math
import numpy as np
from scipy.linalg import eigh
from src.energy.celsius_thermal_network_v1 import NODES,CC,GCB,POTHER,SIGMA
from src.energy.battery_update import compute_battery_transition

@lru_cache(maxsize=32)
def _linear_model(parameters, external):
    cb,cr,cs,gbs,grs,area,space,board,rf,structure=parameters
    caps=(CC,cb,cr,cs);root=tuple(math.sqrt(c) for c in caps)
    if min(gbs,grs,area)<=0:return None
    # The exact constant-input equilibrium is a physically derived tangent
    # point, not a fitted safety threshold or an experiment parameter.
    kelvin=(space**4+(board+rf+structure+external)/(area*SIGMA))**.25
    ref=kelvin-273.15
    loss=area*SIGMA*(kelvin**4-space**4)
    radiation=4.*area*SIGMA*kelvin**3
    if min(gbs,grs,radiation)<=0:return None
    eqs=ref+(board+rf+structure+external-loss)/radiation
    eqb=eqs+board/gbs
    eq=(eqb+max(board-POTHER,0.)/GCB,eqb,eqs+rf/grs,eqs)
    conduct=((GCB,-GCB,0.,0.),(-GCB,GCB+gbs,0.,-gbs),
             (0.,0.,grs,-grs),(0.,-gbs,-grs,gbs+grs+radiation))
    symmetric=np.array([[-conduct[i][j]/(root[i]*root[j]) for j in range(4)] for i in range(4)])
    rates,vectors=eigh(symmetric,check_finite=True,driver='evr')
    if max(rates)>=0:return None
    # Scalar checks avoid relying on the environment's small-matrix BLAS.
    residual=max(abs(sum(symmetric[i,k]*vectors[k,j] for k in range(4))-rates[j]*vectors[i,j])
                 for i in range(4) for j in range(4))
    if residual>1e-12:return None
    return eq,root,tuple(float(v) for v in rates),tuple(tuple(float(v) for v in row) for row in vectors)

def _certify_idle_interval(kernel,state,soc,end_s,work=(),*,board_incremental_w=0.,rf_incremental_dc_w=0.):
    """Return a conservative certificate or None; no state/cache mutation."""
    start=state.time_s
    if end_s<start or not math.isfinite(end_s) or len(state.temperatures_c)!=4:return None
    if tuple(getattr(kernel.network,'nodes',NODES))!=NODES:return None
    if any(w.end_s>start+1e-10 for w in work):return None
    links=[x for x in kernel.links if x.end_s>start and x.start_s<end_s]
    if not links and end_s>start:return None
    if any(x.scene_dc_power_w or x.scene_heat_power_w or x.solar_power_w<0 for x in links):return None
    cursor=start
    for x in links:
        if x.start_s>cursor+1e-9:return None
        cursor=max(cursor,x.end_s)
    if cursor<end_s-1e-9:return None
    p=kernel.network.p
    if min(board_incremental_w,rf_incremental_dc_w)<0:return None
    if not all(math.isfinite(x) for x in (board_incremental_w,rf_incremental_dc_w)):return None
    extra_load=board_incremental_w+rf_incremental_dc_w
    # First try the cheap no-solar bound. If too loose, replay the ORIGINAL
    # battery equation over the known idle exogenous intervals. Each interval
    # has constant net bus power, so its minimum SOC is at an endpoint.
    # This never invents solar input or changes a physical battery update.
    pr=kernel.pricing
    if not (0<pr.discharge_efficiency<=1 and pr.battery_capacity_j>0 and .55<=soc<=1):return None
    lower=soc-(p.frozen_background_power_w+extra_load)*(end_s-start)/pr.discharge_efficiency/pr.battery_capacity_j
    if lower<.55+1e-7:
        exact_soc=soc;minimum=soc
        for link in links:
            duration=min(end_s,link.end_s)-max(start,link.start_s)
            if duration<=0:continue
            transition=compute_battery_transition(exact_soc,link.solar_power_w*duration,
                p.frozen_background_power_w,duration,board_incremental_w*duration,rf_incremental_dc_w*duration,pr.battery_capacity_j,
                pr.charge_efficiency,pr.discharge_efficiency)
            if transition.unserved_load_energy_j>0:return None
            exact_soc=transition.soc_after;minimum=min(minimum,exact_soc)
        lower=minimum-1e-8
        if lower<.55+1e-7:return None
    params=(p.board_capacity_j_k,p.rf_capacity_j_k,p.structure_capacity_j_k,
            p.board_structure_conductance_w_k,p.rf_structure_conductance_w_k,
            p.emissivity_area_m2,p.space_temperature_k,p.board_idle_power_w+board_incremental_w,
            p.rf_idle_power_w+rf_incremental_dc_w*(1.-p.rf_escaped_fraction),p.structure_idle_power_w)
    model=_linear_model(params,max((x.absorbed_external_w for x in links),default=0.))
    if model is None:return None
    eq,root,rates,vectors=model
    initial=state.temperatures_c;limits=tuple(p.safe_limits_c[n] for n in NODES)
    if any(t<=-273.15 or t>limit+1e-8 for t,limit in zip(initial,limits)):return None
    weights=tuple(math.fsum(vectors[k][j]*root[k]*(initial[k]-eq[k]) for k in range(4)) for j in range(4))
    coeff=tuple(tuple(vectors[i][j]*weights[j]/root[i] for j in range(4)) for i in range(4))
    peaks=list(initial);duration=end_s-start;t0=0.;e0=(1.,)*4;y0=initial;step=20.
    while t0<duration:
        t1=min(duration,t0+step);dt=t1-t0;e1=tuple(math.exp(rate*t1) for rate in rates)
        y1=tuple(eq[i]+math.fsum(coeff[i][j]*e1[j] for j in range(4)) for i in range(4))
        interval_peaks=[];valid=True
        for i in range(4):
            b=tuple(coeff[i][j]*rates[j] for j in range(4))
            # Each exponential decreases; bound the derivative throughout
            # this entire interval, not only its endpoints.
            upper=math.fsum(b[j]*(e0[j] if b[j]>=0 else e1[j]) for j in range(4))
            lower_derivative=math.fsum(b[j]*(e1[j] if b[j]>=0 else e0[j]) for j in range(4))
            if upper < -1e-10:
                peak=y0[i]
                pad=0. if t0==0. else 1e-6
            elif lower_derivative > 1e-10:
                peak=y1[i];pad=1e-6
            else:
                peak=max(y0[i],y1[i])+max(abs(upper),abs(lower_derivative))*dt/2.;pad=1e-6
            if peak+pad>limits[i]+(1e-8 if pad==0. else 0.):valid=False;break
            interval_peaks.append(peak+pad)
        if not valid:
            if step>20.:step=max(20.,step/2.);continue
            return None
        peaks=[max(a,b) for a,b in zip(peaks,interval_peaks)]
        t0=t1;e0=e1;y0=y1;step=min(1280.,step*2.)
    return dict(kind='SUFFICIENT_IDLE_TAIL_LINEAR_UPPER_BOUND',safe=True,
        start_s=start,end_s=end_s,upper_peaks_c=dict(zip(NODES,peaks)),soc_lower=lower,
        upper_terminal_c=tuple(v+1e-6 for v in y0),
        actual_trajectory=False,zero_future_compute=board_incremental_w==0.,zero_future_tx=rf_incremental_dc_w==0.)

def certify_idle_tail(kernel,state,soc,end_s,work=()):
    whole=_certify_idle_interval(kernel,state,soc,end_s,work)
    if whole is not None:return whole
    # A constant worst-case heat input over the entire remaining orbit can
    # be too loose. Compose upper bounds across ACTUAL exogenous heat phases.
    # Upper terminal temperatures, never execution states, seed each segment.
    start=state.time_s
    if any(w.end_s>start+1e-10 for w in work):return None
    links=[x for x in kernel.links if x.end_s>start and x.start_s<end_s]
    phases=[]
    for x in links:
        if phases and x.absorbed_external_w==phases[-1][2]:phases[-1][1]=min(end_s,x.end_s)
        else:phases.append([max(start,x.start_s),min(end_s,x.end_s),x.absorbed_external_w])
    if len(phases)<2:return None
    upper_state=state;exact_soc=soc;minimum=soc;peaks=list(state.temperatures_c)
    pr=kernel.pricing
    for a,b,heat in phases:
        if abs(upper_state.time_s-a)>1e-9:return None
        bound=_certify_idle_interval(kernel,upper_state,exact_soc,b,work)
        if bound is None:return None
        minimum=min(minimum,bound['soc_lower'])
        peaks=[max(v,bound['upper_peaks_c'][n]) for n,v in zip(NODES,peaks)]
        for link in links:
            dt=min(b,link.end_s)-max(a,link.start_s)
            if dt>0:
                exact_soc=compute_battery_transition(exact_soc,link.solar_power_w*dt,
                    kernel.network.p.frozen_background_power_w,dt,0.,0.,pr.battery_capacity_j,
                    pr.charge_efficiency,pr.discharge_efficiency).soc_after
        upper_state=replace(upper_state,time_s=b,temperatures_c=bound['upper_terminal_c'])
    if abs(upper_state.time_s-end_s)>1e-9:return None
    return dict(kind='SUFFICIENT_PIECEWISE_IDLE_TAIL_UPPER_BOUND',safe=True,start_s=start,end_s=end_s,
        upper_peaks_c=dict(zip(NODES,peaks)),soc_lower=minimum,upper_terminal_c=upper_state.temperatures_c,
        phases=len(phases),actual_trajectory=False,zero_future_compute=True,zero_future_tx=True)
