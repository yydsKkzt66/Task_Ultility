@echo off
cd /d "%~dp0"
python run.py queue --package B --out outputs --detach
pause
