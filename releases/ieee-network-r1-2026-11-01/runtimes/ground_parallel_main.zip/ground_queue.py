"""Persistent, disjoint A/B queue. A first validates both 4101 window prefixes."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import argparse,csv,json,os,subprocess,sys,time,statistics
import psutil
from formal_common import ROOT,read,write,sha,verify,alive
from formal_summary import flatten

def csvout(path,rows,fields=None):
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields or list(rows[0]) if rows else fields or ['status'])
        w.writeheader();w.writerows(rows)

def stamp():return datetime.now(ZoneInfo('Asia/Shanghai')).strftime('%Y-%m-%d %H:%M:%S')

def scan(folder,children):
    attempts=sorted(folder.glob('attempt_*')) if folder.exists() else []
    attempts=[p for p in attempts if p.is_dir()]
    if not attempts:return ('PENDING',None,{})
    p=attempts[-1];s=read(p/'STATUS.json') if (p/'STATUS.json').exists() else {}
    if (p/'COMPLETED.json').exists() and (p/'AUDIT.json').exists() and read(p/'AUDIT.json')['pass']:
        return 'COMPLETED',p,s
    child=children.get(str(p))
    if alive(s) or (child is not None and child.poll() is None):return 'RUNNING',p,s
    if (p/'FAILED.json').exists():return 'FAILED',p,s
    if (p/'LATEST_CHECKPOINT.json').exists() and len(attempts)<3:return 'RESUMABLE',p,s
    return 'INTERRUPTED',p,s

def launch(job,base,children,logs,stop=21600.,resume=None):
    base.mkdir(parents=True,exist_ok=True)
    n=1+len([p for p in base.glob('attempt_*') if p.is_dir()])
    attempt=base/f'attempt_{n:02d}'
    cmd=[sys.executable,str(ROOT/'run.py'),'worker','--seed',str(job['seed']),
         '--arm',job['arm'],'--out',str(attempt),'--stop',str(stop)]
    if resume:cmd+=['--resume',str(resume)]
    log=(base/f'attempt_{n:02d}.log').open('ab')
    proc=subprocess.Popen(cmd,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,
                          creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
    children[str(attempt)]=proc;logs.append(log)
    # Reserve an attempt immediately, but worker itself owns mkdir and STATUS.
    write(base/f'launch_{n:02d}.json',dict(pid=proc.pid,command=cmd,epoch=time.time(),attempt=str(attempt)))
    return attempt

def checkpoint(attempt):
    meta=read(attempt/'LATEST_CHECKPOINT.json');return attempt/meta['path']

def gate_valid(gate,source_hash):
    return gate.exists() and read(gate).get('pass') is True and read(gate).get('source_sha256')==source_hash

def finish_gate(out,jobs,children):
    results=[]
    for j in jobs:
        state,p,s=scan(out/'GATES'/f"{j['seed']}_{j['arm']}",children)
        if state!='COMPLETED':return None
        summary=read(p/'RESULT/AUDITED_SUMMARY.json')
        assert s['time_s']==4200. and summary['stop_s']==4200.
        results.append(dict(arm=j['arm'],seed=j['seed'],time_s=4200.,audit=read(p/'AUDIT.json'),
              audit_sha256=sha(p/'AUDIT.json'),checkpoint=str(checkpoint(p)),
              checkpoint_sha256=sha(checkpoint(p)),summary_path=str(p/'RESULT/AUDITED_SUMMARY.json'),
              wall_s=s['active_wall_s'],cpu_s=s['cpu_s'],arrivals=s['arrivals'],closed=s['closed']))
    return dict(**{'pass':True},source_sha256=sha(ROOT/'SOURCE_MANIFEST.json'),
                input_manifest_sha256=sha(ROOT/'INPUT_MANIFEST.json'),created=stamp(),results=results,
                scope='Both methods, seed4101, actual 0..4200s. Not final6h results.')

def summarize(out,jobs,children,phase):
    rows=[];done=[]
    for j in jobs:
        st,p,s=scan(out/f"{j['seed']}_{j['arm']}",children)
        row=dict(package=j['package'],arm=j['arm'],seed=j['seed'],status=st,
                 time_s=s.get('time_s'),arrivals=s.get('arrivals'),closed=s.get('closed'),
                 wall_s=s.get('active_wall_s'),cpu_s=s.get('cpu_s'),PID=s.get('pid'),
                 result_path=str(p) if p else None,source_sha256=sha(ROOT/'SOURCE_MANIFEST.json'),
                 config_sha256=j['config_sha256'],input_sha256=read(ROOT/'INPUT_MANIFEST.json')['files'][f"network_inputs/seed_{j['seed']}/tasks.csv"],
                 observed_ETA_s=None)
        if st=='RUNNING':
            try:
                proc=psutil.Process(s['pid']);row['live_CPU_s']=sum(proc.cpu_times()[:2]);row['RSS_MB']=proc.memory_info().rss/1e6
            except (psutil.Error,KeyError):pass
            t=s.get('time_s',0)
            if t>=4200:row['observed_ETA_s']=s['active_wall_s']/t*(21600-t)
        if st=='COMPLETED':
            summary=read(p/'RESULT/AUDITED_SUMMARY.json')
            assert summary['stop_s']==21600. and summary['terminal_settled']
            summary.update(runtime=read(p/'COMPLETED.json'),identity=read(p/'IDENTITY.json'),result_path=str(p))
            flat=flatten(summary);done.append(flat)
        rows.append(row)
    memory=psutil.virtual_memory();now=stamp()
    write(out/'PROGRESS.json',dict(updated=now,phase=phase,max_parallel=4,rows=rows,memory_available_MB=memory.available/1e6,
           ETA_note='Cumulative observed rate after first window only; later queue/thermal work may differ. No 3h guarantee.'))
    all_fields=list(dict.fromkeys(k for r in rows for k in r));csvout(out/'RUN_STATUS.csv',rows,all_fields)
    text=['# 新版地面独立处理主实验进度','',f'更新时间：{now}（北京时间）；阶段：{phase}。','',
          '本机仅本包5组；最多4并行，GROUND优先。另一包不在本机启动。未完成不计零。','',
          '|方法|种子|状态|仿真秒|到达|闭环|有效墙钟秒|PID|线性预计剩余分钟|',
          '|---|---:|---|---:|---:|---:|---:|---:|---:|']
    def f(x):return '—' if x is None else f'{x:.1f}' if isinstance(x,float) else str(x)
    for r in rows:text.append('|'+ '|'.join(f(x) for x in [r['arm'],r['seed'],r['status'],r['time_s'],r['arrivals'],r['closed'],r['wall_s'],r['PID'],r['observed_ETA_s']/60 if r['observed_ETA_s'] is not None else None])+'|')
    text+=['','ETA仅为已完成首窗后的累计实测速率外推，不保证后段速度；3小时是争取目标。',
           '每进程数值线程=1，60秒更新进度；每20分钟记录内存，约10分钟保存检查点。所有时间为桌面仿真开销。',
           '新规则：完整接收后独立处理4.29秒，无地面串行队列/缓存溢出；安全和余热检查保留。']
    (out/'00_PROGRESS_CN.md').write_text('\n'.join(text)+'\n',encoding='utf-8')
    if done:csvout(out/'COMPLETED_NEW_METRICS.csv',done)
    reference=ROOT/'BASELINE_METRICS.csv'
    if reference.exists():
        with reference.open(encoding='utf-8-sig',newline='') as fp:old={(r['method'],int(r['seed'])):r for r in csv.DictReader(fp)}
        changes=[]
        for r in done:
            baseline=old[(r['method'],r['seed'])]
            for k in ['gross','net','E_cost','B_cost','Q_cost','HV_net','HV_closed','ordinary_closed','controlled_J','downlink_MB','wall_s','CPU_s']:
                if k in r and k in baseline:changes.append(dict(method=r['method'],seed=r['seed'],metric=k,old=float(baseline[k]),new=r[k],delta=r[k]-float(baseline[k]),comparison='NEW_CONFIGURATION_NOT_CAPACITY_ONLY'))
        if changes:csvout(out/'OLD_NEW_COMPARISON.csv',changes)
    return rows

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--package',choices=['A','B'],required=True)
    ap.add_argument('--out',default='outputs');ap.add_argument('--detach',action='store_true');ap.add_argument('--poll',type=float,default=60.)
    a=ap.parse_args();assert 5<=a.poll<=60
    out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True);verify()
    if (out/'SUPERVISOR.json').exists() and alive(read(out/'SUPERVISOR.json')):raise SystemExit('Already running')
    if a.detach:
        command=[sys.executable,str(ROOT/'run.py'),'queue','--package',a.package,'--out',str(out),'--poll',str(a.poll)]
        log=(out/'supervisor.log').open('ab')
        flags=(subprocess.CREATE_NO_WINDOW|subprocess.CREATE_BREAKAWAY_FROM_JOB) if os.name=='nt' else 0
        proc=subprocess.Popen(command,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,creationflags=flags,start_new_session=os.name!='nt')
        write(out/'LAUNCH.json',dict(pid=proc.pid,command=command,package=a.package,created=stamp()));print('SUPERVISOR_PID',proc.pid);return
    write(out/'SUPERVISOR.json',dict(pid=os.getpid(),process_created=psutil.Process().create_time(),package=a.package))
    jobs=[j for j in read(ROOT/'RUN_MATRIX.json')['jobs'] if j['package']==a.package]
    assert len(jobs)==5
    jobs.sort(key=lambda j:(j['arm']!='GROUND',j['seed']))
    gates=[j for j in jobs if j['seed']==4101];children={};logs=[];source=sha(ROOT/'SOURCE_MANIFEST.json')
    gate=out/'FIRST_WINDOW_GATE.json' if a.package=='A' else ROOT/'FIRST_WINDOW_GATE.json'
    last_memory=0.;launched=set()
    try:
        while True:
            if time.time()-last_memory>=1200:
                with (out/'MEMORY_20MIN.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(dict(time=stamp(),**psutil.virtual_memory()._asdict()))+'\n')
                last_memory=time.time()
            if not gate_valid(gate,source):
                if a.package=='B':raise RuntimeError('B_REQUIRES_SAME_VERSION_A_FIRST_WINDOW_GATE')
                for j in gates:
                    base=out/'GATES'/f"{j['seed']}_{j['arm']}";st,p,s=scan(base,children)
                    if st in {'FAILED','INTERRUPTED'}:raise RuntimeError('FIRST_WINDOW_STOP:'+str(base))
                    if st in {'PENDING','RESUMABLE'} and str(base) not in launched:
                        launch(j,base,children,logs,stop=4200.,resume=checkpoint(p) if st=='RESUMABLE' else None);launched.add(str(base))
                result=finish_gate(out,gates,children)
                if result:write(gate,result)
                else:
                    summarize(out,jobs,children,'FIRST_WINDOW_VALIDATION_RUNNING');time.sleep(a.poll);continue
            states=[(j,*scan(out/f"{j['seed']}_{j['arm']}",children)) for j in jobs]
            active=sum(st=='RUNNING' for _,st,_,_ in states)
            for j,st,p,s in states:
                if active>=4 or psutil.virtual_memory().available<2*1024**3:break
                base=out/f"{j['seed']}_{j['arm']}"
                if st not in {'PENDING','RESUMABLE'} or str(base) in launched:continue
                resume=checkpoint(p) if st=='RESUMABLE' else None
                if resume is None and a.package=='A' and j['seed']==4101:
                    gs,gp,_=scan(out/'GATES'/f"{j['seed']}_{j['arm']}",children);assert gs=='COMPLETED';resume=checkpoint(gp)
                launch(j,base,children,logs,resume=resume);launched.add(str(base));active+=1
            rows=summarize(out,jobs,children,'FORMAL_MAIN_RUNNING')
            # Allow retry from new version checkpoint on process interruption;
            # audit/safety exceptions stay FAILED for review, never bypassed.
            for j,st,p,s in states:
                if st=='RESUMABLE':launched.discard(str(out/f"{j['seed']}_{j['arm']}"))
            if all(r['status'] in {'COMPLETED','FAILED','INTERRUPTED'} for r in rows):
                write(out/'FINISHED.json',dict(time=stamp(),all_completed=all(r['status']=='COMPLETED' for r in rows),rows=rows));break
            time.sleep(a.poll)
    finally:
        for log in logs:log.close()
        write(out/'SUPERVISOR_EXIT.json',dict(pid=os.getpid(),time=stamp()))

if __name__=='__main__':main()
