@echo off
cd /d "%~dp0"
python run.py queue --package A --out outputs --detach
pause
