"""Independent process; checkpoint only after causal macro-slot completion."""
from pathlib import Path
from collections import Counter
import argparse,json,os,time,sys,traceback,shutil
import psutil
from formal_common import ROOT,read,write,sha,verify,job_for,dump_checkpoint,load_checkpoint
from src.network_revision.runtime import NetworkExperiment

def compact(c):
    return {k:v for k,v in c.items() if k in {'task_id','decision_s','snapshot_id','model','product','route','feasible','reasons','ground_s','size_mb','energy_j','ready_s','cached_inference','continuation','admission_category','physics_diagnostic','score','guidance','queue_diagnostics'}}

def execute(job,folder,stop=21600.,resume=None,experiment=None,identities=None):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=False)
    started=time.perf_counter();cpu_start=time.process_time();proc=psutil.Process();created=proc.create_time()
    cfgpath=ROOT/'configs/network_revision'/f"{job['variant']}.json"
    if sha(cfgpath)!=job['config_sha256']:raise ValueError('CONFIG_MATRIX_HASH_MISMATCH')
    expected=dict(job=job,manifests=identities or {},python=sys.version)
    previous=None;prior_wall=prior_cpu=0.;count=0;maxrss=0;origin_epoch=time.time()
    if resume:
        meta=read(Path(resume).with_suffix('.json'))
        if meta['identity']!=expected:raise ValueError('CHECKPOINT_VERSION_INPUT_OR_PYTHON_MISMATCH')
        if sha(resume)!=meta['pickle_sha256']:raise ValueError('CHECKPOINT_HASH_MISMATCH')
        e=load_checkpoint(resume,job['method']);previous=Path(meta['candidate_file'])
        if not previous.exists():previous=Path(resume).parent.parent/'candidates.jsonl'
        prior_wall=meta['status']['active_wall_s'];prior_cpu=meta['status']['cpu_s'];maxrss=meta['status']['peak_rss_bytes']
        origin_epoch=meta['status'].get('original_start_epoch',origin_epoch)
        count=meta['candidate_count']
    else:e=experiment or NetworkExperiment(ROOT,job['variant'],job['method'],trace=False)
    if e.variant!=job['variant'] or e.method!=job['method']:raise ValueError('RESUME_METHOD_MISMATCH')
    e.fast_nonpositive_bound=True
    if e.method=='B1':
        e.compact_b1_forecast=True
        e.b1_canonical_safety=True
        e.b1_idle_tail_certificate=True
        e.b1_completed_prefix_certificate=True
        e.b1_singleton_prefix_certificate=True
        e.b1_singleton_bound_certificate=True
        e.physics.kernel.whole_bit_search_certificate=True
    write(folder/'IDENTITY.json',dict(**expected,command=[sys.executable,*sys.argv],root=str(ROOT),start_epoch=time.time(),resume=str(resume),resume_at_s=e.physics.now,pid=os.getpid(),process_created=created,
        threads={k:os.environ.get(k) for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']},
        ground_processing=e.physics.ground_processing,
        computational_policy='V6_SAFETY_UNCHANGED_COMPACT_FORECAST_GROUND_PARALLEL_V1' if e.method=='B1' else 'OFFLOAD_ORIGINAL_SELECTION_GROUND_PARALLEL_V1'))
    candidate_path=folder/'candidates.jsonl'
    with candidate_path.open('wb') as f:
        if previous:
            left=meta['candidate_bytes']
            with previous.open('rb') as source:
                while left:
                    data=source.read(min(left,1024*1024))
                    if not data:raise ValueError('TRUNCATED_CHECKPOINT_CANDIDATE_PREFIX')
                    f.write(data);left-=len(data)
    candidates=candidate_path.open('ab');statuslog=(folder/'status.jsonl').open('a',encoding='utf-8')
    last_checkpoint=time.perf_counter()
    checkpoints={4200,21600}
    def status(phase,task=None):
        nonlocal maxrss
        mem=proc.memory_info();maxrss=max(maxrss,mem.rss,getattr(mem,'peak_wset',0))
        s=dict(phase=phase,arm=job['arm'],method=job['method'],seed=job['seed'],pid=os.getpid(),process_created=created,updated_epoch=time.time(),
            time_s=e.physics.now,arrivals=len(e.arrived),closed=len(e.closed),decisions=len(e.decisions),candidates=count,
            active_wall_s=prior_wall+time.perf_counter()-started,total_wall_s=time.time()-origin_epoch,original_start_epoch=origin_epoch,
            cpu_s=prior_cpu+time.process_time()-cpu_start,rss_bytes=mem.rss,peak_rss_bytes=maxrss,task_id=task)
        write(folder/'STATUS.json',s);statuslog.write(json.dumps(s)+'\n');statuslog.flush();return s
    original=e.decide
    def decide(task,**kw):
        nonlocal count
        status('DECIDING',task.task_id);result=original(task,**kw)
        for row in e.candidates:candidates.write((json.dumps(compact(row),ensure_ascii=False,allow_nan=False)+'\n').encode('utf-8'))
        count+=len(e.candidates);e.candidates.clear();candidates.flush()
        return result
    def checkpoint(exp,slot):
        nonlocal last_checkpoint
        status('RUNNING')
        scheduled=exp.physics.now in checkpoints or exp.physics.now==stop
        if not scheduled and time.perf_counter()-last_checkpoint<600.:return
        label=f'T{round(exp.physics.now):05d}';dest=folder/'CHECKPOINTS';dest.mkdir(exist_ok=True)
        path=dest/(label+'.pkl');dump_checkpoint(exp,path)
        s=status('CHECKPOINT_COMPLETE');m=dict(identity=expected,time_s=exp.physics.now,pickle_sha256=sha(path),candidate_count=count,candidate_file=str(candidate_path),candidate_bytes=candidates.tell(),status=s)
        write(path.with_suffix('.json'),m);write(folder/'LATEST_CHECKPOINT.json',dict(path=str(path.relative_to(folder)),metadata=str(path.with_suffix('.json').relative_to(folder))))
        last_checkpoint=time.perf_counter()
        if scheduled:print(f"{job['arm']} seed={job['seed']} t={exp.physics.now:.0f} arrived={len(exp.arrived)} closed={len(exp.closed)} wall={s['active_wall_s']:.1f}s",flush=True)
    e.decide=decide;e.slot_complete_hook=checkpoint
    try:
        status('STARTED');e.run(stop,full_scope='formal' if stop==e.config['horizon_s'] else None)
        e.save(folder/'RESULT')
        from formal_audit import audit
        result=audit(e,job,folder/'RESULT',candidate_path,require_all=(stop==21600.))
        write(folder/'AUDIT.json',result)
        if not result['pass']:raise ValueError('RESULT_AUDIT_FAILED:'+str(result['failures']))
        write(folder/'COMPLETED.json',status('COMPLETED'))
        return e
    except BaseException as error:
        write(folder/'FAILED.json',dict(status=status('FAILED'),error=repr(error),traceback=traceback.format_exc()))
        try:e.save(folder/'FAILED_PARTIAL')
        except BaseException:pass
        raise
    finally:candidates.close();statuslog.close()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,required=True);ap.add_argument('--arm',required=True);ap.add_argument('--out',required=True);ap.add_argument('--resume');ap.add_argument('--stop',type=float,default=21600.)
    a=ap.parse_args();ids=verify();execute(job_for(a.seed,a.arm),a.out,stop=a.stop,resume=a.resume,identities=ids)
if __name__=='__main__':main()
