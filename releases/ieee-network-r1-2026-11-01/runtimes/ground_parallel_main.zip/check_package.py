"""Read-only package verification plus tiny receipt/DDL sanity, no simulation."""
import run
from pathlib import Path
from formal_common import verify,read,ROOT,sha
from src.network_revision.physics import ground_receipt
def main():
 ids=verify();matrix=read(ROOT/'RUN_MATRIX.json');jobs=matrix['jobs']
 assert len(jobs)==10 and len({(j['seed'],j['arm']) for j in jobs})==10
 assert sum(j['package']=='A' for j in jobs)==sum(j['package']=='B' for j in jobs)==5
 for j in jobs:
  cfg=read(ROOT/'configs/network_revision'/f"{j['variant']}.json")
  assert cfg['ground_processing']['policy']=='independent_fixed' and cfg['ground_processing']['service_s']==4.29
  assert cfg['horizon_s']==21600. and sha(ROOT/'configs/network_revision'/f"{j['variant']}.json")==j['config_sha256']
 p={'policy':'independent_fixed','service_s':4.29};pending=[]
 for i in range(1600):
  r,f=ground_receipt(10.,dict(product_id=str(i),task_id=str(i),product='roi_context',route='GROUND',ground_s=4.29,q=.82,model='high_accuracy',deadline_s=14.29),pending,999.,processing=p)
  assert r['ground_available_s']==14.29 and r['ground_start_s']==10 and r['valid'] and f==999.;pending.append(r)
 print('CHECK_ONLY PASS: source/input/config hashes, disjoint5+5 matrix, independent4.29s, no full simulation.',ids)
if __name__=='__main__':main()
