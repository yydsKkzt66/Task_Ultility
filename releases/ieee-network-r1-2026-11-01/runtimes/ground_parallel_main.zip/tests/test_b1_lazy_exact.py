from copy import deepcopy
from dataclasses import replace
import pytest
from test_b1_exact_service_cache import multi

@pytest.mark.parametrize('fifo',[False,True])
@pytest.mark.parametrize('unsafe_count',[0,1,3,5])
def test_rank_then_filter_matches_exhaustive_including_all_unsafe(fifo,unsafe_count):
    results=[]
    for lazy in [False,True]:
        e=multi();e.b1_exhaustive_safety=not lazy
        if fifo:e.b1.cfg=replace(e.b1.cfg,policy='fifo')
        for i,t in enumerate(e.arrived.values()):t.task_value=1.+i
        calls=[];original=e.physics.project
        def project(**kw):
            tid=kw['order'][0].task_id;calls.append(tid)
            if int(tid[-1])<unsafe_count:return dict(safe=False,finishes={})
            return original(**kw)
        # Different sizes ensure these deliberately task-specific synthetic
        # safety outcomes cannot hit the equal-physical-product memo.
        e.physics.order=[replace(x,remaining_bits=x.remaining_bits+i) for i,x in enumerate(e.physics.order)]
        e.physics.project=project
        order=e.b1_service_order(20.)
        chosen=[x.product_id for x in order if x.ready_time_s<=e.physics.now]
        results.append((chosen,len(calls),e.b1_trace,e.b1.no_fit_count))
    assert results[0][0]==results[1][0] and results[0][3]==results[1][3]
    assert results[1][1]<=results[0][1]
    for a,b in zip(results[0][2],results[1][2]):
        assert a['score']==b['score'] and a['task_id']==b['task_id']
        assert b['reason']=='NOT_TESTED_LOWER_RANK' or a['reason']==b['reason']
    if unsafe_count==5:assert not results[1][0] and results[1][1]==5

def test_lower_candidates_not_reported_as_safety_passes():
    e=multi();e.b1_exhaustive_safety=False;e.b1_service_order(20.)
    assert sum(t['reason']=='candidate' for t in e.b1_trace)==1
    assert sum(t['reason']=='NOT_TESTED_LOWER_RANK' for t in e.b1_trace)==4
