from copy import copy,deepcopy
from dataclasses import replace
import pytest
from test_network_revision_runtime import experiment,authorize_mechanism,interval
from src.network_revision.b1_singleton_certificate import certify_singleton
from src.link.event_queue_runtime_v3 import ComputeIntervalV3


@pytest.mark.parametrize('size',[.8,6.,12.])
@pytest.mark.parametrize('start',[0.,.31,10.])
def test_positive_bound_matches_exact_finish_and_covers_exact_temperature(size,start):
    e,t=experiment(method='B1',links=[interval(0.,20.,rate=8e6),interval(20.,40.,rate=4e6),interval(40.,60.,rate=8e6)])
    p=e.physics;p.execute(start)
    plan=authorize_mechanism(e,t,route='B1',size=size,infer_s=0.,infer_j=0.,encoding_s=0.,encoding_j=0.)
    item=replace(plan['item'],deadline_s=60.)
    proof=certify_singleton(p.kernel,p.state,p.soc,item,60.,60.)
    assert proof is not None
    exact=p.project(order=(item,),end_s=60.)
    assert exact['safe'] and exact['finishes'][item.product_id]==proof['finish_s']
    assert not proof['actual_trajectory']
    for row in exact['trajectory']:
        for n,value in row['thermal']['peaks_c'].items():
            assert value<=max(proof['prefix']['upper_peaks_c'][n],proof['tail']['upper_peaks_c'][n])+1e-8


def test_pending_compute_dependencies_and_bad_thermal_state_fail_closed():
    e,t=experiment(method='B1');p=e.physics
    plan=authorize_mechanism(e,t,route='B1',size=.8,infer_s=0.,infer_j=0.,encoding_s=0.,encoding_j=0.)
    item=replace(plan['item'],deadline_s=60.)
    args=(p.kernel,p.state,p.soc,item,60.,60.)
    assert certify_singleton(*args,work=(ComputeIntervalV3('c','t','inference',1.,4.,10.),)) is None
    assert certify_singleton(p.kernel,p.state,p.soc,replace(item,dependencies=('x',)),60.,60.) is None
    bad=replace(p.state,temperatures_c=(100.,100.,100.,100.))
    assert certify_singleton(p.kernel,bad,p.soc,item,60.,60.) is None


@pytest.mark.parametrize('enabled',[True,False])
@pytest.mark.parametrize('rf',[16.,64.99,65.])
@pytest.mark.parametrize('deadline',[2.,60.])
def test_original_scheduler_selection_and_trace_with_fallback(monkeypatch,enabled,rf,deadline):
    from src.network_revision import b1_singleton_certificate
    e,t=experiment(method='B1');authorize_mechanism(e,t,route='B1',size=.8,infer_s=0.,infer_j=0.,encoding_s=0.,encoding_j=0.)
    e.physics.state=replace(e.physics.state,temperatures_c=(43.,24.,rf,16.))
    e.physics.order=[replace(x,deadline_s=deadline) for x in e.physics.order]
    t.deadline_time_s=deadline
    e.b1_canonical_safety=True;e.b1_idle_tail_certificate=True
    other=copy(e);other.physics=deepcopy(e.physics);other.b1=deepcopy(e.b1);other.b1_trace=[]
    other.b1_singleton_bound_certificate=True
    if not enabled:monkeypatch.setattr(b1_singleton_certificate,'certify_singleton',lambda *a,**kw:None)
    assert e.b1_service_order(20.)==other.b1_service_order(20.)
    assert e.b1_trace==other.b1_trace and e.physics.identity()==other.physics.identity()
