from types import SimpleNamespace as NS
from test_network_revision_runtime import experiment,interval,authorize_mechanism

def fixture():
    e,t=experiment('B1',links=[interval(0,20),interval(20,60,0)])
    plan=authorize_mechanism(e,t,product='roi_context',size=4.,route='B1',infer_s=0.,infer_j=0.,encoding_s=0.,encoding_j=0.)
    e.b1_service_order(20.)
    target=NS(task=t)
    return e,t,plan['item'].product_id,target

def test_b1_checks_tail_without_relaxing_service_endpoint():
    e,t,pid,target=fixture();calls=[]
    old=e.physics.project(order=tuple(e.physics.order),end_s=20.)
    assert old['safe'] and old['finishes'][pid]==4.
    e.physics.project=lambda **kw:old
    def tail(**kw):
        calls.append(kw)
        return dict(safe=False)
    e.physics.kernel.project=tail
    e.b1_service_order(20.)  # Rebuild callback for the new immutable input fixture.
    assert not e.b1._hard_safety_feasible(target)
    assert calls[-1]['end_s']==60.
    assert calls[-1]['order']==()
    assert calls[-1]['completed']=={}
    assert not e.b1._hard_safety_feasible(target)
    assert len(calls)==1  # Exact same physical tail, no repeated deserialization.

def test_b1_safe_completion_in_window_still_accepted_and_pure():
    e,t,pid,target=fixture();before=e.physics.identity()
    assert e.b1._hard_safety_feasible(target)
    assert before==e.physics.identity()

def test_b1_later_window_completion_not_admitted():
    e,t,pid,target=fixture()
    e.physics.project=lambda **kw:dict(safe=True,finishes={pid:40.})
    e.b1_service_order(20.)  # New immutable callback after replacing the projector.
    assert not e.b1._hard_safety_feasible(target)

def test_b1_original_deadline_still_limits_service():
    e,t,pid,target=fixture()
    # Before the original window end, but beyond this product's DDL.
    from dataclasses import replace
    e.physics.order=[replace(e.physics.order[0],deadline_s=2.)]
    e.physics.project=lambda **kw:dict(safe=True,finishes={pid:4.})
    e.b1_service_order(20.)
    assert not e.b1._hard_safety_feasible(target)

def test_empty_tail_completed_identity_does_not_change_physics_or_accounting():
    e,t,pid,target=fixture();p=e.physics;before=p.identity()
    first=p.project(order=tuple(p.order),end_s=20.)
    args=dict(thermal_state=first['state'],soc=first['soc'],order=(),
        work=p.projection_work(p.work),end_s=60.,bill=False,
        window_transmitted_bits=first['transmitted_by_window'])
    a=p.kernel.project(completed=first['completed'],**args)
    b=p.kernel.project(completed={},**args)
    for k in ['state','soc','safe','trajectory','flows','peaks_c','remaining','transmitted_by_window']:
        assert a[k]==b[k]
    assert not b['flows'] and before==p.identity()
