from copy import deepcopy
from dataclasses import replace
import pytest
from test_network_revision_runtime import experiment,authorize_mechanism,interval


@pytest.mark.parametrize('rf',[45.,63.,64.99,65.])
@pytest.mark.parametrize('start',[0.,.1234567,9380.1234567])
def test_whole_bit_search_matches_all_40_iterations_exactly(rf,start):
    e,t=experiment(method='B1',links=[interval(start,start+60.,rate=8e5)])
    p=e.physics;p.state=replace(p.state,time_s=start,temperatures_c=(43.,24.,rf,16.))
    t.deadline_time_s=start+60.
    plan=authorize_mechanism(e,t,route='B1',size=12.,infer_s=0.,infer_j=0.,encoding_s=0.,encoding_j=0.)
    other=deepcopy(p);other.kernel.whole_bit_search_certificate=True
    old=p.project(end_s=start+60.);fast=other.project(end_s=start+60.)
    assert old==fast
    assert p.identity()==other.identity()


def test_non_tx_prefix_and_unsafe_compute_are_unchanged():
    e,t=experiment(method='B1');p=e.physics
    p.state=replace(p.state,temperatures_c=(53.89,45.,64.99,30.))
    authorize_mechanism(e,t,route='B1',size=.8,infer_s=10.,infer_j=1000.)
    other=deepcopy(p);other.kernel.whole_bit_search_certificate=True
    old=p.project(end_s=60.);fast=other.project(end_s=60.)
    assert not old['safe'] and old==fast
