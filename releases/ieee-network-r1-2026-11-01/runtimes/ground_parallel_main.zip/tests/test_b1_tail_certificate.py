from dataclasses import replace
from copy import deepcopy
import pytest
from test_b1_exact_service_cache import multi
from src.network_revision.b1_tail_certificate import certify_idle_tail
from src.link.event_queue_runtime_v3 import ComputeIntervalV3

@pytest.mark.parametrize('temperature',[(43.,24.,16.,16.),(47.,27.8,19.5,19.5),
    (46.,26.3,63.18,20.3),(53.89,29.9,64.99,29.9),(44.,28.,65.,21.),(47.,29.,64.,24.)])
@pytest.mark.parametrize('duration',[60.,1800.])
def test_certificate_never_certifies_unsafe_and_bounds_full_kernel(temperature,duration):
    e=multi();p=e.physics
    p.kernel.links=tuple(replace(x,end_s=duration) for x in p.kernel.links[:1])
    state=replace(p.state,temperatures_c=temperature)
    before=p.identity()
    bound=certify_idle_tail(p.kernel,state,.9,duration,())
    truth=p.kernel.project(thermal_state=state,soc=.9,order=(),completed={},work=(),end_s=duration,bill=False)
    if bound is not None:
        assert truth['safe']
        for segment in truth['trajectory']:
            for node,peak in segment['thermal']['peaks_c'].items():
                assert peak<=bound['upper_peaks_c'][node]+1e-7
    assert p.identity()==before

def test_safe_idle_tail_does_certify():
    e=multi();p=e.physics
    c=certify_idle_tail(p.kernel,p.state,.9,60.,())
    assert c is not None and not c['actual_trajectory']

def test_future_compute_never_skipped():
    e=multi();p=e.physics
    work=(ComputeIntervalV3('future','task','inference',10.,12.,20.),)
    assert certify_idle_tail(p.kernel,p.state,.9,60.,work) is None

def test_low_battery_falls_back_even_if_solar_would_help():
    e=multi();p=e.physics
    assert certify_idle_tail(p.kernel,p.state,.55,60.,()) is None

def test_acquisition_falls_back():
    e=multi();p=e.physics
    p.kernel.links=tuple(replace(x,scene_id='synthetic',scene_dc_power_w=1100.,scene_heat_power_w=1100.) for x in p.kernel.links)
    assert certify_idle_tail(p.kernel,p.state,.9,60.,()) is None

def test_calendar_gap_falls_back():
    e=multi();p=e.physics
    p.kernel.links=tuple(replace(x,start_s=x.start_s+1.) for x in p.kernel.links)
    assert certify_idle_tail(p.kernel,p.state,.9,60.,()) is None

@pytest.mark.parametrize('temperature',[15.,25.,29.8])
@pytest.mark.parametrize('deadline',[2.,18.,45.])
def test_selection_and_physical_state_match_numerical_tail(temperature,deadline):
    selections=[]
    for enabled in (False,True):
        e=multi();e.b1_canonical_safety=True;e.b1_idle_tail_certificate=enabled
        e.physics.state=replace(e.physics.state,temperatures_c=(temperature+4.,temperature,temperature,temperature))
        e.physics.order=[replace(x,deadline_s=deadline+i*.13) for i,x in enumerate(e.physics.order)]
        for x in e.physics.order:e.arrived[x.task_id].deadline_time_s=x.deadline_s
        before=e.physics.identity();order=e.b1_service_order(20.)
        assert e.physics.identity()==before
        selections.append([x.product_id for x in order if x.ready_time_s<=e.physics.now])
    assert selections[0]==selections[1]
