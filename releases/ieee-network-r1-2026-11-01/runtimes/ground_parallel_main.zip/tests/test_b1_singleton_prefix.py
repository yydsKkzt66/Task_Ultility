from dataclasses import replace
import pytest
from test_network_revision_runtime import experiment, authorize_mechanism, interval


def quote(e, item, *, prefix=False, work=None, **kw):
    p=e.physics
    return p.kernel.project(thermal_state=p.state,soc=p.soc,order=(item,),completed={},
        work=p.projection_work(p.work) if work is None else work,end_s=60.,bill=False,
        stop_when_single_complete=prefix,**kw)


def test_singleton_prefix_preserves_exact_sent_bytes_and_physical_prefix():
    e,t=experiment(method='B1')
    plan=authorize_mechanism(e,t,route='B1',size=.8,infer_s=0.,infer_j=0.,encoding_s=.1,encoding_j=.01)
    item=plan['item']
    full=quote(e,item)
    short=quote(e,item,prefix=True)
    assert full['safe'] and short['safe']
    finish=short['finishes'][item.product_id]
    assert finish==full['finishes'][item.product_id]<60.
    assert short['state'].time_s==finish
    assert short['flows']==full['flows']
    assert short['trajectory']==full['trajectory'][:len(short['trajectory'])]
    assert 'REQUIRES_SEPARATE_TAIL_SAFETY' in short['reason']


def test_unfinished_product_still_predicts_to_original_end():
    e,t=experiment(method='B1',links=[interval(0.,60.,rate=8e3)])
    plan=authorize_mechanism(e,t,route='B1',size=2.,infer_s=0.,infer_j=0.,encoding_s=.1,encoding_j=.01)
    full=quote(e,plan['item']);short=quote(e,plan['item'],prefix=True)
    assert short==full


def test_prefix_cannot_be_used_for_billing_or_reserved_service():
    e,t=experiment(method='B1');plan=authorize_mechanism(e,t)
    p=e.physics
    with pytest.raises(ValueError,match='DETACHED'):
        p.kernel.project(thermal_state=p.state,soc=p.soc,order=(plan['item'],),completed={},
            work=(),end_s=60.,bill=True,stop_when_single_complete=True)
    with pytest.raises(ValueError,match='DETACHED'):
        quote(e,plan['item'],prefix=True,reserved_slices=(('other',0.,10.),))


def test_existing_certificate_rejects_unfinished_future_compute():
    from src.link.event_queue_runtime_v3 import ComputeIntervalV3
    from src.network_revision.b1_tail_certificate import certify_idle_tail
    e,t=experiment(method='B1')
    future=(ComputeIntervalV3('pending','other','inference',20.,25.,10.),)
    assert certify_idle_tail(e.physics.kernel,e.physics.state,e.physics.soc,60.,future) is None


@pytest.mark.parametrize('certificate_enabled',[True,False])
def test_service_selection_matches_original_with_certificate_or_fallback(monkeypatch,certificate_enabled):
    from copy import copy,deepcopy
    from src.network_revision import b1_tail_certificate
    e,t=experiment(method='B1');authorize_mechanism(e,t,route='B1',size=.8,infer_s=0.,infer_j=0.,encoding_s=0.,encoding_j=0.)
    e.b1_canonical_safety=True;e.b1_idle_tail_certificate=True
    other=copy(e);other.physics=deepcopy(e.physics);other.b1=deepcopy(e.b1);other.b1_trace=[]
    if not certificate_enabled:monkeypatch.setattr(b1_tail_certificate,'certify_idle_tail',lambda *a,**kw:None)
    original=e.b1_service_order(20.)
    other.b1_singleton_prefix_certificate=True
    actual=other.b1_service_order(20.)
    assert actual==original
    assert other.physics.identity()==e.physics.identity()
    assert other.b1_trace==e.b1_trace
