from dataclasses import replace
import pytest
from test_b1_exact_service_cache import multi
from src.network_revision.b1_tail_certificate import certify_idle_tail

@pytest.mark.parametrize('initial',[(44.05,28.30,43.65,22.54),(47.,27.,60.,23.),(53.8,29.8,64.9,29.8)])
@pytest.mark.parametrize('heat',[20.,30.])
def test_piecewise_bound_controls_full_original_kernel(initial,heat):
    e=multi();p=e.physics
    p.kernel.links=tuple(replace(p.kernel.links[1],start_s=i*1200.,end_s=(i+1)*1200.,
        absorbed_external_w=heat if i%2==0 else 0.,solar_power_w=15. if i%2==0 else 0.) for i in range(8))
    state=replace(p.state,temperatures_c=initial)
    bound=certify_idle_tail(p.kernel,state,.8,9600.,())
    truth=p.kernel.project(thermal_state=state,soc=.8,order=(),completed={},work=(),end_s=9600.,bill=False)
    if bound is not None:
        assert truth['safe']
        for segment in truth['trajectory']:
            assert all(v<=bound['upper_peaks_c'][n]+1e-7 for n,v in segment['thermal']['peaks_c'].items())
        assert all(v<=u+1e-7 for v,u in zip(truth['state'].temperatures_c,bound['upper_terminal_c']))
