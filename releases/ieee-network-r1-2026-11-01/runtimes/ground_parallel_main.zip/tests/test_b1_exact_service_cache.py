from copy import deepcopy
from dataclasses import replace
from test_network_revision_runtime import experiment,interval,authorize_mechanism

def multi():
    e,t=experiment('B1',links=[interval(0,20),interval(20,60,0)])
    e.b1_exhaustive_safety=True
    for i in range(5):
        task=deepcopy(t);task.task_id='equal'+str(i);task.deadline_time_s=40.+i
        e.arrived[task.task_id]=task
        authorize_mechanism(e,task,product='roi_context',size=4.,route='B1',infer_s=0.,infer_j=0.,encoding_s=0.,encoding_j=0.)
    return e

def count_calls(e):
    calls=[];old=e.physics.project
    def quoted(**kw):calls.append(kw);return old(**kw)
    e.physics.project=quoted
    return calls

def test_equal_physical_products_share_safe_boolean_keep_all_trace():
    e=multi();calls=count_calls(e);before=e.physics.identity()
    selected=e.b1_service_order(20.)
    assert len(calls)==1 and len(e.b1_trace)==5
    assert before==e.physics.identity()
    assert sum(x.ready_time_s==0 for x in selected)==1
    assert all(r['reason']=='candidate' for r in e.b1_trace)

def test_different_remaining_bits_deadline_or_readiness_never_merged():
    e=multi();p=e.physics
    p.order[1]=replace(p.order[1],remaining_bits=p.order[1].remaining_bits-1)
    p.order[2]=replace(p.order[2],deadline_s=2.)
    p.order[3]=replace(p.order[3],ready_time_s=5e-10)
    calls=count_calls(e);e.b1_service_order(20.)
    assert len(calls)==4
    assert next(r for r in e.b1_trace if r['task_id']=='equal2')['reason']=='blocked_by_hard_safety'

def test_dependencies_and_previously_completed_ids_bypass_cache():
    e=multi();p=e.physics
    p.order[1]=replace(p.order[1],dependencies=('missing',))
    p.completed[p.order[2].product_id]=0.
    calls=count_calls(e);e.b1_service_order(20.)
    assert len(calls)==3
    assert next(r for r in e.b1_trace if r['task_id']=='equal1')['reason']=='blocked_by_hard_safety'

def test_cache_lifetime_is_one_immutable_service_selection():
    e=multi();calls=count_calls(e);e.b1_service_order(20.);e.b1_service_order(20.)
    assert len(calls)==2

def test_equal_physical_products_share_unsafe_boolean():
    e=multi();calls=[]
    def unsafe(**kw):calls.append(kw);return dict(safe=False,finishes={})
    e.physics.project=unsafe;e.b1_service_order(20.)
    assert len(calls)==1 and len(e.b1_trace)==5
    assert all(r['reason']=='blocked_by_hard_safety' for r in e.b1_trace)
