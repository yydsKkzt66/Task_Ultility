from dataclasses import replace
import pytest
from test_b1_exact_service_cache import multi
from src.network_revision.b1_tail_certificate import certify_idle_tail

@pytest.mark.parametrize('soc',[.56,.80,.999])
def test_long_idle_solar_tail_uses_original_battery_and_bounds_truth(soc):
    e=multi();p=e.physics;end=21600.
    p.kernel.links=(replace(p.kernel.links[0],start_s=0.,end_s=end,solar_power_w=15.,business_rate_bit_s=0.,tx_dc_power_w=0.),)
    bound=certify_idle_tail(p.kernel,p.state,soc,end,())
    assert bound is not None
    truth=p.kernel.project(thermal_state=p.state,soc=soc,order=(),completed={},work=(),end_s=end,bill=False)
    assert truth['safe']
    assert min([soc]+[r['battery']['soc_after'] for r in truth['trajectory']])>=bound['soc_lower']
    for segment in truth['trajectory']:
        assert all(v<=bound['upper_peaks_c'][n]+1e-7 for n,v in segment['thermal']['peaks_c'].items())

def test_eclipse_before_solar_cannot_be_hidden_by_final_recharge():
    e=multi();p=e.physics
    p.kernel.links=(replace(p.kernel.links[0],end_s=12000.,solar_power_w=0.,business_rate_bit_s=0.,tx_dc_power_w=0.),
        replace(p.kernel.links[1],start_s=12000.,end_s=21600.,solar_power_w=100.,business_rate_bit_s=0.,tx_dc_power_w=0.))
    assert certify_idle_tail(p.kernel,p.state,.56,21600.,()) is None

def test_solar_clipping_does_not_bank_excess_for_later_eclipse():
    e=multi();p=e.physics
    p.kernel.links=(replace(p.kernel.links[0],end_s=1000.,solar_power_w=1000.,business_rate_bit_s=0.,tx_dc_power_w=0.),
        replace(p.kernel.links[1],start_s=1000.,end_s=100000.,solar_power_w=0.,business_rate_bit_s=0.,tx_dc_power_w=0.))
    assert certify_idle_tail(p.kernel,p.state,.8,100000.,()) is None
