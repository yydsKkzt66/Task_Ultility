from copy import deepcopy
from pathlib import Path
import math
import pytest
from formal_common import ROOT,sha,job_for,read
from formal_worker import execute
from src.network_revision.physics import ground_receipt,NetworkPhysics
from src.network_revision.runtime import NetworkExperiment
from src.network_revision.policy import choose_offload
from test_network_revision_runtime import experiment,interval,authorize_mechanism,action

POLICY={'policy':'independent_fixed','service_s':4.29,'receive_capacity':'nonbinding','version':'GROUND_PARALLEL_V1'}

def info(pid='a',route='B1',deadline=100.):
    return dict(product_id=pid,task_id=pid,product='roi_context',route=route,q=.82,
                model='high_accuracy',ground_s=4.29,deadline_s=deadline)

def test_many_simultaneous_receipts_have_no_queue_or_overflow():
    pending=[];free=900.
    for i in range(1600):
        row,after=ground_receipt(10.,info(str(i)),pending,free,processing=POLICY)
        assert row['ground_start_s']==10. and row['ground_available_s']==14.29 and after==free
        pending.append(row)
    assert len(pending)==1600

@pytest.mark.parametrize('route',['B1','GROUND'])
def test_deadline_straddles_processing_delay(route):
    good,_=ground_receipt(10.,info(route=route,deadline=14.29),[],0,processing=POLICY)
    bad,_=ground_receipt(10.,info(route=route,deadline=14.28),[],0,processing=POLICY)
    assert good['valid'] and not bad['valid']

@pytest.mark.parametrize('route',['DIRECT','TUT','LOCAL'])
def test_non_ground_routes_unchanged(route):
    x=info(route=route);x['ground_s']=1.87 if route=='TUT' else 0.
    assert ground_receipt(10.,x,[],900.)==ground_receipt(10.,x,[],900.,processing=POLICY)

def test_legacy_serial32_remains_available_only_without_new_config():
    pending=[dict(route='B1',ground_start_s=20.) for _ in range(32)]
    assert ground_receipt(10.,info(),pending,100.)==(None,100.)
    assert ground_receipt(10.,info(),pending,100.,processing=POLICY)[0] is not None

@pytest.mark.parametrize('method',['B1','OFFLOAD'])
def test_forecast_direct_and_execution_match_without_future_receipt_iteration(method):
    e,t=experiment(method);e.physics.ground_processing=deepcopy(POLICY)
    plan=authorize_mechanism(e,t,'roi_context',size=4.,route='B1' if method=='B1' else 'GROUND',ground_s=4.29,
        infer_s=0.,infer_j=0.,encoding_s=0.,encoding_j=0.)
    pid=plan['item'].product_id
    # No sorting/enumeration of unrelated projected receives is needed.
    class GetOnly(dict):
        def items(self):raise AssertionError('serial ground replay was invoked')
    pred={'finishes':GetOnly({pid:4.})}
    assert e.ground_forecast(pred,pid,plan)==8.29
    e.physics.execute(6.)
    assert not e.physics.ground_events and e.physics.ground_pending[0]['ground_available_s']==8.29
    e.physics.execute(10.)
    assert len(e.physics.ground_events)==1 and e.physics.ground_events[0]['ground_available_s']==8.29

def toy(method):
    from test_network_formal6h import scene
    e=scene('GROUND' if method=='B1' else 'OFFLOAD')
    e.physics.ground_processing=deepcopy(POLICY)
    return e

def test_compact_forecast_has_exact_candidate_and_execution_parity():
    slow=toy('B1');fast=toy('B1');fast.compact_b1_forecast=True
    for e in (slow,fast):e.run(120.,full_scope='formal')
    assert slow.physics.identity()==fast.physics.identity()
    assert slow.decisions==fast.decisions and slow.ground_ledger==fast.ground_ledger
    assert slow.candidates==fast.candidates

def test_forecast_clone_retains_live_state_and_separates_all_output_lists():
    e,t=experiment('B1');p=e.physics
    authorize_mechanism(e,t,route='B1',ground_s=4.29)
    p.execute(10.)
    before=p.identity();shadow=p.forecast_clone()
    for name in ('state','soc','work','products','completed','order','ground_pending','ground_free','window_transmitted'):
        assert getattr(shadow,name)==getattr(p,name)
    for name in ('flows','trajectory','events','ground_events','expired','actual_thermal_protection'):
        assert getattr(shadow,name)==[] and getattr(shadow,name) is not getattr(p,name)
    shadow.execute(20.);assert before==p.identity()

@pytest.mark.parametrize('method',['B1','OFFLOAD'])
def test_audited_checkpoint_resume_equal_to_uninterrupted(method,tmp_path):
    arm='GROUND' if method=='B1' else 'OFFLOAD';job=job_for(4101,arm)
    straight=execute(job,tmp_path/'straight',stop=120.,experiment=toy(method),identities={'test':'same'})
    execute(job,tmp_path/'first',stop=60.,experiment=toy(method),identities={'test':'same'})
    resumed=execute(job,tmp_path/'resume',stop=120.,resume=tmp_path/'first/CHECKPOINTS/T00060.pkl',identities={'test':'same'})
    assert straight.physics.identity()==resumed.physics.identity()
    assert straight.decisions==resumed.decisions and straight.ground_ledger==resumed.ground_ledger
    assert read(tmp_path/'resume/AUDIT.json')['pass']

def test_offload_original_path_preference_preserved():
    local=dict(route='LOCAL',feasible=True,ground_s=10.,size_mb=.85,energy_j=60.)
    ground=dict(route='GROUND',feasible=True,ground_s=9.,size_mb=4.,energy_j=90.)
    assert choose_offload([local,ground])[0] is ground
    ground['ground_s']=11.
    assert choose_offload([local,ground])[0] is local
