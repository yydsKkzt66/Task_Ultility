from copy import deepcopy
from dataclasses import replace
import pytest
from test_network_revision_runtime import experiment, interval, authorize_mechanism
from src.link.event_queue_runtime_v3 import ComputeIntervalV3

def setup(enabled=True, size=4., deadline=60.):
    e,t=experiment('B1',links=[interval(0,20),interval(20,60,0)])
    e.b1_canonical_safety=True;e.b1_idle_tail_certificate=True
    e.b1_completed_prefix_certificate=enabled
    t.deadline_time_s=deadline
    plan=e.physics.plan(task_id=t.task_id,model='lightweight',product='roi_context',size_mb=size,
        inference_s=0.,inference_j=0.,encoding_s=0.,encoding_j=0.,deadline_s=deadline,q=.6,route='B1',ground_s=4.29)
    plan['detection_quality']=.6
    return e,t,plan

def test_completed_candidate_waits_for_next_control_and_is_pure():
    e,t,plan=setup();before=e.physics.identity()
    fast=e.b1_projection(plan,60.)
    assert fast['prediction_scope']=='CANDIDATE_COMPLETE_NEXT_CONTROL_AND_CERTIFIED_IDLE_TAIL'
    assert fast['state'].time_s==20.
    assert fast['finishes'][plan['item'].product_id]==4.
    assert e.physics.identity()==before
    e.b1_completed_prefix_certificate=False
    full=e.b1_projection(plan,60.)
    assert full['state'].time_s==60.
    assert fast['finishes']==full['finishes'] and fast['flows']==full['flows']
    assert e.ground_forecast(fast,plan['item'].product_id,plan)==e.ground_forecast(full,plan['item'].product_id,plan)

@pytest.mark.parametrize('size,deadline',[(400.,60.),(4.,2.)])
def test_no_early_stop_without_candidate_completion(size,deadline):
    e,t,plan=setup(size=size,deadline=deadline)
    result=e.b1_projection(plan,deadline)
    assert result['prediction_scope']=='FULL_ORIGINAL_B1_REPLAY'
    assert result['finishes'][plan['item'].product_id] is None

def test_unavailable_certificate_preserves_full_replay(monkeypatch):
    from src.network_revision import b1_tail_certificate
    e,t,plan=setup()
    monkeypatch.setattr(b1_tail_certificate,'certify_idle_tail',lambda *args,**kw:None)
    result=e.b1_projection(plan,60.)
    assert result['prediction_scope']=='FULL_ORIGINAL_B1_REPLAY' and result['state'].time_s==60.

def test_existing_ground_queue_and_next_control_bytes_preserved():
    e,t,plan=setup();other=deepcopy(t);other.task_id='existing';other.task_value=t.task_value*10
    e.arrived[other.task_id]=other
    authorize_mechanism(e,other,product='roi_context',size=4.,route='B1',ground_s=40.,infer_s=0.,infer_j=0.,encoding_s=0.,encoding_j=0.)
    # Re-plan after assigning the existing product, preserving unique IDs.
    plan=e.physics.plan(task_id=t.task_id,model='lightweight',product='roi_context',size_mb=4.,inference_s=0.,inference_j=0.,encoding_s=0.,encoding_j=0.,deadline_s=60.,q=.6,route='B1',ground_s=4.29)
    plan['detection_quality']=.6
    fast=e.b1_projection(plan,60.);e.b1_completed_prefix_certificate=False;full=e.b1_projection(plan,60.)
    assert fast['finishes']==full['finishes'] and fast['flows']==full['flows']
    assert e.ground_forecast(fast,plan['item'].product_id,plan)==e.ground_forecast(full,plan['item'].product_id,plan)
