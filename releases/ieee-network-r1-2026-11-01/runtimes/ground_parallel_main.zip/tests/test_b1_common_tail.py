from copy import deepcopy
from dataclasses import replace
import pytest
from test_b1_exact_service_cache import multi

@pytest.mark.parametrize('temperature',[15.,25.,29.8])
@pytest.mark.parametrize('deadline',[2.,4.,7.,18.,45.])
def test_common_tail_matches_original_selection_and_physics(temperature,deadline):
    results=[]
    for common in (False,True):
        e=multi();e.b1_canonical_safety=common;e.b1_exhaustive_safety=not common
        e.physics.state=replace(e.physics.state,temperatures_c=(temperature+4.,temperature,temperature,temperature))
        e.physics.order=[replace(x,deadline_s=deadline+i*.13) for i,x in enumerate(e.physics.order)]
        for x in e.physics.order:e.arrived[x.task_id].deadline_time_s=x.deadline_s
        before=e.physics.identity();order=e.b1_service_order(20.)
        assert before==e.physics.identity()
        selected=[x.product_id for x in order if x.ready_time_s<=e.physics.now]
        results.append(selected)
    assert results[0]==results[1]

def test_completion_after_original_deadline_is_never_accepted():
    e=multi();e.b1_canonical_safety=True;e.b1_exhaustive_safety=False
    e.physics.order=[replace(x,deadline_s=2.) for x in e.physics.order]
    result=e.b1_service_order(20.)
    assert all(x.ready_time_s>e.physics.now for x in result)

def test_near_boundary_uses_original_predicate():
    e=multi();e.b1_canonical_safety=True;e.b1_exhaustive_safety=True
    original=e.physics.kernel.project;calls=[]
    def project(**kw):
        calls.append(kw['end_s'])
        r=original(**kw)
        if kw['end_s']==60.:
            # A near-limit tail certificate must not be used as a shortcut.
            r['trajectory'][-1]['thermal']['peaks_c']['board']=30.-1e-7
            r['trajectory'][-1]['thermal']['peak_times_s']['board']=59.
        return r
    e.physics.kernel.project=project;e.b1_service_order(20.)
    assert 60. in calls and calls.count(20.)>=2

def test_common_tail_requires_no_dependencies():
    e=multi();e.b1_canonical_safety=True;e.b1_exhaustive_safety=True
    e.physics.order=[replace(x,dependencies=('unavailable',)) for x in e.physics.order]
    order=e.b1_service_order(20.)
    assert all(x.ready_time_s>e.physics.now for x in order)
