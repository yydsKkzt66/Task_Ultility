# 独立源码复核

此目录是运行依赖闭包，不含.git、模型权重或图像数据。安装 requirements_network.txt 后运行：

```powershell
python -m pytest tests/test_network_revision_physics.py tests/test_network_revision_runtime.py tests/test_network_revision_review_regressions.py tests/test_network_incremental.py tests/test_network_incremental_independent.py -q
python scripts/run_network_revision.py --variant incremental --method PROP --stop-s 6220 --output runs/reproduced_prefix_01
```

输出目录已存在会拒绝覆盖。完整周期命令/条件见上层FULL_LIFECYCLE_DECISION.md，不能把本包标为已验收的全天/多seed结果。
同状态案例脚本来自工作树，默认相对工程父目录定位旧状态；完整原始状态/receipt在上层SAME_STATE，旧实际数据在LEGACY_RUN。可直接核查BEFORE_AFTER及CASE_WALKTHROUGH中的数值，无需读原工作区。
