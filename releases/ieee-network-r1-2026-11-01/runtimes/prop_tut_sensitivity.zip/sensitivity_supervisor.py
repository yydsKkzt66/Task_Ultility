"""Persistent one-worker-per-job queue, bounded concurrency, retry exact state."""
from pathlib import Path
import os,sys,time,json,subprocess,ctypes,traceback
import psutil
from formal_common import ROOT,verify,alive,sha
from sensitivity_io import atomic_write,read_retry

def host_memory():
    if os.name=='nt':
        class M(ctypes.Structure):
            _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(k,ctypes.c_ulonglong) for k in ['total','available','commit_total','commit_available','virtual_total','virtual_available','extended']]
        m=M();m.length=ctypes.sizeof(m)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):raise OSError('MEMORY_STATUS_FAILED')
        return m.available,m.commit_available
    m=psutil.virtual_memory();return m.available,m.available

def other_simulations(own_pids):
    active=[];unknown=[]
    for p in psutil.process_iter(['pid','name']):
        if p.pid in own_pids or p.pid==os.getpid() or 'python' not in (p.info['name'] or '').lower():continue
        try:
            command=' '.join(p.cmdline()).lower()
            if ('worker' in command and any(x in command for x in ['formal_','sensitivity_run','run.py'])) or ('critical_entry.py' in command):active.append(p.pid)
        except psutil.Error:unknown.append(p.pid)
    return active,unknown

def main(args):
    assert args.machine in {'A','B'} and 1<=args.max_workers<=5
    out=Path(args.out).resolve();out.mkdir(parents=True,exist_ok=True);ids=verify()
    lock=out/'SUPERVISOR.json'
    if lock.exists() and alive(read_retry(lock)):raise RuntimeError('SUPERVISOR_ALREADY_ACTIVE')
    atomic_write(lock,dict(pid=os.getpid(),process_created=psutil.Process().create_time(),machine=args.machine,command=sys.argv))
    jobs=[j for j in read_retry(ROOT/'SENSITIVITY_MATRIX.json')['jobs'] if j['machine']==args.machine]
    def priority(j):
        if j['condition']=='NORMAL' and j['seed'] in [4101,4103]:return (0,j['seed'],0)
        if j['arm']=='PROP':return (1,j['condition'],j['seed'])
        if j['condition']=='NORMAL':return (2,j['seed'],0)
        return (3,j['condition'],{'GROUND':0,'TUT_ADAPTED':1,'OFFLOAD':2}[j['arm']],j['seed'])
    jobs.sort(key=priority);children={};logs={};finished_signature=None
    def attempts(j):return sorted((out/j['job_id']).glob('attempt_[0-9][0-9]'))
    def state(j):
        aa=attempts(j);child=children.get(j['job_id'])
        if not aa:return ('STARTING' if child and child.poll() is None else 'PENDING'),None,{}
        p=aa[-1];s=read_retry(p/'STATUS.json') if (p/'STATUS.json').exists() else {}
        if (p/'VERIFIED_COMPLETE.json').exists():return 'COMPLETED',p,s
        if alive(s) or (child and child.poll() is None):return 'RUNNING',p,s
        failure=read_retry(p/'FAILED.json') if (p/'FAILED.json').exists() else {}
        text=json.dumps(failure)
        retryable=not failure or any(t in text for t in ['PermissionError','MemoryError','OSError','WinError'])
        if len(aa)<4 and retryable:return 'RESUMABLE',p,s
        return 'FAILED',p,s
    def budget(j):return {'PROP':2.3,'GROUND':.65,'OFFLOAD':.8,'TUT_ADAPTED':.8}[j['arm']]*2**30
    try:
        while True:
            try:
                states=[(j,*state(j)) for j in jobs]
                active=[(j,s) for j,st,p,s in states if st in {'RUNNING','STARTING'}]
                available,commit=host_memory();cpu=psutil.cpu_percent(interval=None)
                external,unreadable=other_simulations({s.get('pid') for j,s in active}|{p.pid for p in children.values()})
                target=max(0,min(args.max_workers,5 if cpu<85. and commit>3.*2**30 else 4)-len(external))
                future=0.
                for j,s in active:
                    used=0.
                    try:
                        proc=psutil.Process(s['pid']);used=getattr(proc.memory_info(),'private',proc.memory_info().rss)
                    except (psutil.Error,KeyError):pass
                    future+=max(0.,budget(j)-used)
                for j,st,p,s in states:
                    if len(active)>=target:break
                    if st not in {'PENDING','RESUMABLE'}:continue
                    if commit-future-budget(j)<1.5*2**30 or available-future-budget(j)<1.5*2**30:continue
                    if st=='RESUMABLE' and s and time.time()-s.get('updated_epoch',0)<30:continue
                    dest=out/j['job_id'];dest.mkdir(exist_ok=True);attempt=dest/f'attempt_{len(attempts(j))+1:02d}'
                    command=[sys.executable,str(ROOT/'sensitivity_run.py'),'worker','--job',j['job_id'],'--machine',args.machine,'--out',str(attempt)]
                    checkpoint=None
                    if p and (p/'LATEST_CHECKPOINT.json').exists():
                        checkpoint=p/read_retry(p/'LATEST_CHECKPOINT.json')['path'];meta=read_retry(checkpoint.with_suffix('.json'))
                        assert sha(checkpoint)==meta['pickle_sha256'],'BAD_CHECKPOINT_SHA'
                        assert meta['identity']['manifests']==ids,'CHECKPOINT_VERSION_MISMATCH'
                        command+=['--resume',str(checkpoint)]
                    log=(dest/(attempt.name+'.log')).open('ab')
                    child=subprocess.Popen(command,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
                    children[j['job_id']]=child;logs[child.pid]=log
                    atomic_write(dest/(attempt.name+'_LAUNCH.json'),dict(command=command,pid=child.pid,process_created=psutil.Process(child.pid).create_time(),epoch=time.time(),resume=str(checkpoint),job=j,manifests=ids))
                    active.append((j,{}));future+=budget(j)
                    print('START',j['job_id'],child.pid,flush=True)
                rows=[]
                for j in jobs:
                    st,p,s=state(j)
                    r=dict(job_id=j['job_id'],condition=j['condition'],method=j['arm'],seed=j['seed'],machine=j['machine'],group=j['group'],status=st,
                        attempt=str(p) if p else None,source_manifest=ids['SOURCE_MANIFEST.json'],config_sha256=j['config_sha256'],input_hashes=j['input_hashes'])
                    r.update({k:s.get(k) for k in ['pid','process_created','time_s','arrivals','closed','active_wall_s','total_wall_s','cpu_s','rss_bytes','peak_rss_bytes']})
                    rows.append(r)
                atomic_write(out/'QUEUE_STATE.json',dict(updated_epoch=time.time(),rows=rows,memory_available_bytes=available,commit_headroom_bytes=commit,
                    max_workers=args.max_workers,target_workers=target,reserved_future_growth_bytes=future,source_manifests=ids,
                    external_simulation_pids=external,unreadable_python_pids=unreadable))
                lines=['# IEEE Network敏感性实验进度',time.strftime('\n更新时间：%Y-%m-%d %H:%M:%S'),
                    f'\n机器{args.machine}；新增敏感性{sum(j["group"]=="sensitivity" for j in jobs)}组；正常参照补齐{sum(j["group"]=="reference_completion" for j in jobs)}组。',
                    f'提交内存余量{commit/2**30:.2f} GiB；物理可用{available/2**30:.2f} GiB；并发上限{args.max_workers}。',
                    '\n|条件|方法|种子|状态|仿真秒|到达|闭环|墙钟秒|CPU秒|RSS MiB|PID|','|---|---|---:|---|---:|---:|---:|---:|---:|---:|---:|']
                fmt=lambda v:'—' if v is None else f'{v:.1f}' if isinstance(v,float) else str(v)
                for r in rows:lines.append('|'+ '|'.join(fmt(v) for v in [r['condition'],r['method'],r['seed'],r['status'],r['time_s'],r['arrivals'],r['closed'],r['active_wall_s'],r['cpu_s'],r['rss_bytes']/2**20 if r['rss_bytes'] else None,r['pid']])+'|')
                lines+=['\n每60秒更新；每小时/窗口结束及180秒活动墙钟间隔保存完整检查点。未完成不填0；B正式任务不在A机运行。','失败保留原目录；仅瞬时IO/内存/进程中断可在相同源码和输入下恢复，科学审计失败不自动重试。']
                md=out/'00_PROGRESS_CN.md';tmp=md.with_suffix('.tmp');tmp.write_text('\n'.join(lines)+'\n',encoding='utf-8');os.replace(tmp,md)
                signature=tuple(r['job_id'] for r in rows if r['status']=='COMPLETED')
                if signature!=finished_signature:
                    from sensitivity_summary import summarize,export_reference_update
                    summarize(out);export_reference_update(out);finished_signature=signature
                for key,child in list(children.items()):
                    if child.poll() is not None:
                        if child.pid in logs:logs.pop(child.pid).close()
                        del children[key]
                if all(r['status'] in {'COMPLETED','FAILED'} for r in rows):
                    atomic_write(out/'QUEUE_FINISHED.json',dict(epoch=time.time(),all_completed=all(r['status']=='COMPLETED' for r in rows)));break
            except Exception:
                # Observation/transient failures must never kill or orphan the
                # queue. Worker failures remain visible in their own directories.
                with (out/'SUPERVISOR_ERRORS.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(dict(epoch=time.time(),traceback=traceback.format_exc()))+'\n')
                print(traceback.format_exc(),flush=True)
            time.sleep(60.)
    finally:
        atomic_write(out/'SUPERVISOR_EXIT.json',dict(epoch=time.time(),pid=os.getpid()))
