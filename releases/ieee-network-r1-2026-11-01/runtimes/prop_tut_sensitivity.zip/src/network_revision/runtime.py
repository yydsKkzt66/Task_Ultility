"""IEEE Network policy bridge to a shared causal physical execution interface."""
from __future__ import annotations
from collections import Counter
from copy import deepcopy, copy
from dataclasses import asdict, replace
from pathlib import Path
from types import SimpleNamespace as NS
import csv, json, math, importlib.util, sys, ast, hashlib, time

from src.network_revision.physics import NetworkPhysics, fingerprint, ground_receipt
from src.network_revision.feedback import ProgressFeedback
from src.network_revision.policy import NetworkController, score, choose_prop, choose_offload, thermal_pressure
from src.network_revision.incremental import IncrementalController, incremental_score, terminal_quote, choose_incremental
from src.link.event_queue_runtime_v3 import EventLinkIntervalV3
from src.routers.decoupled_prop_v2 import build_decoupled_action_rows
from src.routers.requirement_aware_projection import normalize_product, product_satisfies
from src.payload.payload_sizer import estimate_payload_size_with_diagnostics, estimate_payload_encoding_cost, estimate_raw_information_gain
from src.payload.information_sufficiency import delta_information_utility, compute_gross_incremental_utility
from src.payload.information_sufficiency import product_information_utility
from src.payload.staged_delivery_queue import StagedDeliveryRequest, compute_staged_priority, staged_delivery_queue_config
from src.payload.proactive_followup import evaluate_proactive_followup_eligibility
from src.payload.bounded_guarantee_queue import rank_guarantee_aware_requests
from src.link.downlink_queue import DownlinkQueue
from src.models.model_registry import ModelRegistry
from src.common.types import ObservedFeedback
from src.reward.reward_function import compute_reward


def read_csv(p):return list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
def read_json(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write_json(p,data):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(data,ensure_ascii=False,indent=2,default=str,allow_nan=False)+'\n',encoding='utf-8')


def private_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module;spec.loader.exec_module(module);return module


def load_b1_scheduler(path):
    """Load exactly the frozen pure scheduler classes without old simulator.

    AST extraction is verbatim, no body rewriting. Its old hard-safety method
    is explicitly replaced on the instance by the common-kernel predicate.
    """
    from dataclasses import dataclass
    from types import ModuleType
    tree=ast.parse(path.read_text(encoding='utf-8-sig'))
    names={'B1SchedulerConfig','B1ScheduleDecision','ContactAwareCompressedGroundScheduler'}
    nodes=[n for n in tree.body if isinstance(n,ast.ClassDef) and n.name in names]
    assert len(nodes)==3
    module=ModuleType('network_frozen_b1');sys.modules[module.__name__]=module
    module.__dict__.update(dataclass=dataclass,math=math)
    unit=ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0)]+nodes,type_ignores=[])
    exec(compile(ast.fix_missing_locations(unit),str(path),'exec'),module.__dict__)
    return module


def load_inputs(root,variant):
    config=read_json(root/'configs/network_revision'/f'{variant}.json')
    for name,expected in config['input_hashes'].items():
        if hashlib.sha256((root/'network_inputs'/name).read_bytes()).hexdigest()!=expected:
            raise ValueError('FROZEN_INPUT_HASH_MISMATCH:'+name)
    cfg=read_json(root/config['legacy_config']);taskrows=read_csv(root/'network_inputs'/config.get('task_manifest','task_manifest.csv'))
    tasks=[]
    for r in taskrows:
        # Values/requirement/metadata are the frozen arrival manifest, not new
        # outputs or labels. No image or label file is opened by this runner.
        tasks.append(NS(task_id=r['task_id'],task_value=float(r['effective_task_value']),
            calibrated_task_value=float(r['effective_task_value']),value_level=r['value_level'],
            product_requirement=r['product_requirement'],arrival_slot=int(r['arrival_slot']),
            arrival_s=float(r['arrival_time_s']),deadline_s=float(r['deadline_s']),
            deadline_time_s=float(r['deadline_time_s']),difficulty=float(r['difficulty']),
            uncertainty=float(r['uncertainty']),high_value_flag=int(r['high_value_flag']),
            quality_requirement=float(r['quality_requirement']),information_requirement=float(r['information_requirement']),
            emergency_flag=int(r['emergency_flag']),base_prior_score=float(r['base_prior_score']),
            metadata=json.loads(r['metadata_json']),scene_id=r['scene_id']))
    if config.get('business_calendar'):
        calendar=read_json(root/'network_inputs'/config['business_calendar'])
        if calendar['rate_contract']!='EFFECTIVE_BIT_S_CAPACITY_050_ALREADY_APPLIED':
            raise ValueError('UNKNOWN_FROZEN_RATE_CONTRACT')
        links=[EventLinkIntervalV3(**r) for r in calendar['intervals']]
        if links[0].start_s!=0. or links[-1].end_s!=config['horizon_s']:
            raise ValueError('CALENDAR_ENDPOINT_MISMATCH')
        if any(a.end_s!=b.start_s for a,b in zip(links,links[1:])):
            raise ValueError('NONCONTIGUOUS_FROZEN_CALENDAR')
        return config,cfg,sorted(tasks,key=lambda t:(t.arrival_s,t.task_id)),links
    slots=read_csv(root/'network_inputs'/config.get('slot_trace','slot_trace.csv'));solar=read_csv(root/'network_inputs/solar_trace_one_orbit.csv')
    links=[];window=0;was=False
    total_by_window={}
    for i,r in enumerate(slots):
        active=bool(int(r['link__in_contact']))
        if active and not was:window+=1
        was=active;wid=f'legacy_window_{window:03d}' if active else ''
        rate=float(r['link__throughput_mbps'])*1e6*(config['capacity']/config['source_bundle_capacity'])*cfg['simulator']['downlink_efficiency'] if active else 0.
        tx=cfg['simulator']['tx_power_w']*(1+cfg['simulator']['comm_alpha_gamma']*(1-float(r['link__link_quality']))) if active else 0.
        sunrow=solar[i%len(solar)];sunpower=float(sunrow['solar_power_W'])
        # Heat-boundary migration is separate from the unchanged electric solar
        # trace. Use legacy sunlight phase, not R06 orbital geometry/last20s.
        lit=sunrow.get('orbit_phase','').lower() not in {'eclipse','night'}
        heat=config['physics']['absorbed_external_w'][1 if lit else 0]
        links.append(EventLinkIntervalV3(i*20.,(i+1)*20.,rate,tx,sunpower,heat,wid))
        if wid:total_by_window[wid]=total_by_window.get(wid,0.)+rate*20.
    links=[replace(x,window_capacity_bits=total_by_window.get(x.window_id,0.)) for x in links]
    return config,cfg,sorted(tasks,key=lambda t:(t.arrival_s,t.task_id)),links


class NetworkExperiment:
    def __init__(self,root,variant='pressure_fixed',method='PROP',trace=True):
        self.root=Path(root);self.variant=variant;self.method=method;self.trace=trace
        self.config,self.cfg,self.tasks,links=load_inputs(self.root,variant)
        if self.config.get('tut_latency_policy','legacy_proxy') not in {'legacy_proxy','causal_ground'}:
            raise ValueError('INVALID_TUT_LATENCY_POLICY')
        self.incremental=variant.startswith('incremental')
        self.incremental_prop=self.incremental and method=='PROP'
        self.physics=NetworkPhysics(self.config['physics']['network'],self.cfg['simulator'],links)
        self.controller=(IncrementalController(self.cfg,self.config['incremental_pricing'],self.config['public_prices'])
            if self.incremental_prop else NetworkController(self.cfg,'pressure_fixed' if self.incremental else variant))
        self.arrived={};self.arrival_events=[];self.decisions=[];self.candidates=[]
        self.overhead=dict(candidate_seconds=[],controller_seconds=[],decision_seconds=[])
        self.delivered={};self.ground_ledger=[];self.closed={};self.pending={};self.retry_windows=set()
        self.registry=ModelRegistry(self.cfg['model_pool'])
        self.actions=[NS(**a) for a in build_decoupled_action_rows() if a['payload_policy']!='defer']
        # Author-defined ablations act on policy only, never on physical service.
        ablation=self.config.get('ablation',{})
        if set(ablation)-{'allowed_models','allow_progressive','required_product_only'}:raise ValueError('UNKNOWN_ABLATION_SWITCH')
        if ablation and not self.incremental_prop:raise ValueError('ABLATION_REQUIRES_INCREMENTAL_PROP')
        allowed=ablation.get('allowed_models')
        if allowed is not None:
            if not allowed or set(allowed)-{a.model_name for a in self.actions}:raise ValueError('INVALID_ALLOWED_MODELS')
            self.actions=[a for a in self.actions if a.model_name in allowed]
        self.allow_progressive=ablation.get('allow_progressive',True)
        if type(self.allow_progressive) is not bool:raise ValueError('INVALID_PROGRESSIVE_SWITCH')
        self.required_product_only=ablation.get('required_product_only',False)
        if type(self.required_product_only) is not bool:raise ValueError('INVALID_REQUIRED_PRODUCT_SWITCH')
        self.qmap=self.config['q_eff'];self.staged_count_slot={};self.staged_count_window={}
        s=self.cfg['simulator']
        self.queue_policy=DownlinkQueue(queue_max_mb=s['queue_max_mb'],slot_seconds=20.,
            queue_priority_tau_d=s['queue_priority_tau_d'],queue_age_bonus=s['queue_age_bonus'],
            queue_meta_first_bonus=s['queue_meta_first_bonus'],queue_high_value_bonus=s['queue_high_value_bonus'])
        self.same_state=[];self.case_states={};self.staged_requests={};self.staged_trace=[]
        self.proactive_slot_count={};self.proactive_window_count={};self.guarantee_debt={}
        self.feedback=ProgressFeedback(self.cfg['simulator']['guarantee'])
        self.wall_scope='BOUNDED_PREFIX_NOT_FINAL_24H'
        self.tut=None;self.b1=None
        if method=='TUT':
            mod=private_module('network_frozen_tut',self.root/'vendor/frozen_runtime_v1/tut/src/routers/tut_uoi_rate_router.py')
            self.tut=mod.TutUoiRateRouter(product_utility_cfg=self.cfg['product_requirement_utility'])
        if method=='B1':
            mod=load_b1_scheduler(self.root/'vendor/frozen_runtime_v1/b1_offload/src/baselines/b1_enhanced.py')
            self.b1=mod.ContactAwareCompressedGroundScheduler(mod.B1SchedulerConfig())
            self.b1_module=mod;self.b1_waiting=[];self.b1_trace=[]
        self.stopped_reason=None

    def sorted_order(self,extra=()):
        items=list(self.physics.order)+list(extra)
        if self.method in {'OFFLOAD','B1'}:return items  # committed FIFO/non-preemption
        def priority(item):
            task=self.arrived[item.task_id];info=self.physics.products.get(item.product_id,{})
            delta=delta_information_utility(item.product_type,self.delivered.get(item.task_id,set()),task.product_requirement,self.cfg['product_requirement_utility'])
            q=NS(task_id=item.task_id,generated_time_s=info.get('ready_s',item.ready_time_s),
                deadline_time_s=item.deadline_s,remaining_utility=task.task_value*delta,
                remaining_mb=item.remaining_bits/8e6,is_metadata=item.product_type=='metadata',
                is_high_value=bool(task.high_value_flag or task.emergency_flag),
                continue_request_priority_bonus=0.,is_residual=info.get('continuation',False),
                followup_trigger='',metadata={},payload_size_mb=item.remaining_bits/8e6,
                task_value=task.task_value,incremental_utility=delta)
            if info.get('continuation') and item.task_id in self.staged_requests:
                request=deepcopy(self.staged_requests[item.task_id])
                request.timeliness_factor=max(0.,(task.deadline_time_s-self.physics.now)/task.deadline_s)
                return compute_staged_priority(request,current_slot=int(self.physics.now//20),config=self.cfg['simulator'])[0]
            return self.queue_policy._compute_priority(q,self.physics.now)
        return sorted(items,key=lambda x:(-priority(x),x.deadline_s,x.remaining_bits))

    def ground_forecast(self,projection,pid,newplan):
        free=max(self.physics.now,self.physics.ground_free);out={};pending=list(self.physics.ground_pending)
        for tx,id_ in sorted((t,k) for k,t in projection['finishes'].items() if t is not None):
            info=dict(newplan) if id_==pid else self.physics.products[id_]
            if id_==pid:
                item=newplan['item'];info.update(product_id=id_,task_id=item.task_id,product=item.product_type,deadline_s=item.deadline_s)
            row,free=ground_receipt(tx,info,pending,free)
            if row is not None:
                pending.append(row);out[id_]=row['ground_available_s']
        return out.get(pid)

    def b1_projection(self,plan,deadline):
        """Replay the actual B1 scheduling boundary on a detached owner.

        No future arrivals, changed rank, full-fit relaxation, or fictitious
        queue service. The same scheduler is used at each macro/event edge.
        """
        shadow=copy(self);shadow.physics=deepcopy(self.physics);shadow.b1=deepcopy(self.b1)
        shadow.b1_trace=[]
        p=shadow.physics;first_flow=len(p.flows);first_trajectory=len(p.trajectory)
        # Instance-level observer wrappers may close over the live owner;
        # never copy those callables into a detached physical forecast.
        for name in ('project','execute'):
            p.__dict__.pop(name,None)
        p.authorize(plan)
        ids=[x.product_id for x in p.order]
        while p.now<deadline-1e-9:
            end=min(deadline,(math.floor((p.now+1e-9)/20.)+1)*20.,p.kernel.link_at(p.now).end_s)
            order=shadow.b1_service_order(end)
            trial=p.project(end_s=end,order=order)
            if not trial['safe']:return trial
            times=[v for v in trial['finishes'].values() if v is not None and v>p.now+1e-9]
            times += [x.ready_time_s for x in p.order if x.ready_time_s>p.now+1e-9]
            event=min([end]+times);p.execute(event,service_order=order)
        return dict(safe=True,reason='',state=p.state,soc=p.soc,
            flows=p.flows[first_flow:],trajectory=p.trajectory[first_trajectory:],
            finishes={id_:p.completed.get(id_) for id_ in ids},
            remaining={x.product_id:x.remaining_bits for x in p.order})

    def candidate(self,task,action,*,route='DIRECT',continuation=False,decision_context=None):
        p=self.physics;product=action.payload_policy;model=action.model_name
        context={} if decision_context is None else decision_context
        deadline=task.deadline_time_s if self.incremental else min(task.deadline_time_s,self.config['horizon_s'])
        service_end=min(deadline,self.config['horizon_s'])
        q=self.qmap[model];profile=self.registry.get_profile(model)
        size,diag=estimate_payload_size_with_diagnostics(product,task=task,payload_profiles_cfg=self.cfg['payload_profiles'])
        enc_s,enc_j=estimate_payload_encoding_cost(product,size,self.cfg['payload_profiles'])
        inf_s=profile.latency_s;inf_j=profile.estimated_power_w*inf_s;ground_delay=0.
        if continuation and product=='roi_context' and 'roi' in self.delivered.get(task.task_id,set()):
            roi_size,_=estimate_payload_size_with_diagnostics('roi',task=task,payload_profiles_cfg=self.cfg['payload_profiles'])
            roi_s,roi_j=estimate_payload_encoding_cost('roi',roi_size,self.cfg['payload_profiles'])
            size=max(0.,size-roi_size);enc_s=max(0.,enc_s-roi_s);enc_j=max(0.,enc_j-roi_j)
            diag.update(incremental_after_roi=True,already_materialized_roi_mb=roi_size)
        if route in {'GROUND','B1'}:
            raw=next((float(task.metadata[k]) for k in ['raw_payload_mb','raw_size_mb','image_raw_size_mb','source_image_mb'] if k in task.metadata),32.)
            size=raw/8.;inf_s=inf_j=0.;enc_s=11.*raw/32.
            enc_j=enc_s*(1.4 if route=='B1' else 6.8);ground_delay=1.5*raw/32.+2.79
            diag={'payload_size_source':'legacy_compressed_full_image_input_NOT_final_roi_context'}
        elif route=='LOCAL':
            size=.85;enc_s=.153;enc_j=2.04
            diag={'payload_size_source':'legacy_OFFLOAD_fixed_roi_profile'}
        elif self.method=='TUT':
            size={'metadata':.002,'roi':.85,'roi_context':2.7}[product]
            inf_s=1.44;inf_j=21.6;enc_s=.43;enc_j=6.02;ground_delay=1.87;q=.697529100765
        plan=p.plan(task_id=task.task_id,model=model,product=product,size_mb=size,
            inference_s=inf_s,inference_j=inf_j,encoding_s=enc_s,encoding_j=enc_j,
            deadline_s=deadline,q=q,route=route,ground_s=ground_delay)
        plan['continuation']=continuation
        plan['detection_quality']=max(.05,min(1.,profile.quality_base-(1.-profile.robustness)*.35*task.difficulty-.18*task.uncertainty))
        pid=plan['item'].product_id
        if 'snapshot_id' not in context:context['snapshot_id']=p.identity()
        before=context['snapshot_id'];order=self.sorted_order((plan['item'],))
        # Same known-work horizon in a and a0. Once all known work expires,
        # empty-time integration cannot change terminal queue bytes.
        projection_end=(min(self.config['horizon_s'],max([deadline]+[x.deadline_s for x in p.order]))
            if self.incremental_prop else service_end)
        projection=(self.b1_projection(plan,service_end) if route=='B1' else
            p.project(order=order,work=p.work+plan['work'],end_s=projection_end))
        assert before==p.identity(),'PREDICTION_MUTATED_EXECUTION'
        ground=self.ground_forecast(projection,pid,plan)
        reasons=[]
        if not projection['safe']:reasons.append(projection['reason'])
        if plan['ready_s']>service_end:reasons.append('READY_AFTER_SERVICE_ENDPOINT')
        if ground is None or ground>service_end:reasons.append('NO_EXECUTABLE_SERVICE_BEFORE_DEADLINE')
        if ground is None and projection['finishes'].get(pid) is not None:reasons.append('GROUND_QUEUE_OVERFLOW_PREDICTED')
        if route=='LOCAL' and (product_information_utility({'roi'},task.product_requirement,self.cfg['product_requirement_utility'])+1e-9<task.information_requirement or profile.quality_base+1e-9<task.quality_requirement):reasons.append('LOCAL_INFORMATION_OR_QUALITY_REQUIREMENT')
        if route in {'GROUND','B1'} and (1.+1e-9<task.information_requirement or profile.quality_base+1e-9<task.quality_requirement):reasons.append('GROUND_INFORMATION_OR_QUALITY_REQUIREMENT')
        if sum(x.remaining_bits for x in order)/8e6>self.cfg['simulator']['queue_max_mb']:reasons.append('QUEUE_OVERFLOW')
        # Whole-known-schedule physical projection includes committed work;
        # existing IDs are not interpreted as service or ground events.
        tx=sum(f['energy_j'] for f in projection['flows'] if f['product_id']==pid)
        tx_s=sum(f['end_s']-f['start_s'] for f in projection['flows'] if f['product_id']==pid)
        energy=plan['inference_j']+enc_j+tx
        # Old latency calibration remains an online penalty only, separately
        # from causal actual/predicted ground availability.
        active=(0. if plan['cached'] else inf_s)+enc_s+tx_s
        old_queue_proxy=20.*min(sum(x.remaining_bits for x in p.order)/8e6/self.cfg['simulator']['queue_max_mb'],1.)
        legacy_cal=self.cfg['simulator']['shared_calibrated_prior']['latency_calibration']
        # Explicit legacy adapter only. PROP incremental never evaluates the
        # old 1000s latency fee, absolute Qnext fee or Mode action biases.
        tut_causal=self.method=='TUT' and self.config.get('tut_latency_policy','legacy_proxy')=='causal_ground'
        latency=(max(0.,ground-p.now) if ground is not None else active) if self.incremental_prop or tut_causal else legacy_cal['alpha']*(active+old_queue_proxy)+legacy_cal['beta']
        next_control=(math.floor(p.now/20.)+1)*20.
        served_next=sum(f['business_bits']*max(0.,min(next_control,f['end_s'])-f['start_s'])/(f['end_s']-f['start_s'])
            for f in projection['flows'] if f['start_s']<next_control)
        qnext=max(0.,sum(x.remaining_bits for x in order if x.ready_time_s<=next_control)-served_next)/8e6
        pred=NS(predicted_product_type=product,predicted_E_comp=plan['inference_j']+enc_j,
            predicted_E_comm=tx,predicted_L_inf=(0. if plan['cached'] else inf_s)+enc_s,
            predicted_L_comm=tx_s,predicted_L_queue=max(0.,latency-active),
            predicted_Q_next_mb=qnext,predicted_S_gen_mb=size,predicted_B_next=projection['soc'],
            predicted_Theta_next=0. if projection['safe'] else 1.,delivery_success_proxy=float(ground is not None),
            predicted_detection_quality=q,predicted_delivery_factor=float(ground is not None),
            predicted_S_down_mb=size if ground is not None else 0.,predicted_safety_violation=float(bool(reasons)),
            predicted_reward=0.)
        baselines=context.setdefault('baselines',{})
        if projection_end not in baselines:
            baselines[projection_end]=p.project(end_s=projection_end,order=self.sorted_order())
        baseline=baselines[projection_end]  # read-only within one unmutated decision
        baseline_served_next=sum(f['business_bits']*max(0.,min(next_control,f['end_s'])-f['start_s'])/(f['end_s']-f['start_s'])
            for f in baseline['flows'] if f['start_s']<next_control)
        baseline_qnext=max(0.,sum(x.remaining_bits for x in p.order if x.ready_time_s<=next_control)-baseline_served_next)/8e6
        # Window scope starts at the candidate's ready time and ends at the
        # first usable window end (or deadline). Other windows remain available
        # to the feasibility projection, including partial resume.
        future=[x for x in p.kernel.links if x.business_rate_bit_s>0 and x.end_s>max(p.now,plan['ready_s']) and x.start_s<service_end]
        wid=future[0].window_id if future else ''
        window=[x for x in p.kernel.links if wid and x.window_id==wid]
        end=min(service_end,max((x.end_s for x in window),default=service_end))
        # Opt-in computational pruning. Fixed physical forecasts, terminal
        # accounting and feedback opportunities are still evaluated exactly.
        # mu_B >= 0 makes the zero-mu_B score an upper bound. If it cannot
        # clear the same strict threshold, choose_incremental would remove
        # this candidate for every possible executable-window quotation.
        bound=None
        delivered=self.delivered.get(task.task_id,set())
        if self.incremental_prop and getattr(self,'fast_nonpositive_bound',False):
            settings=self.controller.settings
            if settings['a_W']>=0. and self.config['public_prices']['downlink_price_per_MB']>=0.:
                terminal=terminal_quote(p,order,projection,self.config['horizon_s'])
                base_terminal=terminal_quote(p,p.order,baseline,self.config['horizon_s'])
                # Mathematical best-case window pressure, not a physical
                # capacity quote. Never export the dummy 1-bit construction.
                lower_guide=self.controller.guidance(p,dict(safe_available_bits=1.,committed_bits=0.,window_total_bits=1.))
                upper=incremental_score(task,product,delivered,q,ground,plan,projection,baseline,terminal,base_terminal,lower_guide,self.config['public_prices'])
                if (upper['economic_projection_resolved'] and upper['tx_new_mb']>=0. and
                        math.isfinite(upper['net_score']) and upper['net_score']<=1e-12):
                    bound=(lower_guide,upper)
        if bound is not None:
            guide,sc=bound
            margin=p.service_margin(plan['ready_s'],end,baseline)
            margin.update(window_id=wid,window_total_bits=sum((x.end_s-x.start_s)*x.business_rate_bit_s for x in window),
                ready_s=plan['ready_s'],deadline_s=deadline,window_end_s=end,
                safe_available_bits=None,remaining_bits=None,
                qualification='EXECUTABLE_MARGIN_NOT_EVALUATED_CERTIFIED_NONPOSITIVE_SCORE')
            guide['window_margin']=margin;guide['mu_B']=None;guide['pressure']['window']=None
            guide['qualification']='mu_E exact; mu_B and executable window not evaluated after nonpositive upper-bound proof'
            sc.update(net_score_evaluation='CERTIFIED_UPPER_BOUND_NOT_EXACT_SCORE',net_score_exact=None,
                net_score_upper_bound=sc['net_score'],proven_not_positive=True,
                scarcity_cost_lower_bound=sc['scarcity_cost'],effective_price_B_lower_bound=sc['effective_price_B'])
            for key in ['scarcity_cost','scarcity_downlink_cost','effective_price_B']:sc[key]=None
            if not self.controller.settings['use_dynamic']:
                # pW remains uncomputed, but mu_B is known exactly to be zero.
                # Preserve the same certified decision and expose its exact price.
                guide['mu_B']=0.
                guide['qualification']='dynamic scarcity disabled; pW uncomputed; fixed prices exact'
                sc.update(net_score_evaluation='EXACT_FIXED_PRICE_SCORE_NO_DYNAMIC',net_score_exact=sc['net_score'],
                    scarcity_cost=0.,scarcity_downlink_cost=0.,effective_price_B=self.config['public_prices']['downlink_price_per_MB'])
        else:
            margin=(p.executable_margin(plan['ready_s'],end,baseline)
                    if (self.variant=='pressure_fixed' or self.incremental) and self.method in {'PROP','TUT'}
                    else p.service_margin(plan['ready_s'],end,baseline))
            margin.update(window_id=wid,window_total_bits=sum((x.end_s-x.start_s)*x.business_rate_bit_s for x in window),
                ready_s=plan['ready_s'],deadline_s=deadline,window_end_s=end)
            guide=self.controller.guidance(p,margin)
            delivered=self.delivered.get(task.task_id,set())
            if self.incremental_prop:
                terminal=terminal_quote(p,order,projection,self.config['horizon_s'])
                base_terminal=terminal_quote(p,p.order,baseline,self.config['horizon_s'])
                sc=incremental_score(task,product,delivered,q,ground,plan,projection,baseline,terminal,base_terminal,guide,self.config['public_prices'])
                if not sc['economic_projection_resolved']:reasons.append('UNRESOLVED_TERMINAL_ECONOMICS')
            else:
                sc=score(self.cfg,task,action,pred,delivered,guide,ground,self.qmap)
                sc['adapter']='LEGACY_'+self.method+'_DECISION_PARADIGM'
        if self.method=='MYOPIC':
            pred.predicted_detection_quality=max(.05,min(1.,profile.quality_base-(1.-profile.robustness)*.32*task.difficulty-.16*task.uncertainty))
            pred.predicted_reward=self.myopic_reward(task,pred,product)
            sc['net_score']=pred.predicted_reward;sc['selection_score_source']='FROZEN_COMMON_PREDICTED_REWARD'
        if self.method=='TUT':
            # TUT has its own nominal normalized coefficients, never PROP's
            # 471.16 per 5120MB applied to TUT's 2.7MB reference.
            pp=guide['pressure'];tg=dict(lambda_E=.3*(1+1.2*pp['E']+.8*pp['H']),
                lambda_Q=.15*(1+.9*pp['Q']),lambda_L=.2*(1+.75*pp['deadline']))
            value,detail=self.tut._score(action,pred,task,tg)
            if tut_causal:
                # The residual component includes CPU/contact/service waits and
                # the existing ground processing delay, exactly once. Missing
                # delivery remains a hard rejection, never zero-latency success.
                detail.update(latency_source='SHARED_CAUSAL_GROUND_FORECAST',
                    causal_ground_delay_s=None if ground is None else max(0.,ground-p.now),
                    latency_available=ground is not None)
            sc.update(net_score=value,tut_detail=detail,tut_guidance=tg)
        row=dict(task_id=task.task_id,decision_s=p.now,model=model,product=product,route=route,
            feasible=not reasons,reasons=reasons,ground_s=ground,size_mb=size,energy_j=energy,
            physics_diagnostic=dict(safe=projection['safe'],reason=projection['reason'],
                peaks_c=projection.get('peaks_c'),unsafe_certificate=projection.get('unsafe_certificate'),
                positive_contact_before_deadline=bool(future),
                nominal_future_mb=sum(max(0.,min(x.end_s,service_end)-max(x.start_s,p.now,plan['ready_s']))*
                    x.business_rate_bit_s/8e6 for x in p.kernel.links)),
            score=sc,guidance=guide,predicted=vars(pred),profile=asdict(profile),
            payload_diagnostics=diag,ready_s=plan['ready_s'],cached_inference=plan['cached'],
            queue_diagnostics=dict(current_mb=sum(x.remaining_bits for x in p.order)/8e6,
                baseline_next_mb=baseline_qnext,candidate_next_mb=qnext,
                delta_next_vs_no_new_action_mb=qnext-baseline_qnext,
                scope='next-control diagnostic only; PROP incremental uses formal-terminal difference' if self.incremental_prop else 'legacy absolute Qnext adapter'),
            snapshot_id=before,continuation=continuation)
        return dict(**row,action=action,plan=plan,projection=projection)

    def myopic_reward(self,task,pred,product):
        from src.payload.payload_policy import get_payload_policy_profile
        from src.payload.information_sufficiency import product_information_utility
        # Same frozen reward function and task value normalization as the old
        # common predictor, now consuming causal costs/availability.
        context=NS(V_t=task.task_value,H_t=task.difficulty,U_t=task.uncertainty,
            D_t=1.-min(task.deadline_s/120.,1.),B_t=self.physics.soc,
            Theta_t=thermal_pressure(self.physics.state,self.physics.network.p),E_t_AI=.92,
            Q_t=sum(x.remaining_bits for x in self.physics.order)/8e6)
        fb=ObservedFeedback(E_comp=pred.predicted_E_comp,E_comm=pred.predicted_E_comm,
            L_inf=pred.predicted_L_inf,L_queue=pred.predicted_L_queue,L_comm=pred.predicted_L_comm,
            S_gen_current_mb=pred.predicted_S_gen_mb,S_down_total_mb=pred.predicted_S_down_mb,
            S_down_current_task_mb=pred.predicted_S_down_mb,queue_next_mb=pred.predicted_Q_next_mb,
            delta_queue_mb=pred.predicted_Q_next_mb-context.Q_t,
            delivery_status='deferred' if product=='defer' else 'delivered' if pred.delivery_success_proxy else 'queued',
            delivery_factor=pred.delivery_success_proxy,safety_violation=int(pred.predicted_safety_violation),
            total_latency_s=pred.predicted_L_inf+pred.predicted_L_queue+pred.predicted_L_comm,
            detection_quality=pred.predicted_detection_quality,dropped_current_task_mb=0.,queue_item_count=len(self.physics.order))
        raw=estimate_raw_information_gain(product,self.cfg['payload_profiles'])
        reward=compute_reward(task=task,context=context,payload_information=raw*max(pred.predicted_detection_quality,.10 if product=='defer' else .55),
            feedback=fb,reward_cfg=self.cfg['reward'],simulator_cfg=self.cfg['simulator'])
        return reward.reward

    @staticmethod
    def public_candidate(x):return {k:v for k,v in x.items() if k not in {'action','plan','projection'}}

    def decide(self,task,*,continuation=False):
        if continuation and not self.allow_progressive:raise ValueError('INFORMATION_FOLLOWUP_DISABLED')
        decision_started=time.perf_counter()
        p=self.physics;delivered=self.delivered.get(task.task_id,set());actions=self.actions
        if self.required_product_only:
            actions=[a for a in actions if product_satisfies(a.payload_policy,task.product_requirement)]
        if continuation:
            required=normalize_product(task.product_requirement)
            cached_models=[k.split(':')[-1] for k in p.inference_cache if k.startswith(task.task_id+':')]
            actions=[a for a in actions if a.payload_policy==required and a.model_name in cached_models]
        if self.method=='TUT':actions=[a for a in actions if a.model_name=='balanced']
        if self.method=='OFFLOAD':actions=[NS(**dict(vars(self.actions[0]),model_name='high_accuracy',payload_policy=product,
            action_name='OFFLOAD:'+route,expected_compute_level=.95,expected_payload_level=.55 if product=='roi' else .95))
            for product,route in [('roi','LOCAL'),('roi_context','GROUND')]]
        if self.method=='B1':actions=[NS(**dict(vars(self.actions[0]),model_name='high_accuracy',payload_policy='roi_context',action_name='B1:GROUND'))]
        candidates=[];decision_context={}
        for action in actions:
            route=('LOCAL' if action.payload_policy=='roi' else 'GROUND') if self.method=='OFFLOAD' else 'B1' if self.method=='B1' else 'TUT' if self.method=='TUT' else 'DIRECT'
            if f'{task.task_id}:{action.payload_policy}:{route}' in p.products:continue
            started=time.perf_counter()
            candidates.append(self.candidate(task,action,route=route,continuation=continuation,decision_context=decision_context))
            self.overhead['candidate_seconds'].append(time.perf_counter()-started)
        if self.method=='OFFLOAD':chosen,reason=choose_offload(candidates)
        elif self.method in {'MYOPIC','TUT'}:
            valid=[c for c in candidates if c['feasible']]
            ranked=sorted(valid,key=lambda c:(-c['score']['net_score'],sum(c['predicted'][k] for k in ['predicted_L_inf','predicted_L_queue','predicted_L_comm']),c['size_mb'],c['energy_j'],c['action'].action_name))
            if self.method=='TUT':defer_score=-task.task_value
            else:
                base=p.project(end_s=min(self.config['horizon_s'],(math.floor(p.now/20.)+1)*20.))
                qcurrent=sum(x.remaining_bits for x in p.order)/8e6
                calibration=self.cfg['simulator']['shared_calibrated_prior']['latency_calibration']
                dp=NS(predicted_E_comp=0.,predicted_E_comm=0.,predicted_L_inf=0.,
                    predicted_L_queue=calibration['beta']+calibration['alpha']*20.*min(qcurrent/5120.,1.),
                    predicted_L_comm=0.,predicted_S_gen_mb=0.,predicted_S_down_mb=0.,
                    predicted_Q_next_mb=sum(base['remaining'].values())/8e6,
                    delivery_success_proxy=0.,predicted_safety_violation=0.,predicted_detection_quality=0.)
                defer_score=self.myopic_reward(task,dp,'defer')
            chosen=ranked[0] if ranked and ranked[0]['score']['net_score']>defer_score+1e-12 else None
            reason='one_shot_frozen_baseline_score'
        elif self.method=='B1':
            chosen=next((c for c in candidates if c['feasible']),None);reason='compressed_ground_path'
        elif self.incremental_prop:chosen,reason=choose_incremental(candidates,task,delivered)
        else:chosen,reason=choose_prop(candidates,task,delivered)
        if continuation and not self.incremental_prop:
            # Persistent closing requests preserve all value classes; actual
            # physical/incremental feasibility, not a second model selection.
            valid=[c for c in candidates if c['feasible'] and c['score']['positive_benefit']>0]
            chosen=max(valid,key=lambda c:(c['score']['positive_benefit']/c['size_mb'],c['model']),default=None)
            reason='persistent_closing_cached_inference'
        link=p.kernel.link_at(p.now)
        if continuation and link.window_id:
            end=max(x.end_s for x in p.kernel.links if x.window_id==link.window_id)
            for c in candidates:
                if c['feasible'] and c['ground_s']<=end:
                    self.feedback.opportunity(task,c['product'],link.window_id,delivered)
        state=dict(time_s=p.now,soc=p.soc,thermal=asdict(p.state),queue=[asdict(x) for x in p.order],
            inference_cache=deepcopy(p.inference_cache),mode=self.controller.mode_name)
        self.case_states.setdefault(task.task_id,state)
        rejection_counts=Counter()
        for c in candidates:
            if not c['feasible']:
                category=('no_deadline_service' if all(r in {'READY_AFTER_SERVICE_ENDPOINT','NO_EXECUTABLE_SERVICE_BEFORE_DEADLINE','GROUND_QUEUE_OVERFLOW_PREDICTED'} for r in c['reasons']) else 'unresolved_economics' if c['reasons']==['UNRESOLVED_TERMINAL_ECONOMICS'] else 'hard_physics')
            elif self.incremental_prop and c['score']['net_score']<=1e-12:category='economics'
            elif chosen is not c:category='business_rule_or_rank'
            else:category='admitted'
            c['admission_category']=category;rejection_counts[category]+=1
        self.candidates.extend(self.public_candidate(c) for c in candidates)
        self.decisions.append(dict(task_id=task.task_id,time_s=p.now,continuation=continuation,
            action=chosen['action'].action_name if chosen else 'delay/store',reason=reason,
            score=chosen['score']['net_score'] if chosen else 0.,snapshot_id=p.identity(),candidate_categories=dict(rejection_counts)))
        if self.method=='PROP' and self.variant=='pressure_fixed':
            other=NetworkController(self.cfg,'physics_fixed' if self.variant=='pressure_fixed' else 'pressure_fixed')
            other.history=deepcopy(self.controller.history);other.mode_name=self.controller.mode_name
            for c in candidates:
                g=other.guidance(p,c['guidance']['window_margin'])
                self.same_state.append(dict(task_id=task.task_id,model=c['model'],product=c['product'],state=state,
                    executed_variant=self.variant,alternative_variant=other.variant,mode_held_fixed=True,
                    original=c['score'],alternative=score(self.cfg,task,c['action'],NS(**c['predicted']),delivered,g,c['ground_s'],self.qmap)))
        if chosen:
            p.authorize(chosen['plan']);self.pending.pop(task.task_id,None)
        elif self.method=='PROP' and task.value_level in {'high','urgent'} and not continuation:
            self.pending[task.task_id]='retry_initial'
        self.overhead['decision_seconds'].append(time.perf_counter()-decision_started)
        return chosen

    def observe_ground(self):
        for row in self.physics.ground_events[len(self.ground_ledger):]:
            task=self.arrived[row['task_id']];delivered=self.delivered.setdefault(task.task_id,set())
            if row['q'] is None or not math.isfinite(row['q']):raise ValueError('MISSING_QUALITY_PROVENANCE')
            delta=delta_information_utility(row['product'],delivered,task.product_requirement,self.cfg['product_requirement_utility']) if row['valid'] else 0.
            timely=max(0.,1.-(row['ground_available_s']-task.arrival_s)/task.deadline_s)
            gross=compute_gross_incremental_utility(task.task_value,row['q'],delta,timely)
            if row['valid']:delivered.add(row['product'])
            closes=row['valid'] and product_satisfies(row['product'],task.product_requirement)
            if closes:self.closed.setdefault(task.task_id,row['ground_available_s'])
            self.ground_ledger.append(dict(**row,value=task.task_value,delta_information=delta,timeliness=timely,gross=gross,closes=closes))
            if self.method=='PROP' and self.allow_progressive and row['valid'] and not closes:
                self.pending[task.task_id]='closing'
                product=normalize_product(task.product_requirement)
                size,_=estimate_payload_size_with_diagnostics(product,task=task,payload_profiles_cfg=self.cfg['payload_profiles'])
                delta_next=delta_information_utility(product,delivered,task.product_requirement,self.cfg['product_requirement_utility'])
                info=self.physics.products[row['product_id']];now=row['ground_available_s']
                self.staged_requests[task.task_id]=StagedDeliveryRequest(
                    request_id='staged:'+task.task_id+':'+product,task_id=task.task_id,product_type=product,
                    parent_product_type=row['product'],product_requirement=task.product_requirement,
                    value_level=task.value_level,calibrated_task_value=task.task_value,
                    residual_delta_information_utility=delta_next,residual_utility_remaining=delta_next,
                    detection_quality=info['detection_quality'],timeliness_factor=max(0.,(task.deadline_time_s-now)/task.deadline_s),
                    payload_size_mb=size,deadline_slot=int(task.deadline_time_s//20),created_slot=int(now//20),
                    last_evaluated_slot=int(now//20),earliest_delivery_slot=int(now//20),deadline_s=task.deadline_s,created_time_s=now)

    def process_closing(self,slot,*,same_slot=False):
        p=self.physics;link=p.kernel.link_at(p.now)
        if not self.allow_progressive:return
        if self.method!='PROP' or not link.business_rate_bit_s:return
        cfg=staged_delivery_queue_config(self.cfg['simulator'])
        candidates=[];requests=[]
        for tid,request in self.staged_requests.items():
            task=self.arrived[tid]
            if self.pending.get(tid)!='closing' or tid in self.closed or task.deadline_time_s<=p.now:continue
            if any(x.task_id==tid for x in p.order):continue
            request.timeliness_factor=max(0.,(task.deadline_time_s-p.now)/task.deadline_s)
            value,components=compute_staged_priority(request,current_slot=slot,config=self.cfg['simulator'])
            request.priority_score=value;request.priority_components=components
            if components['value_density_priority']<cfg['min_value_density'] or value<cfg['eriv_threshold']:continue
            if same_slot:
                pcfg=self.cfg['simulator']['progressive_payload']['phase6_proactive_followup']
                if self.proactive_slot_count.get(slot,0)>=pcfg['max_proactive_residuals_per_slot'] or self.proactive_window_count.get(link.window_id,0)>=pcfg['max_proactive_residuals_per_contact']:continue
                if p.now-request.created_time_s>600.:continue
                state=dict(task_id=tid,product_requirement=task.product_requirement,
                    delivered_products=self.delivered.get(tid,set()),pending_products={request.product_type},
                    task_closed_flag=False,residual_utility_remaining=request.residual_utility_remaining,
                    deadline_s=task.deadline_s,task_value=task.task_value)
                window_end=max(x.end_s for x in p.kernel.links if x.window_id==link.window_id)
                thermal=thermal_pressure(p.state,p.network.p) if self.variant=='pressure_fixed' or self.incremental else min(1.,(max(p.state.temperatures_c)+10.)/40.)
                system=dict(variant='proposed_lyapunov_rule_mode_safe_bandit',use_lyapunov_pricing=True,use_mode_controller=True,
                    queue_mb=sum(x.remaining_bits for x in p.order)/8e6,queue_max_mb=5120.,
                    remaining_deadline_s=task.deadline_time_s-p.now,deadline_s=task.deadline_s,
                    battery_soc=p.soc,thermal_pressure=thermal,value_level=task.value_level,
                    contact_available=True,contact_remaining_window_s=window_end-p.now,
                    task_value=task.task_value,model_quality_factor=request.detection_quality,payload_size_mb=request.payload_size_mb)
                gate=evaluate_proactive_followup_eligibility(state,system,self.cfg['simulator'])
                self.staged_trace.append(dict(task_id=tid,time_s=p.now,same_slot=True,proactive_gate=asdict(gate)))
                if not gate.proactive_flag:continue
            requests.append(request)
        ranked=rank_guarantee_aware_requests(requests,current_slot=slot,config=self.cfg['simulator'],
            debt_by_task=self.guarantee_debt,delivered_products_by_task=self.delivered,
            waiting_age_slots_by_task={r.task_id:max(0,slot-r.created_slot) for r in requests},
            queue_pressure=sum(x.remaining_bits for x in p.order)/8e6/5120.)
        candidates=[(r.priority_score,self.arrived[r.task_id].deadline_time_s,r.task_id) for r in ranked]
        candidates.sort(key=lambda x:(-x[0],x[1],x[2]))
        admitted=0
        for value,_,tid in candidates:
            if self.staged_count_slot.get(slot,0)>=cfg['max_admissions_per_slot'] or self.staged_count_window.get(link.window_id,0)>=cfg['max_admissions_per_contact_window']:break
            if same_slot and admitted>=1:break
            chosen=self.decide(self.arrived[tid],continuation=True)
            self.staged_trace.append(dict(task_id=tid,time_s=p.now,priority=value,components=self.staged_requests[tid].priority_components,
                same_slot=same_slot,admitted=chosen is not None))
            if chosen:
                admitted+=1;self.staged_count_slot[slot]=self.staged_count_slot.get(slot,0)+1
                self.staged_count_window[link.window_id]=self.staged_count_window.get(link.window_id,0)+1
                if same_slot:
                    self.proactive_slot_count[slot]=self.proactive_slot_count.get(slot,0)+1
                    self.proactive_window_count[link.window_id]=self.proactive_window_count.get(link.window_id,0)+1

    def advance_slot_events(self,end_s,slot):
        p=self.physics
        boundary_ground=False
        while p.now<end_s-1e-9:
            p.order=self.sorted_order()
            service_order=self.b1_service_order(end_s) if self.method=='B1' else None
            trial=p.project(end_s=end_s,order=service_order)
            times=[v for v in trial['finishes'].values() if v is not None and v>p.now+1e-9]
            times += [r['ground_available_s'] for r in p.ground_pending if r['ground_available_s']>p.now+1e-9]
            if self.method=='B1':times += [x.ready_time_s for x in p.order if x.ready_time_s>p.now+1e-9]
            event=min([end_s,p.kernel.link_at(p.now).end_s]+times)
            p.execute(event,service_order=service_order);before=len(self.ground_ledger);self.observe_ground()
            if len(self.ground_ledger)>before and p.now<end_s-1e-9:self.process_closing(slot,same_slot=True)
            boundary_ground=len(self.ground_ledger)>before and abs(p.now-end_s)<=1e-9
        return boundary_ground

    def b1_service_order(self,end_s):
        p=self.physics;link=p.kernel.link_at(p.now)
        window=[x for x in p.kernel.links if link.window_id and x.window_id==link.window_id]
        until=max((x.end_s for x in window),default=p.now)
        capacity=p.kernel.offered_bits_between(p.now,until)/8e6
        eligible=[x for x in p.order if x.ready_time_s<=p.now+1e-9 and x.deadline_s>p.now]
        rows=[];byid={}
        for item in eligible:
            info=p.products[item.product_id];task=self.arrived[item.task_id]
            row=NS(task=task,compressed_size_mb=info['original_bits']/8e6,
                remaining_downlink_mb=item.remaining_bits/8e6,deadline_time_s=item.deadline_s,
                queue_enter_time_s=item.ready_time_s,capture_time_s=task.arrival_s)
            rows.append(row);byid[item.task_id]=item
        # Replace the old two-node hard safety formula with the same exact
        # shared kernel used for execution; retain old B1 rank and full-fit.
        def safe(item,*args):
            target=byid[item.task.task_id]
            quote=p.project(order=(target,),end_s=max(p.now+1e-8,min(until,target.deadline_s)))
            return quote['safe'] and quote['finishes'].get(target.product_id) is not None
        self.b1._hard_safety_feasible=safe
        selected=None;trace=[]
        active=next((x for x in eligible if x.partially_served),None)
        if active:selected=byid[active.task_id]
        elif rows and link.business_rate_bit_s:
            chosen,trace=self.b1.select(rows,p.now,NS(throughput_mbps=link.business_rate_bit_s/1e6,link_quality=1.),
                NS(battery_soc=p.soc,thermal_pressure=thermal_pressure(p.state,p.network.p)),self.cfg['simulator'],capacity)
            if chosen:selected=byid[chosen.task.task_id]
        self.b1_trace.extend(dict(time_s=p.now,**asdict(t)) for t in trace)
        # Mask service eligibility only. Hardware ready remains in original
        # queue/product state; all bytes, costs and deadlines are preserved.
        return [x if selected is not None and x.product_id==selected.product_id else replace(x,ready_time_s=max(x.ready_time_s,end_s+1.)) for x in p.order]

    def run(self,stop_s,*,full_scope=None):
        horizon=self.config['horizon_s']
        if stop_s<=0 or stop_s>horizon:raise ValueError('STOP_OUTSIDE_DECLARED_HORIZON')
        if stop_s==horizon:
            if full_scope not in {'development','formal'}:raise ValueError('FULL_LIFECYCLE_REQUIRES_EXPLICIT_SCOPE')
            if full_scope=='development' and self.config.get('dataset_scope')!='INDEPENDENT_DEVELOPMENT':
                raise ValueError('DEVELOPMENT_REQUIRES_INDEPENDENT_DEVELOPMENT_INPUT')
            self.wall_scope=('FINITE_PERIOD_' if self.config.get('finite_period') else 'FULL_LIFECYCLE_')+full_scope.upper()+'_NOT_AUTOMATIC_SCIENTIFIC_ACCEPTANCE'
        elif full_scope is not None:raise ValueError('FULL_SCOPE_REQUIRES_FORMAL_ENDPOINT')
        by_slot={}
        fresh_preobserved=self.physics.now==0. and not self.arrival_events and not self.decisions
        for task in sorted(self.tasks,key=lambda t:(t.arrival_s,t.task_id)):
            if task.arrival_s<stop_s and (task.task_id not in self.arrived or fresh_preobserved):
                if task.arrival_s<self.physics.now-1e-9:raise ValueError('UNOBSERVED_ARRIVAL_BEFORE_RESUME')
                by_slot.setdefault(int(task.arrival_s//20.),[]).append(task)
        if abs(self.physics.now/20.-round(self.physics.now/20.))>1e-9:
            raise ValueError('RESUME_REQUIRES_COMPLETED_MACRO_SLOT')
        def register(tasks):
            for task in tasks:
                if task.task_id in self.arrived and not (fresh_preobserved and task.arrival_s==0. and self.arrived[task.task_id] is task):
                    raise ValueError('DUPLICATE_ARRIVAL')
                if abs(task.arrival_s-self.physics.now)>1e-8:raise ValueError('NONCAUSAL_ARRIVAL')
                self.arrived[task.task_id]=task
                self.arrival_events.append(dict(task_id=task.task_id,time_s=self.physics.now))
                if self.incremental_prop:self.controller.observe_arrival(self.physics,task)
        for slot in range(int(round(self.physics.now/20.)),math.ceil(stop_s/20.)):
            p=self.physics;arrivals=by_slot.get(slot,[])
            environment_hook=getattr(self,'environment_event',None)
            if environment_hook is not None:environment_hook(p.now)
            initial=[t for t in arrivals if t.arrival_s==p.now]
            register(initial);task=initial[0] if initial else None
            started=time.perf_counter()
            if self.incremental_prop:self.controller.observe_slot(slot,p,task,arrived=self.arrived,pending=self.pending,closed=self.closed)
            else:self.controller.observe_slot(slot,p,task)
            self.overhead['controller_seconds'].append(time.perf_counter()-started)
            if self.method=='PROP':
                self.feedback.slot(slot,p,self.arrived,self.pending,self.delivered,self.closed)
                self.guarantee_debt=self.feedback.debts()
            p.order=self.sorted_order()
            for t in initial:self.decide(t)
            link=p.kernel.link_at(p.now)
            if self.method=='PROP' and link.business_rate_bit_s:
                # Ordinary closing requests are execution continuations;
                # A future off-grid arrival cannot suppress a slot-start retry.
                self.process_closing(slot)
                if task is None:
                    retry=[self.arrived[k] for k,v in self.pending.items() if v=='retry_initial' and k not in self.closed
                        and self.arrived[k].deadline_time_s>p.now and (k,link.window_id) not in self.retry_windows
                        and not any(x.task_id==k for x in p.order)]
                    retry.sort(key=lambda t:(-t.task_value,t.deadline_time_s-p.now,-t.base_prior_score,t.task_id))
                    if retry:
                        t=retry[0];self.retry_windows.add((t.task_id,link.window_id));self.decide(t)
            interior=[t for t in arrivals if t not in initial]
            while interior:
                when=interior[0].arrival_s
                boundary_ground=self.advance_slot_events(when,slot)
                batch=[t for t in interior if t.arrival_s==when]
                register(batch)
                for t in batch:self.decide(t)
                if boundary_ground:self.process_closing(slot,same_slot=True)
                interior=interior[len(batch):]
            p.order=self.sorted_order()
            self.advance_slot_events(min(stop_s,(slot+1)*20.),slot)
            if self.method=='PROP' and link.window_id and not any(x.window_id==link.window_id and x.end_s>p.now+1e-9 for x in p.kernel.links):
                self.feedback.window_end(link.window_id,p,self.arrived,self.delivered,self.closed)
            # Checkpoints are taken only after all slot/window feedback.
            hook=getattr(self,'slot_complete_hook',None)
            if hook is not None:hook(self,slot)
            if slot%100==99:print(f'progress {self.variant}/{self.method} t={p.now:g} arrivals={len(self.arrived)} ground={len(self.ground_ledger)}',flush=True)
        return self.evaluate()

    def evaluate(self):
        ledger=self.physics.ledger();prices=self.config['public_prices']
        gross=sum(r['gross'] for r in self.ground_ledger)
        costs=dict(energy=ledger['controlled_j']/3600.*prices['energy_price_per_Wh'],
            downlink=ledger['downlink_mb']*prices['downlink_price_per_MB'],
            terminal_backlog=ledger['backlog_mb']*prices['terminal_backlog_price_per_MB'] if not self.incremental or self.physics.now>=self.config['horizon_s']-1e-9 else 0.)
        result=dict(variant=self.variant,method=self.method,seed=self.config['seed'],stop_s=self.physics.now,
            scope=self.wall_scope,arrivals=len(self.arrived),closed=len(self.closed),ground_events=len(self.ground_ledger),
            gross=gross,costs=costs,net=gross-sum(costs.values()),ledger=ledger,soc=self.physics.soc,
            thermal=asdict(self.physics.state),decision_count=len(self.decisions),
            input_identity=fingerprint(self.config['input_hashes']),physics_owner='NetworkPhysics/C06_EventQueueKernelV3',
            formal_claim=False)
        if self.incremental:
            result.update(formal_settlement_s=self.config['horizon_s'],terminal_settled=self.physics.now>=self.config['horizon_s']-1e-9,
                net_scope='CUMULATIVE_OBSERVED_NO_TERMINAL_SETTLEMENT' if self.physics.now<self.config['horizon_s'] else ('FINITE_PERIOD_FIXED_KAPPA_SETTLED' if self.config.get('finite_period') else 'FORMAL_ENDPOINT_DEVELOPMENT_ONLY'),
                kappa_Q_zero_fixed_trajectory_net=gross-costs['energy']-costs['downlink'],
                observation_backlog_snapshot_charge=ledger['backlog_mb']*prices['terminal_backlog_price_per_MB'])
            groups={}
            statuses={}
            for tid,t in self.arrived.items():
                if tid in self.closed:status='closed'
                elif t.deadline_time_s<=self.physics.now+1e-9:status='deadline_elapsed_unclosed'
                elif tid in self.pending or any(x.task_id==tid for x in self.physics.order) or any(x['task_id']==tid for x in self.physics.ground_pending):status='right_censored_pending'
                else:status='right_censored_rejected_or_partial' if self.config.get('finite_period') else 'one_shot_rejected_or_partial'
                statuses[tid]=status
            for name in ['all','high_value','ordinary']:
                ids={tid for tid,t in self.arrived.items() if name=='all' or (t.value_level in {'high','urgent'})==(name=='high_value')}
                rows=[r for r in self.ground_ledger if r['task_id'] in ids];energy=sum(sum(ledger['by_task'].get(tid,{}).get(k,0.) for k in ['inference_j','encoding_j','tx_j']) for tid in ids)
                b=sum(ledger['by_task'].get(tid,{}).get('downlink_mb',0.) for tid in ids)
                q=sum(x.remaining_bits for x in self.physics.order if x.task_id in ids and x.ready_time_s<=self.physics.now+1e-10)/8e6
                g=sum(r['gross'] for r in rows);ec=energy/3600.*prices['energy_price_per_Wh'];bc=b*prices['downlink_price_per_MB'];qc=q*prices['terminal_backlog_price_per_MB'] if result['terminal_settled'] else 0.
                groups[name]=dict(tasks=len(ids),closed=sum(tid in self.closed for tid in ids),gross=g,energy_cost=ec,downlink_cost=bc,terminal_cost=qc,net=g-ec-bc-qc,status_counts=dict(Counter(statuses[t] for t in ids)))
            result.update(groups=groups,task_status=statuses,candidate_category_counts=dict(sum((Counter(d['candidate_categories']) for d in self.decisions),Counter())),
                task_rejection_decision_counts={cat:len({d['task_id'] for d in self.decisions if d['action']=='delay/store' and d['candidate_categories'].get(cat,0)>0}) for cat in ['hard_physics','no_deadline_service','economics','business_rule_or_rank','unresolved_economics']},
                rejection_count_note='candidate counts are attempts; task counts are distinct IDs with any rejected decision in category, nonexclusive and separate from final lifecycle status')
        return result

    def scale(self):
        all_values=[t.task_value for t in self.tasks]
        return dict(identity=dict(seed=self.config['seed'],variant=self.variant,method=self.method,input_hashes=self.config['input_hashes']),
            time=dict(full_horizon_s=self.config['horizon_s'],macro_slot_s=20,full_macro_slots=int(self.config['horizon_s']/20),actual_prefix_s=self.physics.now),
            tasks=dict(full_count=len(self.tasks),full_class_counts=dict(Counter(t.value_level for t in self.tasks)),
                actual_arrivals=len(self.arrived),prefix_classes=dict(Counter(t.value_level for t in self.arrived.values())),
                full_values=dict(min=min(all_values),max=max(all_values),sum=sum(all_values)),
                full_deadline_s=dict(min=min(t.deadline_s for t in self.tasks),max=max(t.deadline_s for t in self.tasks))),
            models={name:dict(q=q,profile=asdict(self.registry.get_profile(name))) for name,q in self.qmap.items()},
            actions=dict(Counter(d['action'] for d in self.decisions)),
            communication=dict(full_contacts=len(set(x.window_id for x in self.physics.kernel.links if x.window_id)),
                full_raw_business_mb=sum(x.business_rate_bit_s*(x.end_s-x.start_s) for x in self.physics.kernel.links)/8e6,
                actual_consumed_mb=self.physics.ledger()['downlink_mb'],reserved='NO_HARD_RESERVATION_LEGACY_DISABLED',
                per_candidate_executable='candidate log; not actual bytes'),
            energy=self.physics.ledger(),lifecycle=dict(ground=len(self.ground_ledger),closure=len(self.closed),q_coverage=1.),
            detector=dict(backend='MockDetector engineering profiles',pixels_read=[],labels_read=[],
                declared_input='frozen task metadata contains historical offline label summary; unchanged legacy boundary'),
            D_arm_comparison='NOT_APPLICABLE_NETWORK_ENGINEERING_REVISION')

    def save(self,out):
        out=Path(out);out.mkdir(parents=True,exist_ok=False)
        write_json(out/'CONFIG_EFFECTIVE.json',self.config)
        write_json(out/'summary.json',self.evaluate());write_json(out/'experiment_scale_snapshot.json',self.scale())
        write_json(out/'decisions.json',self.decisions)
        write_json(out/'TRACE_POLICY.json',dict(candidate_diagnostics_exported=self.trace,
            authoritative_ledgers_always_exported=True,physical_behavior_unchanged=True))
        if self.trace:write_json(out/'candidates.json',self.candidates)
        write_json(out/'ground_ledger.json',self.ground_ledger);write_json(out/'products.json',self.physics.products)
        write_json(out/'flows.json',self.physics.flows);write_json(out/'work.json',[asdict(x) for x in self.physics.work])
        write_json(out/'physical_trajectory.json',self.physics.trajectory)
        write_json(out/'events.json',self.physics.events);write_json(out/'mode_updates.json',self.controller.mode_updates)
        write_json(out/'arrival_events.json',self.arrival_events)
        write_json(out/'thermal_protection.json',self.physics.actual_thermal_protection)
        write_json(out/'terminal_state.json',dict(now_s=self.physics.now,arrived=sorted(self.arrived),order=[asdict(x) for x in self.physics.order],
            expired=self.physics.expired,ground_pending=self.physics.ground_pending,pending=self.pending,
            closed=self.closed,delivered={k:sorted(v) for k,v in self.delivered.items()}))
        write_json(out/'staged_trace.json',self.staged_trace)
        write_json(out/'overhead.json',self.overhead)
        write_json(out/'progress_feedback.json',self.feedback.trace)
        if self.method=='B1':write_json(out/'b1_schedule.json',self.b1_trace)
        if self.trace:
            write_json(out/'case_arrival_states.json',self.case_states)
            write_json(out/'same_state_pricing.json',self.same_state)
