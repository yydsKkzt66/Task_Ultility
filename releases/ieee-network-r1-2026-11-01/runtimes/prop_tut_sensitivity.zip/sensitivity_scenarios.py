"""Declared exogenous factors only; inherited policies and evaluator unchanged."""
from dataclasses import replace,asdict
from copy import deepcopy
from pathlib import Path
import math,json
from src.network_revision.runtime import NetworkExperiment,write_json
from src.network_revision.physics import fingerprint

class SensitivityExperiment(NetworkExperiment):
    def __init__(self,root,variant,method,trace=False):
        super().__init__(root,variant,method,trace)
        self.factor=self.config['sensitivity']
        self.normal_links=tuple(self.physics.kernel.links)
        target=self.factor['capacity_multiplier']
        if target!=.5:
            ratio=target/.5  # input calendar ALREADY contains absolute0.50
            self.physics.kernel.links=tuple(replace(x,business_rate_bit_s=x.business_rate_bit_s*ratio,
                window_capacity_bits=x.window_capacity_bits*ratio) for x in self.normal_links)
        self.outage_announced=False;self.environment_events=[];self.recovery_backlog=None
        self.calendar_snapshots=[]

    def environment_event(self,now):
        outage=self.factor.get('outage')
        if not outage:return
        start,end=outage
        if not self.outage_announced and now>=start:
            assert abs(now-start)<1e-8,'MISSED_NOTIFICATION_BOUNDARY'
            p=self.physics;before=p.identity();old=p.kernel.links
            links=[]
            for x in old:
                # Formal boundaries are exact macro/environment boundaries.
                if x.start_s<end and x.end_s>start:
                    assert x.start_s>=start and x.end_s<=end
                    x=replace(x,business_rate_bit_s=0.,tx_dc_power_w=0.,window_capacity_bits=0.)
                links.append(x)
            p.kernel.links=tuple(links);p.kernel._projection_cache.clear()
            # All link-derived memo tables are tied to the tuple identity.
            p.kernel.link_at(now)
            for name in ('_capacity_links','_constant_links'):
                if hasattr(p.kernel,name):delattr(p.kernel,name)
            assert p.identity()==before,'NOTIFICATION_RESET_EXECUTION_STATE'
            self.outage_announced=True
            self.environment_events.append(dict(time_s=now,event='OUTAGE_NOTIFICATION_BEFORE_CONTROL_DECISION_TX',
                unavailable=[start,end],state_before=before,state_after=p.identity(),
                old_calendar=fingerprint([asdict(x) for x in old]),new_calendar=fingerprint([asdict(x) for x in links]),
                revoked_future_service_only=True,queue_preserved=True,cache_invalidated=True))
        if self.recovery_backlog is None and now>=end:
            assert abs(now-end)<1e-8,'MISSED_RECOVERY_BOUNDARY'
            # Explicit cohorts: authorized outstanding bytes, and wider arrived
            # unclosed tasks. Never retroactively resurrect a terminal task.
            p=self.physics
            authorized={x.task_id for x in p.order}|{x['task_id'] for x in p.ground_pending}
            eligible={tid for tid,t in self.arrived.items() if tid not in self.closed and t.deadline_time_s>now}
            hv={tid for tid in eligible if self.arrived[tid].value_level in {'high','urgent'}}
            self.recovery_backlog=dict(time_s=now,authorized_HV=sorted(hv&authorized),unclosed_arrived_HV=sorted(hv))
            self.environment_events.append(dict(time_s=now,event='OUTAGE_INTERVAL_ENDED',cohorts=self.recovery_backlog))

    def save(self,out):
        super().save(out)
        write_json(Path(out)/'SENSITIVITY_ENVIRONMENT.json',dict(factor=self.factor,notification=self.environment_events,
            recovery_backlog=self.recovery_backlog,actual_calendar=[asdict(x) for x in self.physics.kernel.links]))

def additional_audit(e,job,folder):
    p=e.physics;factor=e.factor;outage=factor.get('outage');checks={};delay={}
    checks['TUT_CAUSAL_POLICY']=e.method!='TUT' or e.config.get('tut_latency_policy')=='causal_ground'
    checks['value_total']=math.isclose(math.fsum(t.task_value for t in e.tasks),factor['main_value_total'],rel_tol=1e-12,abs_tol=1e-9)
    if outage:
        a,b=outage
        checks['notified_at_start']=len([r for r in e.environment_events if r['event'].startswith('OUTAGE_NOTIFICATION') and r['time_s']==a])==1
        checks['zero_outage_service']=not any(f['start_s']<b and f['end_s']>a and f['business_bits']>0 for f in p.flows)
        checks['normal_first_fourth']=all(x.business_rate_bit_s==y.business_rate_bit_s for x,y in zip(p.kernel.links,e.normal_links) if x.end_s<=a or x.start_s>=b)
    for kind in ['all','high_value','ordinary']:
        vals=[];seen=set()
        for r in e.ground_ledger:
            if not r['valid'] or not r['closes'] or r['task_id'] in seen:continue
            seen.add(r['task_id'])
            t=e.arrived[r['task_id']];hv=t.value_level in {'high','urgent'}
            if kind=='all' or (kind=='high_value')==hv:vals.append(r['ground_available_s']-t.arrival_s)
        vals.sort()
        def quant(q):
            if not vals:return None
            at=(len(vals)-1)*q;i=int(at);return vals[i]+(vals[min(i+1,len(vals)-1)]-vals[i])*(at-i)
        delay[kind]=dict(n=len(vals),mean_s=math.fsum(vals)/len(vals) if vals else None,p95_s=quant(.95))
    no_window={'HV':[],'ordinary':[]}
    for t in e.tasks:
        if t.deadline_time_s>p.now:continue
        possible=any(x.business_rate_bit_s>0 and min(t.deadline_time_s,x.end_s)>max(t.arrival_s,x.start_s) for x in p.kernel.links)
        if not possible:no_window['HV' if t.value_level in {'high','urgent'} else 'ordinary'].append(t.task_id)
    recovery={}
    if e.recovery_backlog:
        when=e.recovery_backlog['time_s']
        for cohort in ['authorized_HV','unclosed_arrived_HV']:
            ids=set(e.recovery_backlog[cohort]);events=[r for r in e.ground_ledger if r['task_id'] in ids and r['ground_available_s']>=when and r['valid']]
            recovery[cohort]=dict(cohort_count=len(ids),new_gross=math.fsum(r['gross'] for r in events),new_closures=len({r['task_id'] for r in events if r['closes']}))
    # Explicitly validate the TUT input used for ALL candidates after execution.
    error=0.;denom=0
    if e.method=='TUT':
        for line in (Path(folder)/'candidates.jsonl').open(encoding='utf-8'):
            c=json.loads(line);d=c['score']['tut_detail'];denom+=1
            assert d['latency_source']=='SHARED_CAUSAL_GROUND_FORECAST'
            if c['ground_s'] is not None:error=max(error,abs(d['predicted_latency_s']-(c['ground_s']-c['decision_s'])))
        checks['TUT_ALL_CANDIDATE_LATENCIES']=error<=1e-7
    result=dict(pass_=all(checks.values()),checks=checks,condition=job['condition'],seed=job['seed'],method=job['arm'],
        delay=delay,expired_tasks_without_any_window={k:len(v) for k,v in no_window.items()},no_window_ids=no_window,
        recovery=recovery,TUT_candidates=denom,TUT_max_latency_error_s=error,normal_reference_delta='computed by summary only when matching normal reference is available')
    write_json(Path(folder)/'SENSITIVITY_AUDIT.json',result)
    windows={}
    for x in e.normal_links:
        if not x.window_id:continue
        w=windows.setdefault(x.window_id,dict(start_s=x.start_s,end_s=x.end_s))
        w['start_s']=min(w['start_s'],x.start_s);w['end_s']=max(w['end_s'],x.end_s)
    window_rows=[]
    for name,w in windows.items():
        when=w['end_s'];events=[r for r in e.ground_ledger if w['start_s']<=r['ground_available_s']<when and r['valid']]
        snap=Path(folder)/'SNAPSHOTS'/f'T{round(when):05d}'/'summary.json'
        snapshot=json.loads(snap.read_text(encoding='utf-8')) if snap.exists() else None
        window_rows.append(dict(window=name,**w,ground_events_within_window=len(events),
            gross_within_window=math.fsum(r['gross'] for r in events),
            closed_within_window=len({r['task_id'] for r in events if r['closes']}),
            backlog_ready_MB_at_end=snapshot['ledger']['backlog_mb'] if snapshot else None,
            committed_unready_MB_at_end=snapshot['ledger']['unmaterialized_committed_mb'] if snapshot else None,
            snapshot_available=bool(snapshot)))
    write_json(Path(folder)/'WINDOW_DELIVERY_BACKLOG.json',dict(rows=window_rows,
        note='Actual ground events in [window_start,window_end); ACK/ground events after a window remain in the full ground ledger. Backlog from saved state at exact window end.'))
    return result
