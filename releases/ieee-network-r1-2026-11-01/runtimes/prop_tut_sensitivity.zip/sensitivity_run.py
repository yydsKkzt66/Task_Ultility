from pathlib import Path
import sys,runpy,os,argparse,json,time,traceback
ROOT=Path(__file__).resolve().parent
_bootstrap=runpy.run_path(str(ROOT/'run.py'),run_name='_sensitivity_environment')
from sensitivity_io import install,atomic_write,read_retry
install()
from formal_common import verify,sha

def worker(a):
    from sensitivity_scenarios import SensitivityExperiment,additional_audit
    from formal_worker import execute
    ids=verify();matrix=read_retry(ROOT/'SENSITIVITY_MATRIX.json')
    j=next(j for j in matrix['jobs'] if j['job_id']==a.job)
    if a.machine and j['machine']!=a.machine:raise ValueError('MACHINE_SCOPE_MISMATCH')
    e=None if a.resume else SensitivityExperiment(ROOT,j['variant'],j['method'])
    try:
        e=execute(j,a.out,stop=a.stop,resume=a.resume,experiment=e,identities=ids)
        result=additional_audit(e,j,a.out)
        if not result['pass_']:raise ValueError('SENSITIVITY_AUDIT_FAILED')
        if a.stop==21600.:
            atomic_write(Path(a.out)/'VERIFIED_COMPLETE.json',dict(epoch=time.time(),job=j,source=ids,sensitivity_audit=result))
    except Exception as error:
        if not (Path(a.out)/'FAILED.json').exists():
            atomic_write(Path(a.out)/'FAILED.json',dict(error=repr(error),traceback=traceback.format_exc(),stage='sensitivity_wrapper'))
        raise

def check(a):
    import pytest
    out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
    ids={} if a.development else verify();sys.path.insert(0,str(ROOT/'tests'))
    gates=['test_post_period_forecast_has_zero_benefit_and_no_early_authorization','test_nonzero_delta_terminal_ready_backlog_matches_execution','test_large_clock_reserved_empty_replay_bits_and_protection']
    result=pytest.main(['-q','-p','no:cacheprovider',str(ROOT/'tests/test_sensitivity.py')]+[str(ROOT/'tests/test_network_formal6h.py')+'::'+g for g in gates]+['--basetemp='+str(out/'test_tmp'),'--junitxml='+str(out/'pytest.xml')])
    imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items() if (n=='src' or n.startswith(('src.','formal_','sensitivity_','network_frozen_'))) and getattr(m,'__file__',None)}
    outside={n:p for n,p in imports.items() if not Path(p).is_relative_to(ROOT)}
    atomic_write(out/'CHECK_ONLY.json',dict(pass_=result==0 and not outside,pytest_exit=result,manifests=ids,
        root=str(ROOT),cwd=str(Path.cwd()),imports=imports,outside_imports=outside,python=sys.version))
    raise SystemExit(result if not outside else 3)

def main():
    p=argparse.ArgumentParser();p.add_argument('command',choices=['worker','check','launch','summary','import-reference']);p.add_argument('--job');p.add_argument('--out',default='outputs');p.add_argument('--resume');p.add_argument('--stop',type=float,default=21600.);p.add_argument('--machine',choices=['A','B']);p.add_argument('--max-workers',type=int,default=5);p.add_argument('--development',action='store_true');p.add_argument('--reference-zip')
    a=p.parse_args()
    if a.command=='worker':worker(a)
    elif a.command=='check':check(a)
    elif a.command=='launch':
        from sensitivity_supervisor import main as launch
        launch(a)
    elif a.command=='summary':
        from sensitivity_summary import summarize
        summarize(Path(a.out).resolve())
    elif a.command=='import-reference':
        from sensitivity_summary import import_reference
        import_reference(a.reference_zip)
if __name__=='__main__':main()
