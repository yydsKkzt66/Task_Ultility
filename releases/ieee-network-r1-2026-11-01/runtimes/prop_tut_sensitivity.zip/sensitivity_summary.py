"""Read-only completed-result accounting; no predictions or policy callbacks."""
from pathlib import Path
from collections import defaultdict
import csv,json,math,statistics,zipfile,hashlib,os
from formal_common import ROOT,sha,verify
from sensitivity_io import read_retry as read,atomic_write as write
from formal_summary import flatten

SEEDS={4101,4102,4103}
REFERENCE_FILES=['AUDIT.json','IDENTITY.json','COMPLETED.json','VERIFIED_COMPLETE.json','SENSITIVITY_AUDIT.json',
    'RESULT/AUDITED_SUMMARY.json','RESULT/task_accounting.csv','RESULT/ground_ledger.json','RESULT/CONFIG_EFFECTIVE.json','RESULT/windows.csv']

def csvwrite(path,rows):
    keys=list(dict.fromkeys(k for r in rows for k in r))
    tmp=Path(str(path)+'.tmp')
    with tmp.open('w',encoding='utf-8-sig',newline='') as f:
        if keys:
            w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
    os.replace(tmp,path)

def finished(out):
    result=[]
    for j in read(ROOT/'SENSITIVITY_MATRIX.json')['jobs']:
        for p in reversed(sorted((Path(out)/j['job_id']).glob('attempt_[0-9][0-9]'))):
            if not (p/'VERIFIED_COMPLETE.json').exists():continue
            v=read(p/'VERIFIED_COMPLETE.json')
            assert v['job']==j and read(p/'AUDIT.json')['pass'] and v['sensitivity_audit']['pass_']
            assert v['source']['SOURCE_MANIFEST.json']==sha(ROOT/'SOURCE_MANIFEST.json')
            s=read(p/'RESULT/AUDITED_SUMMARY.json');s['runtime']=read(p/'COMPLETED.json')
            s['arm']=j['arm'];s['condition']=j['condition'];s['job']=j;s['path']=str(p)
            s['extra']=read(p/'SENSITIVITY_AUDIT.json');result.append(s);break
    return result

def references(out=None):
    refs={}
    for r in read(ROOT/'REFERENCE_INDEX.json')['rows']:
        if r['status']!='COMPLETE_AUDITED':continue
        p=ROOT/r['relative_path'];assert sha(p/'RESULT/AUDITED_SUMMARY.json')==r['summary_sha256']
        assert read(p/'AUDIT.json')['pass']
        s=read(p/'RESULT/AUDITED_SUMMARY.json');s['arm']=r['arm'];s['runtime']=read(p/'COMPLETED.json')
        s['condition']='NORMAL';s['path']=str(p);refs[r['seed'],r['arm']]=s
    for m in sorted((ROOT/'reference_updates').glob('*/REFERENCE_UPDATE.json')):
        d=read(m)
        assert d['source_manifest_sha256']==sha(ROOT/'SOURCE_MANIFEST.json')
        for rel,h in d['files'].items():assert sha(m.parent/rel)==h
        for r in d['rows']:
            p=m.parent/r['path'];s=read(p/'RESULT/AUDITED_SUMMARY.json')
            assert read(p/'AUDIT.json')['pass'] and read(p/'VERIFIED_COMPLETE.json')['sensitivity_audit']['pass_']
            s.update(arm=r['arm'],condition='NORMAL',runtime=read(p/'COMPLETED.json'),path=str(p),extra=read(p/'SENSITIVITY_AUDIT.json'))
            refs[r['seed'],r['arm']]=s
    if out:
        for s in finished(out):
            if s['condition']=='NORMAL':refs[s['seed'],s['arm']]=s
    return refs

def closure_delay(s):
    if 'extra' in s:return s['extra']['delay']
    p=Path(s['path']);tasks={r['task_id']:r for r in csv.DictReader((p/'RESULT/task_accounting.csv').open(encoding='utf-8-sig'))}
    data={'all':[],'high_value':[],'ordinary':[]};seen=set()
    for r in read(p/'RESULT/ground_ledger.json'):
        if not r['valid'] or not r['closes'] or r['task_id'] in seen:continue
        t=tasks[r['task_id']];seen.add(r['task_id'])
        v=r['ground_available_s']-float(t['arrival_s']);data['all'].append(v)
        data['high_value' if t['value_level'] in {'high','urgent'} else 'ordinary'].append(v)
    result={}
    for k,vs in data.items():
        vs.sort();at=(len(vs)-1)*.95;i=max(0,int(at))
        result[k]=dict(n=len(vs),mean_s=statistics.mean(vs) if vs else None,p95_s=vs[i]+(vs[min(i+1,len(vs)-1)]-vs[i])*(at-i) if vs else None)
    return result

def row(s):
    r=flatten(s);r.update(condition=s['condition'],result_path=s['path'],status='COMPLETED_AUDITED')
    for group,label in [('all','all'),('high_value','HV'),('ordinary','ordinary')]:
        g=s['groups'][group]
        for key in ['gross','net','energy_cost','downlink_cost','terminal_cost','closed','tasks']:r[label+'_'+key]=g[key]
        r[label+'_right_censored']=sum(v for k,v in g['status_counts'].items() if k.startswith('right_censored'))
        r[label+'_DDL_failed']=g['status_counts'].get('deadline_elapsed_unclosed',0)
    r['partial_delivered_tasks']=sum(v for k,v in s['ground_state_counts'].items() if k.endswith('_partial'))
    for k,v in s['ground_state_counts'].items():r['ground_'+k]=v
    for k,v in s['peak_temperatures_c'].items():r[k+'_peak_C']=v
    for k,v in s['selected_models'].items():r['selected_'+k]=v
    for k,v in s['mode_seconds'].items():r['mode_seconds_'+k]=v
    for k,v in s.get('candidate_categories',{}).items():r['candidate_'+k]=v
    for k,v in s.get('task_rejection_decision_counts',{}).items():r['distinct_task_rejection_'+k]=v
    for g,d in closure_delay(s).items():
        for k,v in d.items():r['closure_delay_'+g+'_'+k]=v
    r['progressive_authorizations']=s['progressive_authorizations'];r['progressive_ground_events']=s['progressive_ground_events']
    r['thermal_protection_count']=s['thermal_protection_count']
    if 'extra' in s:
        for k,v in s['extra']['expired_tasks_without_any_window'].items():r['expired_no_window_'+k]=v
        for k,v in s['extra']['recovery'].items():
            for field,value in v.items():r['recovery_'+k+'_'+field]=value
    return r

def summarize(out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    records=finished(out);refs=references(out);rr=[row(s) for s in records]
    normal=[row(s) for (seed,arm),s in sorted(refs.items()) if seed in SEEDS]
    csvwrite(out/'COMPLETED_PER_SEED.csv',rr);csvwrite(out/'NORMAL_REFERENCE_PER_SEED.csv',normal)
    write(out/'REFERENCE_STATUS.json',dict(expected=12,available=len(normal),missing=[dict(seed=s,method=m) for s in sorted(SEEDS) for m in ['GROUND','OFFLOAD','TUT_ADAPTED','PROP'] if (s,m) not in refs]))
    groups=defaultdict(list);deltas=[];windows=[];rejections=[]
    for r in [r for r in rr if r['condition']!='NORMAL']+normal:groups[r['condition'],r['method']].append(r)
    for s in records:
        wp=Path(s['path'])/'WINDOW_DELIVERY_BACKLOG.json'
        extra={r['window']:r for r in read(wp)['rows']} if wp.exists() else {}
        for w in s['windows']:windows.append(dict(condition=s['condition'],seed=s['seed'],method=s['arm'],**(w|extra.get(w['window'],{}))))
        for w in s['rejection_reasons']:rejections.append(dict(condition=s['condition'],seed=s['seed'],method=s['arm'],denominator=s['candidate_denominator'],**w))
        base=refs.get((s['seed'],s['arm']))
        if s['condition']=='NORMAL' or not base:continue
        a=row(s);b=row(base)
        for k in ['net','HV_net','gross','HV_gross','HV_closed','ordinary_closed','controlled_J','downlink_MB','Q_end_MB']:
            deltas.append(dict(condition=s['condition'],method=s['arm'],seed=s['seed'],metric=k,value=a[k],normal=b[k],absolute=a[k]-b[k],percent=100*(a[k]-b[k])/abs(b[k]) if b[k] else None))
    csvwrite(out/'PAIRED_NORMAL_DELTAS.csv',deltas);csvwrite(out/'WINDOWS.csv',windows);csvwrite(out/'REJECTIONS.csv',rejections)
    agg=[];progress=[]
    for (condition,method),rows in sorted(groups.items()):
        progress.append(dict(condition=condition,method=method,n=len(rows),seeds=sorted(r['seed'] for r in rows),complete={r['seed'] for r in rows}==SEEDS))
        if {r['seed'] for r in rows}!=SEEDS:continue
        for metric in sorted(set().union(*(r.keys() for r in rows))):
            if metric=='seed':continue
            values=[r.get(metric) for r in rows]
            if all(isinstance(v,(int,float)) and not isinstance(v,bool) for v in values):
                agg.append(dict(condition=condition,method=method,metric=metric,n=3,mean=statistics.mean(values),sample_sd=statistics.stdev(values),ddof=1))
    csvwrite(out/'THREE_SEED_MEAN_SD.csv',agg);write(out/'AGGREGATION_STATUS.json',progress)
    plot=[]
    for r in agg:
        if r['metric'] not in {'net','HV_net'}:continue
        for family,conditions in [('capacity',['A1','A2','NORMAL','A3']),('value',['NORMAL','A4','A5']),('outage',['NORMAL','B1','B2'])]:
            if r['condition'] in conditions:plot.append(dict(analysis=family,**r))
    csvwrite(out/'SENSITIVITY_PLOT_DATA.csv',plot)
    lines=['# 已完成结果与正常参照','','仅纳入通过全部审计的21600秒结果。少于三个配对种子的条件不填误差条；正常参照只使用因果时延版TUT。',
        f'','正常参照：'+str(len(normal))+'/12。四个额外正常TUT作业与84次敏感性实验分开计数。',
        '','|条件|方法|种子|净效用|HV净效用|HV闭环|普通闭环|','|---|---|---:|---:|---:|---:|---:|']
    for r in normal+[r for r in rr if r['condition']!='NORMAL' or r['seed'] not in SEEDS]:lines.append(f"|{r['condition']}|{r['method']}|{r['seed']}|{r['net']:.6f}|{r['HV_net']:.6f}|{r['HV_closed']}|{r['ordinary_closed']}|")
    lines+=['','原冻结TUT不混入；旧正式GROUND/OFFLOAD/PROP沿用已审计结果，适配层零扰动短测证明策略与物理等价。',
        '时延仅统计实际按期满足需求的闭环任务。安全候选拒绝、独立任务数与实际违规分别列示。GROUND地面产品层级不代表星上发送了该产品。',
        '有限6h观察期，尚未到DDL且未闭环保持右删失。桌面耗时不是实测星上计算开销。']
    (out/'00_RESULTS_CN.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return rr

def export_reference_update(out):
    out=Path(out);rows=[s for s in finished(out) if s['condition']=='NORMAL']
    if not rows:return
    ids=verify();names=sorted(s['seed'] for s in rows);suffix='_'.join(map(str,names))
    target=out/f'CAUSAL_TUT_REFERENCE_UPDATE_{suffix}.zip'
    if target.exists():return
    files={};data={};entries=[]
    for s in rows:
        prefix=f"{s['seed']}_TUT_ADAPTED";entries.append(dict(seed=s['seed'],arm='TUT_ADAPTED',path=prefix))
        for f in REFERENCE_FILES:
            path=Path(s['path'])/f;key=prefix+'/'+f;data[key]=path.read_bytes();files[key]=hashlib.sha256(data[key]).hexdigest()
    meta=dict(source_manifest_sha256=ids['SOURCE_MANIFEST.json'],input_manifest_sha256=ids['INPUT_MANIFEST.json'],rows=entries,files=files,normal_conditions_only=True)
    with zipfile.ZipFile(str(target)+'.tmp','w',zipfile.ZIP_DEFLATED) as z:
        for key,value in data.items():z.writestr(key,value)
        z.writestr('REFERENCE_UPDATE.json',json.dumps(meta,ensure_ascii=False,indent=2))
    os.replace(str(target)+'.tmp',target)
    write(out/'LATEST_REFERENCE_EXPORT.json',dict(path=str(target),sha256=sha(target),seeds=names,three_seed_normal_ready={4101,4103}<=set(names)))

def import_reference(path):
    ids=verify();path=Path(path);tag=sha(path);dest=ROOT/'reference_updates'/tag
    with zipfile.ZipFile(path) as z:
        m=json.loads(z.read('REFERENCE_UPDATE.json'))
        assert m['source_manifest_sha256']==ids['SOURCE_MANIFEST.json'] and m['input_manifest_sha256']==ids['INPUT_MANIFEST.json'],'REFERENCE_VERSION_MISMATCH'
        for r in m['rows']:
            assert r['arm']=='TUT_ADAPTED' and r['seed'] in {4101,4103,4104,4105}
            prefix=r['path'];v=json.loads(z.read(prefix+'/VERIFIED_COMPLETE.json'))
            expected=next(j for j in read(ROOT/'SENSITIVITY_MATRIX.json')['jobs'] if j['job_id']==f"NORMAL_{r['seed']}_TUT_ADAPTED")
            assert v['job']==expected and v['source']==ids and v['sensitivity_audit']['pass_']
        for rel,h in m['files'].items():
            p=dest/rel
            assert p.resolve().is_relative_to(dest.resolve()) and hashlib.sha256(z.read(rel)).hexdigest()==h
        dest.mkdir(parents=True,exist_ok=True)
        for rel in m['files']:
            p=dest/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(rel))
        write(dest/'REFERENCE_UPDATE.json',m)
    print('Imported normal causal TUT references:',[r['seed'] for r in m['rows']])
