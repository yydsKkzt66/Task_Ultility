"""Isolated TUT scoring correction; synthetic calendars, no parameter search."""
from copy import deepcopy
import json,math
from pathlib import Path
import pytest
from formal_common import ROOT,read,job_for
from formal_worker import execute
from src.network_revision.physics import NetworkPhysics,fingerprint
from src.network_revision.runtime import NetworkExperiment
from test_network_revision_runtime import experiment,interval,action,authorize_mechanism,full_decision_state
from test_network_formal6h import scene

JOB=next(j for j in read(ROOT/'RUN_MATRIX.json')['jobs'] if j['arm']=='TUT_CAUSAL_LATENCY')

def scored(e,t,policy='causal_ground',product='metadata'):
    e.config['tut_latency_policy']=policy
    before=full_decision_state(e)
    c=e.candidate(t,action(e,product,'balanced'))
    assert full_decision_state(e)==before
    return c

def total_latency(c):
    p=c['predicted']
    return p['predicted_L_inf']+p['predicted_L_comm']+p['predicted_L_queue']

@pytest.mark.parametrize('inside',[False,True])
def test_causal_ground_latency_waits_and_ground_processing_once(inside):
    e,t=experiment('TUT',links=[interval(0,20,0),interval(20,60)])
    if inside:
        e.physics.execute(22.);t.arrival_s=22.
    c=scored(e,t)
    assert c['feasible']
    assert total_latency(c)==pytest.approx(c['ground_s']-e.physics.now,abs=1e-8)
    finish=c['projection']['finishes'][c['plan']['item'].product_id]
    assert c['ground_s']-finish==pytest.approx(1.87,abs=1e-8)
    assert c['ready_s']==pytest.approx(e.physics.now+1.44+.43)
    assert c['score']['tut_detail']['latency_available']
    if not inside:assert total_latency(c)>20.

def test_waiting_cpu_serialization_and_physical_parity():
    e,t=experiment('TUT')
    old=deepcopy(t);old.task_id='already_authorized'
    e.arrived[old.task_id]=old
    authorize_mechanism(e,old,infer_s=5.,encoding_s=2.)
    legacy=scored(e,t,'legacy_proxy')
    causal=scored(e,t)
    assert causal['feasible'] and causal['ready_s']==pytest.approx(8.87)
    for k in ('plan','projection','feasible','reasons','ground_s','size_mb','energy_j','ready_s','profile','guidance'):
        assert fingerprint(legacy[k])==fingerprint(causal[k]),k
    assert total_latency(causal)==pytest.approx(causal['ground_s']-e.physics.now,abs=1e-8)
    assert total_latency(legacy)!=pytest.approx(total_latency(causal))
    assert legacy['score']['tut_guidance']==causal['score']['tut_guidance']
    assert causal['plan']['q']==.697529100765
    assert causal['plan']['inference_j']==21.6
    assert causal['size_mb']==.002

@pytest.mark.parametrize('late_ground',[False,True])
def test_missing_delivery_or_ground_after_horizon_is_hard_rejected(late_ground):
    links=[interval(0,60,0)] if not late_ground else [interval(0,58.5,0),interval(58.5,60)]
    e,t=experiment('TUT',links=links)
    c=scored(e,t)
    assert not c['feasible']
    assert 'NO_EXECUTABLE_SERVICE_BEFORE_DEADLINE' in c['reasons']
    detail=c['score']['tut_detail']
    if c['ground_s'] is None:
        assert detail['causal_ground_delay_s'] is None and not detail['latency_available']
    else:assert c['ground_s']>60.

@pytest.mark.parametrize('method',['PROP','OFFLOAD','MYOPIC'])
def test_flag_does_not_change_other_methods(method):
    e,t=experiment(method)
    a=scored(e,t,'legacy_proxy');b=scored(e,t)
    assert fingerprint(a)==fingerprint(b)

def test_config_is_exactly_one_latency_policy_addition():
    old=job_for(JOB['seed'],'TUT_ADAPTED')
    a=read(ROOT/'configs/network_revision'/f"{old['variant']}.json")
    b=read(ROOT/'configs/network_revision'/f"{JOB['variant']}.json")
    a['variant']=b['variant'];a['tut_latency_policy']='causal_ground'
    assert a==b and JOB['input_hashes']==old['input_hashes']

def causal_scene():
    e=scene('TUT_ADAPTED');e.variant=JOB['variant'];e.config['variant']=JOB['variant'];e.config['tut_latency_policy']='causal_ground'
    return e

def test_eventful_delivery_and_exact_checkpoint_restore(tmp_path):
    a=causal_scene();execute(JOB,tmp_path/'straight',stop=120.,experiment=a,identities={'synthetic':'causal'})
    b=causal_scene();execute(JOB,tmp_path/'first',stop=60.,experiment=b,identities={'synthetic':'causal'})
    c=execute(JOB,tmp_path/'resumed',stop=120.,resume=tmp_path/'first/CHECKPOINTS/T00060.pkl',identities={'synthetic':'causal'})
    assert a.physics.identity()==c.physics.identity()
    assert a.decisions==c.decisions and a.ground_ledger==c.ground_ledger
    assert a.evaluate()['costs']==c.evaluate()['costs']
    assert len(a.arrived)==8 and a.closed and a.physics.flows
    assert {v['model'] for v in a.physics.products.values()}=={'balanced'}
    assert not a.pending and not a.staged_requests
    assert not any(v.get('continuation') for v in a.physics.products.values())
    assert read(tmp_path/'straight/AUDIT.json')['pass']

def test_crosswindow_authorized_bytes_continue_without_new_product():
    e,t=experiment('TUT');e.config['tut_latency_policy']='causal_ground'
    e.physics=NetworkPhysics(e.config['physics']['network'],e.cfg['simulator'],[interval(0,2),interval(2,20,0),interval(20,22),interval(22,60,0)])
    authorize_mechanism(e,t,'roi_context',size=2.7,infer_s=0.,infer_j=0.,encoding_s=0.,encoding_j=0.,ground_s=1.87)
    e.advance_slot_events(20.,0)
    assert e.physics.order[0].remaining_bits==5_600_000
    e.advance_slot_events(40.,1)
    assert sum(f['business_bits'] for f in e.physics.flows)==21_600_000
    assert len(e.physics.products)==1 and len(e.ground_ledger)==1
    assert e.ground_ledger[0]['ground_available_s']==pytest.approx(22.57)
    assert not e.pending and not e.staged_requests
