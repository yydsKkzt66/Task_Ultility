from pathlib import Path
from copy import deepcopy
from dataclasses import replace
import math,json,csv
import pytest
from formal_common import ROOT,read,dump_checkpoint,load_checkpoint
from formal_worker import execute
from src.network_revision.runtime import NetworkExperiment
from src.network_revision.physics import NetworkPhysics
from sensitivity_scenarios import SensitivityExperiment,additional_audit
from test_network_revision_runtime import interval,action,full_decision_state,authorize_mechanism

def job(condition='NORMAL',arm='TUT_ADAPTED',seed=4101):
    return next(j for j in read(ROOT/'SENSITIVITY_MATRIX.json')['jobs'] if j['condition']==condition and j['arm']==arm and j['seed']==seed)

def small(method='PROP',outage=None,plain=False):
    j=job();cls=NetworkExperiment if plain else SensitivityExperiment
    e=cls(ROOT,j['variant'],method,trace=False);e.fast_nonpositive_bound=True
    e.config['horizon_s']=160.;e.config['incremental_pricing']['formal_settlement_s']=160.
    links=[interval(0,20,0),interval(20,30,8e6,'one'),interval(30,40,0),interval(40,60,8e6,'two'),interval(60,80,0),interval(80,100,8e6,'three'),interval(100,120,0),interval(120,140,8e6,'four'),interval(140,160,0)]
    e.physics=NetworkPhysics(e.config['physics']['network'],e.cfg['simulator'],links)
    tasks=[]
    for i,t in enumerate([1.,1.,1.1,39.999,40.,79.999,99.999,121.,141.]):
        x=deepcopy(e.tasks[0]);x.task_id=f'synthetic_{i}';x.arrival_s=t;x.arrival_slot=int(t//20)
        x.task_value=x.calibrated_task_value=10.;x.value_level='high';x.high_value_flag=1;x.emergency_flag=0
        x.deadline_s=180.;x.deadline_time_s=t+180.;x.product_requirement='evidence';x.information_requirement=x.quality_requirement=.1;tasks.append(x)
    e.tasks=tasks
    if not plain:
        e.normal_links=tuple(links);e.factor=dict(e.factor,outage=outage,main_value_total=90.)
    return e

@pytest.mark.parametrize('method',['PROP','B1','OFFLOAD','TUT'])
def test_zero_disturbance_exact_decisions_execution_and_accounting(method):
    a=small(method,plain=True);b=small(method)
    a.run(160.,full_scope='formal');b.run(160.,full_scope='formal')
    assert a.decisions==b.decisions and a.ground_ledger==b.ground_ledger
    assert a.physics.identity()==b.physics.identity()
    assert a.evaluate()==b.evaluate()

@pytest.mark.parametrize('method',['PROP','B1','OFFLOAD','TUT'])
@pytest.mark.parametrize('outage',[[40.,60.],[40.,100.]])
def test_no_future_leak_notification_no_service_and_recovery(method,outage):
    a=small(method);b=small(method,outage)
    a.run(40.);b.run(40.)
    assert a.decisions==b.decisions and a.physics.identity()==b.physics.identity()
    assert a.ground_ledger==b.ground_ledger and not b.outage_announced
    before=b.physics.identity();cache=dict(b.physics.inference_cache)
    b.environment_event(40.)
    assert b.physics.identity()==before and b.physics.inference_cache==cache
    assert b.outage_announced and not b.physics.kernel._projection_cache
    assert b.physics.kernel.link_at(40.).business_rate_bit_s==0
    assert b.physics.kernel.offered_bits_between(*outage)==0
    b.run(160.,full_scope='formal')
    assert not any(f['start_s']<outage[1] and f['end_s']>40. for f in b.physics.flows)
    assert any(f['start_s']>=outage[1] for f in b.physics.flows)
    assert b.recovery_backlog['time_s']==outage[1]
    assert len(b.arrived)==9
    assert b.evaluate()['task_status']['synthetic_8'].startswith('right_censored')

@pytest.mark.parametrize('name,mult',[('A1',.15),('A2',.30),('A3',.90)])
def test_absolute_capacity_and_environment_preserved(name,mult):
    j=job(name,'PROP');e=SensitivityExperiment(ROOT,j['variant'],'PROP')
    for before,after in zip(e.normal_links,e.physics.kernel.links):
        assert after.business_rate_bit_s==pytest.approx(before.business_rate_bit_s*mult/.5)
        for k in ['start_s','end_s','solar_power_w','absorbed_external_w','tx_dc_power_w','window_id']:
            assert getattr(before,k)==getattr(after,k)
    assert sum(x.business_rate_bit_s*(x.end_s-x.start_s) for x in e.physics.kernel.links)==pytest.approx(sum(x.business_rate_bit_s*(x.end_s-x.start_s) for x in e.normal_links)*mult/.5)

@pytest.mark.parametrize('name',['A4','A5'])
def test_values_final_prior_normalized_once_and_other_attributes_same(name):
    j=job(name,'PROP');e=SensitivityExperiment(ROOT,j['variant'],'PROP');n=small()
    old=NetworkExperiment(ROOT,f'incremental_formal_{j["seed"]}_prop','PROP')
    assert math.fsum(t.task_value for t in e.tasks)==pytest.approx(math.fsum(t.task_value for t in old.tasks),abs=1e-9)
    assert e.config['public_prices']==old.config['public_prices']
    ratios={}
    for a,b in zip(e.tasks,old.tasks):
        assert a.task_id==b.task_id and a.deadline_time_s==b.deadline_time_s and a.metadata==b.metadata
        assert a.product_requirement==b.product_requirement and a.arrival_s==b.arrival_s
        assert a.task_value==a.calibrated_task_value
        ratios.setdefault(a.value_level,set()).add(round(a.task_value/b.task_value,12))
    assert all(len(v)==1 for v in ratios.values()) and len({next(iter(v)) for v in ratios.values()})>1

def test_checkpoint_resume_outage_and_public_audit(tmp_path):
    j=job();a=small('TUT',[40.,100.])
    execute(j,tmp_path/'straight',stop=160.,experiment=a,identities={'test':'same'})
    b=small('TUT',[40.,100.])
    execute(j,tmp_path/'prefix',stop=40.,experiment=b,identities={'test':'same'})
    c=execute(j,tmp_path/'resumed',stop=160.,resume=tmp_path/'prefix/CHECKPOINTS/T00040.pkl',identities={'test':'same'})
    assert a.physics.identity()==c.physics.identity() and a.decisions==c.decisions
    assert a.environment_events==c.environment_events and a.ground_ledger==c.ground_ledger
    assert additional_audit(c,j,tmp_path/'resumed')['pass_']

def test_matrix_scope_and_exact_shared_inputs():
    jobs=read(ROOT/'SENSITIVITY_MATRIX.json')['jobs']
    assert len(jobs)==88 and sum(j['machine']=='B' for j in jobs)==24
    assert sum(j['machine']=='A' and j['group']=='sensitivity' for j in jobs)==60
    assert sum(j['group']=='reference_completion' for j in jobs)==4
    for condition in ['A1','A2','A3','A4','A5','B1','B2']:
        for seed in [4101,4102,4103]:
            jj=[j for j in jobs if j['condition']==condition and j['seed']==seed]
            assert len(jj)==4 and len({j['config_sha256'] for j in jj})==1
