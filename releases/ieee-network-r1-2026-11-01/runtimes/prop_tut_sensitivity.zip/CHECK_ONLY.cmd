@echo off
setlocal
cd /d "%~dp0"
set PYTHONPATH=
set PYTHONNOUSERSITE=1
if exist "%~dp0.venv\Scripts\python.exe" (
  "%~dp0.venv\Scripts\python.exe" "%~dp0sensitivity_run.py" check --out "%~dp0CHECK_ONLY"
) else (
  py -3.11 "%~dp0sensitivity_run.py" check --out "%~dp0CHECK_ONLY"
)
exit /b %errorlevel%
