# IEEE Network 三类敏感性实验：A/B 分机包 V1

本包采用正式6h场景与共同因果到地时延版TUT，使用MockDetector工程代理。它不是实测星上检测或原TUT论文完整复现。旧TUT不得混入本包统计。

## 第二台电脑：解压、安装、检查、启动

推荐 Windows x64、Python 3.11.15，与来源机器一致。其他补丁版只可独立从头运行；断点恢复严格检查Python身份。目录可含中文，不要求D盘或原工程。不要用父工程的PYTHONPATH。

在PowerShell中执行（将ZIP路径替换成实际位置）：

```powershell
Expand-Archive -LiteralPath 'C:\Downloads\NETWORK_SENSITIVITY_B_PORTABLE_V1.zip' -DestinationPath 'C:\NetworkSensitivityB'
Set-Location 'C:\NetworkSensitivityB'
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\CHECK_ONLY.cmd
.\RUN_B.cmd
```

CHECK_ONLY先校验所有源码及输入SHA，再运行22项短测。预期`22 passed`，`CHECK_ONLY/CHECK_ONLY.json`中`pass_=true`、`outside_imports={}`。独立短测包括合成小日历上的真实发送、服务中断、恢复、完整检查点续跑、非零终态Q、既有承诺保护；它不启动B的24次正式实验。

RUN_B只读取`SENSITIVITY_MATRIX.json`中machine=B的24个作业，输出`B_RUNS`。默认4并发，系统内存允许时可用下列命令最多5并发。严禁与RUN_B重复启动：

```powershell
.\.venv\Scripts\python.exe .\sensitivity_run.py launch --machine B --max-workers 5 --out .\B_RUNS
```

保持启动窗口或由系统任务启动。若控制器意外结束，重新运行同一RUN_B命令即可；它验证PID与进程创建时间，已运行的工作进程不重复启动。已完成作业不重跑；已中断作业从最近通过SHA校验的完整检查点恢复到新的attempt目录。失败原目录不删除。审计失败不会自动换参数重试。每个进程数值库线程数固定1，实际并发受提交内存和物理内存余量约束。

## 唯一实验清单与评价

全局清单88项：A敏感性60、B敏感性24、额外正常TUT4；后者不计入84项敏感性。B的显式24项副本在`RUN_MATRIX_B.json`，执行身份以全局清单为准。

每次1600任务、21600秒；low322/medium830/high323/urgent125，HV448/普通1152；三个配对种子4101–4103。保留原DDL，不强制到期清空。20秒宏步，200秒Mode；四窗[3600,4200)、[9300,9900)、[15000,15600)、[20700,21300)。背景8.86W，6h背景191376J，单列于可控能耗之外。

- B1：[9300,9900)没有地面服务。
- B2：[9300,15600)连续没有地面服务。
- 9300前只看到正常日历；9300时在该时刻控制、决策、发送前同时通知。日照/外部热与任务到达不改，保留消耗、字节、推理缓存、队列与DDL。仅服务日历和依赖它的预测缓存更新。
- 本版不复用跨条件前缀：没有已独立验证的同版本中断前检查点，全部从共同初态开始，不混用中断后原轨迹。
- A1/A2/A3名义绝对容量倍率0.15/0.30/0.90，冻结输入已含0.50，故比例分别为目标/0.50；A4/A5价值1:2:5:10与1:5:20:50，最终任务先验价值总和逐种子归一到主实验，κ不变。
- 所有方法共用因果物理执行及固定公共计分。GROUND是固定压缩后地面推理；OFFLOAD仍自行LOCAL/GROUND/DEFER；TUT固定Balanced，依据原UoI规则选产品，其时延输入改为共同物理模型的实际可执行到地预测。PROP沿用原完整规则，没有A–H、ROI补救、额外HV授权或温度平滑。

## 正常参照与新版TUT补齐

`references`包含10/12个已审计三种子正常参照：GROUND/OFFLOAD/PROP各3，以及新版TUT4102。TUT4101、4103由A机优先补跑，绝不以旧TUT代替。新版TUT4104、4105也在A机单独补齐五种子主实验，不用于三种子敏感性均值。

A机每当正常TUT完成，会在A_RUNS生成`CAUSAL_TUT_REFERENCE_UPDATE_*.zip`及`LATEST_REFERENCE_EXPORT.json`。从A机复制最新更新包，在B机导入：

```powershell
.\.venv\Scripts\python.exe .\sensitivity_run.py import-reference --reference-zip 'C:\Downloads\CAUSAL_TUT_REFERENCE_UPDATE_4101_4103_4104_4105.zip'
.\.venv\Scripts\python.exe .\sensitivity_run.py summary --out .\B_RUNS
```

更新包文件名以A机实际完成种子为准。导入校验源码、输入、具体作业身份和逐文件SHA，写入独立`reference_updates`，不修改冻结源码或输入。没有正常参照的配对差值留空，缺种子的均值/误差条不生成。B实验可先运行，不必等待参照更新。

## 进度、账本与结果

`B_RUNS/00_PROGRESS_CN.md`和`QUEUE_STATE.json`每60秒更新状态、仿真时间、到达/闭环、墙钟/CPU、RSS、PID和身份。每小时、窗口结束及每180秒活动墙钟保存完整检查点；定点另存账本与执行轨迹。

各attempt包含身份、公共审计、敏感性审计、候选、实际地面事件、实际能耗/下传、轨迹、窗口交付和积压、未到DDL右删失。`VERIFIED_COMPLETE.json`才是可进入敏感性表的最终完成标记。

汇总自动输出`COMPLETED_PER_SEED.csv`、`NORMAL_REFERENCE_PER_SEED.csv`、`PAIRED_NORMAL_DELTAS.csv`、`THREE_SEED_MEAN_SD.csv`、`SENSITIVITY_PLOT_DATA.csv`、`WINDOWS.csv`及`REJECTIONS.csv`。均值和样本标准差ddof=1只在4101–4103均完成时生成。候选拒绝次数、独立任务数、实际安全违规分开；时延以实际按期闭环任务为分母。窗口后到地ACK仍保留在完整地面账本中。

公共审计既定数值容差：时间1e-7秒，能量绝对1e-5J，效用绝对1e-8及相对1e-9，整数比特严格相等。这些是比较容差，不改变任何物理阈值或安全过滤。控制台CPU时间是桌面仿真耗时，不是星上开销。

## 文件与依赖边界

`SOURCE_MANIFEST.json`、`INPUT_MANIFEST.json`、`FILE_SHA256.json`列出实际字节SHA。完整输入、profile、vendor模块均在包内；无需图像下载、真实YOLO模型或本机缓存。历史输入中保留的旧路径只作数据来源元信息，运行入口全部按包根目录解析。仅Python解释器及requirements依赖由本机环境提供。

源码冻结后不在同一正式表中静默混入修复版；需要影响决策或物理的修复时，必须另建版本并明确受影响作业。
