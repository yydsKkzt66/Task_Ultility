@echo off
setlocal
cd /d "%~dp0"
set PYTHONPATH=
set PYTHONNOUSERSITE=1
if exist "%~dp0.venv\Scripts\python.exe" (
  "%~dp0.venv\Scripts\python.exe" "%~dp0sensitivity_run.py" launch --machine A --max-workers 5 --out "%~dp0A_RUNS"
) else (
  py -3.11 "%~dp0sensitivity_run.py" launch --machine A --max-workers 5 --out "%~dp0A_RUNS"
)
exit /b %errorlevel%
