"""Persistent disjoint queues. Full safety/audit, checkpoint recovery, no deadline truncation."""
from pathlib import Path
from datetime import datetime
import argparse,os,sys,time,subprocess,json,csv,statistics
import run,psutil
from formal_common import ROOT,read,write,sha,verify,alive


def stamp():return datetime.now().astimezone().isoformat(timespec='seconds')


def csvout(path,rows):
    if not rows:return
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)


def state(base,children,prefix=False):
    attempts=sorted(p for p in base.glob('attempt_*') if p.is_dir()) if base.exists() else []
    if not attempts:
        for launch in sorted(base.glob('launch_*.json'),reverse=True) if base.exists() else []:
            claim=read(launch)
            child=children.get(str(base/f"attempt_{launch.stem.split('_')[-1]}"))
            if child is not None and child.poll() is None:
                return 'RUNNING',None,dict(pid=claim['pid'])
        return 'PENDING',None,{}
    a=attempts[-1];s=read(a/'STATUS.json') if (a/'STATUS.json').exists() else {}
    marker='COMPLETED.json' if prefix else 'VERIFIED_COMPLETE.json'
    if (a/marker).exists():return 'COMPLETED',a,s
    proc=children.get(str(a))
    if (proc is not None and proc.poll() is None) or alive(s):return 'RUNNING',a,s
    failure=a/'FAILED.json'
    if not failure.exists():failure=a/'WRAPPER_FAILED.json'
    if failure.exists():
        error=read(failure).get('error','')
        transient=any(k in error for k in ['PermissionError','MemoryError','WinError 1455','WinError 32'])
        if not transient:return 'FAILED_REVIEW',a,s
    if len(attempts)>=4:return 'FAILED_RETRY_LIMIT',a,s
    return ('RESUMABLE' if (a/'LATEST_CHECKPOINT.json').exists() else 'RETRY'),a,s


def checkpoint(attempt):return attempt/read(attempt/'LATEST_CHECKPOINT.json')['path']


def start(job,base,children,logs,stop=21600,resume=None):
    base.mkdir(parents=True,exist_ok=True)
    n=len(list(base.glob('attempt_*')))+1;a=base/f'attempt_{n:02d}'
    # Reserve directory through launch state; execute owns its actual mkdir.
    command=[sys.executable,str(ROOT/'worker9h.py'),'--job',job['job_id'],'--package',job['package'],
             '--out',str(a),'--stop',str(stop)]
    if resume:command+=['--resume',str(resume)]
    log=(base/f'attempt_{n:02d}.log').open('ab');logs.append(log)
    p=subprocess.Popen(command,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,
        creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
    children[str(a)]=p
    write(base/f'launch_{n:02d}.json',dict(pid=p.pid,command=command,epoch=time.time()))
    # Covers the interval before the child opens its STATUS; directory polling
    # alone could otherwise launch a duplicate after a very fast refresh.
    time.sleep(.3)
    return a


def report(out,jobs,children,phase,start_epoch,max_workers):
    rows=[];complete=[]
    for j in jobs:
        st,p,s=state(out/j['job_id'],children)
        r=dict(job_id=j['job_id'],condition=j['condition'],method=j['arm'],seed=j['seed'],status=st,
               time_s=s.get('time_s'),arrivals=s.get('arrivals'),closed=s.get('closed'),
               active_wall_s=s.get('active_wall_s'),cpu_s=s.get('cpu_s'),PID=s.get('pid'),
               attempt=str(p) if p else None,config_sha256=j['config_sha256'],
               source_sha256=sha(ROOT/'SOURCE_MANIFEST.json'),input_sha256=j['task_sha256'],
               estimated_remaining_s=None)
        if st=='RUNNING' and s.get('time_s',0)>=4200:
            r['estimated_remaining_s']=s['active_wall_s']/s['time_s']*(21600-s['time_s'])
        if st=='COMPLETED':
            with (p/'METRICS/metrics.csv').open(encoding='utf-8-sig',newline='') as f:m=next(csv.DictReader(f))
            complete.append(dict(job_id=j['job_id'],**m));r.update(net=float(m['overall_net']),HV_net=float(m['hv_net']))
        window=p/'WINDOW_NET.json' if p else None
        if window and window.exists():
            for w in read(window)['rows']:r[f"W{w['window']}_net_HV"]=f"{w['overall_net']:.6f} / {w['HV_net']:.6f}"
        rows.append(r)
    mem=psutil.virtual_memory();elapsed=time.time()-start_epoch
    write(out/'PROGRESS.json',dict(updated=stamp(),phase=phase,max_workers=max_workers,elapsed_s=elapsed,
         target_hours=9,remaining_budget_s=max(0,32400-elapsed),memory_available_MB=mem.available/1e6,rows=rows,
         ETA_note='Per-run cumulative rate after first window; later work may differ; target is not a completion guarantee.'))
    csvout(out/'RUN_STATUS.csv',rows);csvout(out/'COMPLETED_ALL_METRICS.csv',complete)
    if complete:
        groups={}
        for r in complete:groups.setdefault((r['condition'],r['method']),[]).append(r)
        agg=[]
        for (cond,method),rr in groups.items():
            if {int(r['seed']) for r in rr}!=set([4101,4102,4103]):continue
            for k in rr[0]:
                if k in ['job_id','method','condition','seed']:continue
                try:v=[float(r[k]) for r in rr]
                except (ValueError,TypeError):continue
                agg.append(dict(condition=cond,method=method,metric=k,n=3,mean=statistics.mean(v),sample_sd=statistics.stdev(v),ddof=1))
        csvout(out/'COMPLETE_THREE_SEED_MEAN_SD.csv',agg)
    text=['# 新版地面基线敏感性进度','',f'更新时间：{stamp()}；阶段：{phase}；并行上限{max_workers}。',
          f'目标9小时，已用{elapsed/3600:.2f}小时；可用内存{mem.available/1e9:.2f} GB。',
          '窗口数值为累计总体净效用 / HV净效用；阶段值未扣终态Q，最终以21600秒审计结果为准。','',
          '|条件|方法|种子|状态|仿真秒|闭环|PID|W1|W2|W3|W4|终态净效用/HV|',
          '|---|---|---:|---|---:|---:|---:|---|---|---|---|---|']
    for r in rows:
        vals=[r['condition'],r['method'],r['seed'],r['status'],r['time_s'],r['closed'],r['PID']]
        vals += [r.get(f'W{k}_net_HV') for k in [1,2,3,4]]
        vals += [f"{r['net']:.6f} / {r['HV_net']:.6f}" if 'net' in r else None]
        text.append('|'+ '|'.join('—' if v is None else str(v) for v in vals)+'|')
    text+=['','自动从同版检查点恢复进程中断/资源类失败；物理或审计异常保留失败待查，不放行。到9小时仍未完成会继续保存真实进度，不缩短仿真或伪造完成。']
    (out/'00_PROGRESS_CN.md').write_text('\n'.join(text)+'\n',encoding='utf-8')
    return rows


def main():
    p=argparse.ArgumentParser();p.add_argument('--package',choices=['A','B'],required=True)
    p.add_argument('--out',required=True);p.add_argument('--max-workers',type=int,default=4)
    p.add_argument('--detach',action='store_true');p.add_argument('--poll',type=float,default=30)
    a=p.parse_args();assert 1<=a.max_workers<=4 and 5<=a.poll<=60
    ids=verify();assert read(ROOT/'VALIDATION_GATE.json')['pass_']
    out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
    if (out/'SUPERVISOR.json').exists() and alive(read(out/'SUPERVISOR.json')):raise SystemExit('Already running')
    if a.detach:
        command=[sys.executable,str(ROOT/'queue9h.py'),'--package',a.package,'--out',str(out),
                 '--max-workers',str(a.max_workers),'--poll',str(a.poll)]
        log=(out/'supervisor.log').open('ab')
        flags=(subprocess.CREATE_NO_WINDOW|subprocess.CREATE_BREAKAWAY_FROM_JOB) if os.name=='nt' else 0
        child=subprocess.Popen(command,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,
              creationflags=flags,start_new_session=os.name!='nt')
        write(out/'LAUNCH.json',dict(pid=child.pid,command=command,created=stamp()));print('SUPERVISOR_PID',child.pid);return
    jobs=[j for j in read(ROOT/'SENSITIVITY_MATRIX.json')['jobs'] if j['package']==a.package]
    jobs.sort(key=lambda j:j['queue_priority'])
    write(out/'SUPERVISOR.json',dict(pid=os.getpid(),process_created=psutil.Process().create_time(),package=a.package))
    children={};logs=[];lastmem=0;origin=time.time()
    if (out/'START.json').exists():origin=read(out/'START.json')['epoch']
    else:write(out/'START.json',dict(epoch=origin,identities=ids,package=a.package))
    try:
        while True:
            if time.time()-lastmem>=1200:
                with (out/'MEMORY_20MIN.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(dict(epoch=time.time(),**psutil.virtual_memory()._asdict()))+'\n')
                lastmem=time.time()
            states=[(j,*state(out/j['job_id'],children)) for j in jobs]
            active=sum(st=='RUNNING' for _,st,_,_ in states)
            for j,st,folder,s in states:
                if active>=a.max_workers or psutil.virtual_memory().available<3*1024**3:break
                if st not in ['PENDING','RESUMABLE','RETRY']:continue
                resume=checkpoint(folder) if st=='RESUMABLE' else None
                # A previously passed first-window prefix is a same-identity continuation.
                pref=out/'PREFIXES'/j['job_id']
                ps,pa,_=state(pref,children,prefix=True)
                if resume is None and st=='PENDING' and ps=='COMPLETED':resume=checkpoint(pa)
                start(j,out/j['job_id'],children,logs,resume=resume);active+=1
            rows=report(out,jobs,children,'FORMAL_SENSITIVITY',origin,a.max_workers)
            if all(r['status']=='COMPLETED' or r['status'].startswith('FAILED') for r in rows):
                write(out/'FINISHED.json',dict(updated=stamp(),all_completed=all(r['status']=='COMPLETED' for r in rows),rows=rows));break
            time.sleep(a.poll)
    finally:
        for f in logs:f.close()
        write(out/'SUPERVISOR_EXIT.json',dict(pid=os.getpid(),time=stamp()))


if __name__=='__main__':main()
