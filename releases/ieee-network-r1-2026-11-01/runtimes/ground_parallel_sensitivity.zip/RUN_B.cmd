@echo off
setlocal
cd /d "%~dp0"
if not defined PYTHON_EXE set "PYTHON_EXE=python"
"%PYTHON_EXE%" queue9h.py --package B --out "..\B_RUNS" --max-workers 4 --detach
if errorlevel 1 pause
