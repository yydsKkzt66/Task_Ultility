"""Read saved ledgers only. No simulator imports, no replays or source edits.

Usage: python export_run_metrics.py --attempt RUN/attempt_01 --output NEW_DIR
Call after final audit. Outputs are independent derived files, not acceptance
markers. Existing source FAILED records are never changed by this exporter.
"""
from pathlib import Path
from collections import Counter
import argparse
import csv
import hashlib
import json
import math
import statistics

PRODUCTS = ('metadata', 'roi', 'roi_context')
RANK = dict(none=0, metadata=1, roi=2, roi_context=3, alert=1,
            verification=2, context=3, evidence=3)


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def csvread(p):
    with Path(p).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save(p, obj):
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    Path(p).write_text(json.dumps(obj, ensure_ascii=False, indent=2,
                                allow_nan=False) + '\n', encoding='utf-8')


def csvsave(p, rows):
    if not rows:
        raise ValueError('Empty table requires an explicit schema')
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    with Path(p).open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def near(a, b):
    if not math.isclose(float(a), float(b), rel_tol=1e-9, abs_tol=1e-7):
        raise ValueError(('METRIC_MISMATCH', a, b))


def quantile95(values):
    if not values:
        return None
    v = sorted(values)
    x = .95 * (len(v) - 1)
    lo = int(x)
    return v[lo] + (v[min(lo + 1, len(v) - 1)] - v[lo]) * (x - lo)


def mean(values):
    return statistics.mean(values) if values else None


def summarize(attempt):
    attempt = Path(attempt).resolve()
    result = attempt / 'RESULT'
    paths = [result / n for n in ('AUDITED_SUMMARY.json', 'CONFIG_EFFECTIVE.json',
             'task_accounting.csv', 'ground_ledger.json', 'terminal_state.json')]
    paths += [attempt / n for n in ('IDENTITY.json', 'STATUS.json', 'AUDIT.json')]
    if (attempt / 'COMPLETED.json').exists():
        paths.append(attempt / 'COMPLETED.json')
    before = {str(p): sha(p) for p in paths}
    s = read(result / 'AUDITED_SUMMARY.json')
    cfg = read(result / 'CONFIG_EFFECTIVE.json')
    acc = csvread(result / 'task_accounting.csv')
    events = read(result / 'ground_ledger.json')
    terminal = read(result / 'terminal_state.json')
    audit = read(attempt / 'AUDIT.json')
    status = read(attempt / 'STATUS.json')
    identity = read(attempt / 'IDENTITY.json')
    end = float(s['stop_s'])
    assert end == cfg['horizon_s'] == terminal['now_s'] == 21600
    assert s['terminal_settled'] and len(acc) == s['arrivals'] == 1600
    by_id = {r['task_id']: r for r in acc}
    assert len(by_id) == len(acc)
    hv = {r['task_id'] for r in acc if r['HV'] == 'True'}
    assert len(hv) == 448
    first = {}
    highest = dict.fromkeys(by_id, 'none')
    for e in sorted(events, key=lambda e: e['ground_available_s']):
        tid = e['task_id']
        t = by_id[tid]
        available = float(e['ground_available_s'])
        assert available <= end + 1e-9
        assert available >= float(t['arrival_s']) - 1e-9
        if not e['valid']:
            continue
        assert available <= min(float(t['deadline_s']), end) + 1e-9
        product = e['product']
        assert product in PRODUCTS
        if RANK[product] > RANK[highest[tid]]:
            highest[tid] = product
        if RANK[product] >= RANK[t['required']]:
            first.setdefault(tid, available)
    assert set(first) == set(terminal['closed'])
    groups = []
    for group, ids, source_group in [('all', set(by_id), 'all'),
                                     ('HV', hv, 'high_value'),
                                     ('ordinary', set(by_id) - hv, 'ordinary')]:
        rr = [by_id[k] for k in ids]
        costs = {k: math.fsum(float(t[k]) for t in rr)
                 for k in ('gross', 'E_cost', 'B_cost', 'Q_cost')}
        net = costs['gross'] - costs['E_cost'] - costs['B_cost'] - costs['Q_cost']
        times = [first[k] - float(by_id[k]['arrival_s']) for k in ids if k in first]
        g = dict(group=group, arrivals=len(ids), closed=len(times),
                 closure_rate_percent=100 * len(times) / len(ids),
                 gross=costs['gross'], energy_cost=costs['E_cost'],
                 downlink_cost=costs['B_cost'], queue_cost=costs['Q_cost'], net=net,
                 latency_mean_s=mean(times), latency_p95_s=quantile95(times))
        src = s['groups'][source_group]
        for k in ('gross', 'net', 'closed'):
            near(g[k], src[k])
        groups.append(g)
    a, h, o = groups
    row = dict(method=s['arm'], seed=s['seed'],
               condition=cfg.get('sensitivity', {}).get('condition', 'NORMAL'),
               overall_net=s['net'], hv_net=s['groups']['high_value']['net'],
               ordinary_net=s['groups']['ordinary']['net'], overall_gross=s['gross'],
               hv_gross=h['gross'], ordinary_gross=o['gross'],
               energy_cost=s['costs']['energy'], downlink_cost=s['costs']['downlink'],
               queue_cost=s['costs']['terminal_backlog'],
               arrivals=len(acc), hv_arrivals=len(hv), ordinary_arrivals=len(acc)-len(hv),
               hv_closed=h['closed'], ordinary_closed=o['closed'], total_closed=a['closed'],
               hv_closure_rate_percent=h['closure_rate_percent'],
               ordinary_closure_rate_percent=o['closure_rate_percent'],
               closure_rate_percent=a['closure_rate_percent'],
               controllable_energy_kj=s['ledger']['controlled_j']/1000,
               downlink_mb=s['ledger']['downlink_mb'],
               latency_mean_s=a['latency_mean_s'], latency_p95_s=a['latency_p95_s'],
               hv_latency_mean_s=h['latency_mean_s'], hv_latency_p95_s=h['latency_p95_s'],
               ordinary_latency_mean_s=o['latency_mean_s'], ordinary_latency_p95_s=o['latency_p95_s'])
    for p in PRODUCTS:
        row[p + '_satisfied'] = sum(highest[k] == p and k in first for k in by_id)
        row[p + '_partial'] = sum(highest[k] == p and k not in first for k in by_id)
        row[p + '_total'] = row[p + '_satisfied'] + row[p + '_partial']
    row['partial_only'] = sum(row[p + '_partial'] for p in PRODUCTS)
    row['effective_delivered'] = sum(row[p + '_total'] for p in PRODUCTS)
    row['no_valid_product'] = len(acc) - row['effective_delivered']
    row['right_censored_tasks'] = sum(k not in first and float(r['deadline_s']) > end
                                      for k, r in by_id.items())
    row['deadline_failed_tasks'] = len(acc)-row['total_closed']-row['right_censored_tasks']
    row['fixed_cost'] = row['energy_cost']+row['downlink_cost']+row['queue_cost']
    row.update(actual_safety_violations=s['actual_safety_violations'],
               thermal_wait_s=s['thermal_wait_s'], min_soc=s['min_soc'],
               chip_peak_c=s['peak_temperatures_c']['chip'], rf_peak_c=s['peak_temperatures_c']['rf'],
               active_wall_s=status.get('active_wall_s'), cpu_s=status.get('cpu_s'),
               peak_rss_bytes=status.get('peak_rss_bytes'))
    for value, source in [(a['net'], s['net']), (a['gross'], s['gross']),
                          (a['energy_cost'], row['energy_cost']),
                          (a['downlink_cost'], row['downlink_cost']),
                          (a['queue_cost'], row['queue_cost'])]:
        near(value, source)
    prices = cfg['public_prices']
    near(row['controllable_energy_kj']/3.6*prices['energy_price_per_Wh'], row['energy_cost'])
    near(row['downlink_mb']*prices['downlink_price_per_MB'], row['downlink_cost'])
    near(row['overall_gross']-row['fixed_cost'], row['overall_net'])
    task_rows = []
    for tid, r in by_id.items():
        assert highest[tid] == r['highest_effective_ground_product']
        assert (tid in first) == (r['satisfies_requirement'] == 'True')
        assert (highest[tid] != 'none' and tid not in first) == (r['partial_only'] == 'True')
        task_rows.append(dict(task_id=tid, HV=tid in hv, arrival_s=float(r['arrival_s']),
                              deadline_s=float(r['deadline_s']), required=r['required'],
                              highest_valid_product=highest[tid], closed=tid in first,
                              classification='fulfilled' if tid in first else
                              'partial' if highest[tid] != 'none' else 'none',
                              status=r['status'], first_closure_s=first.get(tid),
                              closure_latency_s=first[tid]-float(r['arrival_s']) if tid in first else None))
    assert before == {str(p): sha(p) for p in paths}, 'SOURCE_CHANGED_DURING_READ'
    evidence = dict(source_attempt=str(attempt), source_hashes=before,
                    ground_version=cfg.get('ground_processing'), execution_manifests=identity['manifests'],
                    original_audit_pass=audit['pass'], original_failures=audit['failures'],
                    strict_completion_marker=(attempt/'COMPLETED.json').exists(),
                    metric_reconciliation_pass=True, simulations_run=0,
                    qualification='Metric reconciliation only; never replaces physical audit or grants exception acceptance.')
    return row, groups, task_rows, evidence


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    attempt, output = args.attempt.resolve(), args.output.resolve()
    if output == attempt or attempt in output.parents:
        raise ValueError('Output must be separate from source attempt')
    if output.exists() and any(output.iterdir()):
        raise ValueError('Use an empty output directory to preserve previous exports')
    row, groups, tasks, evidence = summarize(attempt)
    csvsave(output/'metrics.csv', [row])
    csvsave(output/'group_metrics.csv', groups)
    csvsave(output/'task_product_and_closure.csv', tasks)
    save(output/'METRIC_RECONCILIATION.json', evidence)
    print(json.dumps(row, ensure_ascii=False))


if __name__ == '__main__':
    main()
