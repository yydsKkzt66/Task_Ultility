"""New independent run wrapper: frozen physics/policies, scenario, exact clock, metrics."""
from pathlib import Path
import argparse,sys,time,traceback
import run
from formal_common import ROOT,read,write,verify
from exact_arrival import install
install(ROOT)
from sensitivity_scenarios import SensitivityExperiment,additional_audit
from formal_worker import execute
from export_run_metrics import summarize,csvsave,save


def worker(args):
    identities=verify()
    job=next(j for j in read(ROOT/'SENSITIVITY_MATRIX.json')['jobs'] if j['job_id']==args.job)
    if args.package and job['package']!=args.package: raise ValueError('PACKAGE_SCOPE_MISMATCH')
    try:
        e=None if args.resume else SensitivityExperiment(ROOT,job['variant'],job['method'])
        e=execute(job,args.out,stop=args.stop,resume=args.resume,experiment=e,identities=identities)
        write(Path(args.out)/'ARRIVAL_TAIL_EVENTS.json',dict(records=getattr(e,'exact_arrival_tail_records',[])))
        if args.stop==21600:
            check=additional_audit(e,job,args.out)
            if not check['pass_']:raise ValueError('SENSITIVITY_AUDIT_FAILED')
            row,groups,tasks,evidence=summarize(args.out)
            assert evidence['original_audit_pass'] and evidence['strict_completion_marker']
            dest=Path(args.out)/'METRICS'
            csvsave(dest/'metrics.csv',[row]);csvsave(dest/'group_metrics.csv',groups)
            csvsave(dest/'task_product_and_closure.csv',tasks)
            save(dest/'METRIC_RECONCILIATION.json',evidence)
            write(Path(args.out)/'VERIFIED_COMPLETE.json',dict(job=job,manifests=identities,
                source_audit_pass=True,sensitivity_audit_pass=True,metrics_pass=True,epoch=time.time()))
    except BaseException as error:
        folder=Path(args.out);folder.mkdir(parents=True,exist_ok=True)
        write(folder/'WRAPPER_FAILED.json',dict(error=repr(error),traceback=traceback.format_exc(),epoch=time.time()))
        raise


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--job',required=True);p.add_argument('--out',required=True)
    p.add_argument('--package',choices=['A','B']);p.add_argument('--resume');p.add_argument('--stop',type=float,default=21600)
    worker(p.parse_args())
