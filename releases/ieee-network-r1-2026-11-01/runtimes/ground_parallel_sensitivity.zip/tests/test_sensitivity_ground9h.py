from pathlib import Path
from copy import deepcopy
from dataclasses import replace
import math,json
import pytest
from formal_common import ROOT,read,sha
from formal_worker import execute
from src.network_revision.runtime import NetworkExperiment
from src.network_revision.physics import NetworkPhysics
from sensitivity_scenarios import SensitivityExperiment,additional_audit
from test_network_revision_runtime import interval


def job(condition='A1',arm='GROUND',seed=4101):
    return next(j for j in read(ROOT/'SENSITIVITY_MATRIX.json')['jobs']
                if j['condition']==condition and j['arm']==arm and j['seed']==seed)


def small(method,plain=False,outage=None,condition='NORMAL'):
    variant='incremental_ground_parallel_normal_test_4101' if condition=='NORMAL' else job(condition)['variant']
    e=(NetworkExperiment if plain else SensitivityExperiment)(ROOT,variant,method,trace=False)
    assert e.incremental and e.physics.ground_processing['policy']=='independent_fixed'
    e.config['horizon_s']=160.;e.config['incremental_pricing']['formal_settlement_s']=160.
    links=[interval(0,20,0),interval(20,30,8e6,'one'),interval(30,40,0),
           interval(40,60,8e6,'two'),interval(60,80,0),interval(80,100,8e6,'three'),
           interval(100,120,0),interval(120,140,8e6,'four'),interval(140,160,0)]
    e.physics=NetworkPhysics(e.config['physics']['network'],e.cfg['simulator'],links,
                            ground_processing=e.config['ground_processing'])
    tasks=[]
    for i,t in enumerate([1.,1.,1.1,39.999,40.,79.999,99.999,121.,141.]):
        x=deepcopy(e.tasks[0]);x.task_id=f'synthetic_{i}';x.arrival_s=t;x.arrival_slot=int(t//20)
        x.task_value=x.calibrated_task_value=10.;x.value_level='high';x.high_value_flag=1;x.emergency_flag=0
        x.deadline_s=180.;x.deadline_time_s=t+180.;x.product_requirement='evidence'
        x.information_requirement=x.quality_requirement=.1;tasks.append(x)
    e.tasks=tasks
    if not plain:e.normal_links=tuple(links);e.factor=dict(e.factor,outage=outage,main_value_total=90.)
    return e


@pytest.mark.parametrize('method',['B1','OFFLOAD'])
def test_zero_disturbance_scientific_parity(method):
    a,b=small(method,plain=True),small(method)
    a.run(160.,full_scope='formal');b.run(160.,full_scope='formal')
    assert a.physics.identity()==b.physics.identity()
    assert a.decisions==b.decisions and a.candidates==b.candidates and a.ground_ledger==b.ground_ledger
    assert a.evaluate()==b.evaluate()


@pytest.mark.parametrize('method',['B1','OFFLOAD'])
@pytest.mark.parametrize('outage',[[40.,60.],[40.,100.]])
def test_outage_hidden_then_announced_no_service_and_recovery(method,outage):
    a,b=small(method),small(method,outage=outage)
    a.run(40.);b.run(40.)
    assert a.decisions==b.decisions and a.physics.identity()==b.physics.identity() and not b.outage_announced
    before=b.physics.identity();cache=dict(b.physics.inference_cache)
    b.environment_event(40.)
    assert b.physics.identity()==before and b.physics.inference_cache==cache
    assert b.physics.kernel.offered_bits_between(*outage)==0
    b.run(160.,full_scope='formal')
    assert not any(f['start_s']<outage[1] and f['end_s']>40 for f in b.physics.flows)
    assert any(f['start_s']>=outage[1] for f in b.physics.flows)
    assert b.recovery_backlog['time_s']==outage[1]
    assert len(b.arrived)==9
    assert all(r['ground_available_s']==pytest.approx(r['tx_end_s']+4.29) for r in b.ground_ledger if r['route'] in ['B1','GROUND'])


@pytest.mark.parametrize('method',['B1','OFFLOAD'])
def test_checkpoint_and_observer_do_not_change_execution(method,tmp_path):
    arm='GROUND' if method=='B1' else 'OFFLOAD';j=job(arm=arm)
    a=small(method,outage=[40.,100.],condition='A1')
    # Same execution flags as the frozen worker. Observer-free reference.
    for e in [a]:
        e.fast_nonpositive_bound=True
        if method=='B1':
            for k in ['compact_b1_forecast','b1_canonical_safety','b1_idle_tail_certificate',
                      'b1_completed_prefix_certificate','b1_singleton_prefix_certificate','b1_singleton_bound_certificate']:setattr(e,k,True)
            e.physics.kernel.whole_bit_search_certificate=True
    a.run(160.,full_scope='formal')
    # Dynamic B1 loader creates a fresh module per experiment; formal workers
    # own one experiment/process. Construct each checkpoint test sequentially.
    b=small(method,outage=[40.,100.],condition='A1')
    execute(j,tmp_path/'straight',stop=160.,experiment=b,identities={'test':'same'})
    c=small(method,outage=[40.,100.],condition='A1')
    execute(j,tmp_path/'prefix',stop=40.,experiment=c,identities={'test':'same'})
    d=execute(j,tmp_path/'resumed',stop=160.,resume=tmp_path/'prefix/CHECKPOINTS/T00040.pkl',identities={'test':'same'})
    assert a.physics.identity()==b.physics.identity()==d.physics.identity()
    assert a.decisions==b.decisions==d.decisions
    assert a.ground_ledger==b.ground_ledger==d.ground_ledger
    assert additional_audit(d,j,tmp_path/'resumed')['pass_']


@pytest.mark.parametrize('condition',['A1','A2','A3','A4','A5','B1','B2'])
@pytest.mark.parametrize('seed',[4101,4102,4103])
def test_all_real_inputs_flags_capacity_and_normalization(condition,seed):
    j=job(condition,seed=seed);e=SensitivityExperiment(ROOT,j['variant'],'B1',trace=False)
    normal=NetworkExperiment(ROOT,f'incremental_ground_parallel_{seed}','B1',trace=False)
    assert e.incremental and len(e.tasks)==1600 and e.config['horizon_s']==21600
    assert e.config['public_prices']==normal.config['public_prices']
    assert e.physics.ground_processing==normal.physics.ground_processing
    assert math.fsum(t.task_value for t in e.tasks)==pytest.approx(math.fsum(t.task_value for t in normal.tasks),abs=1e-9)
    for x,y in zip(e.physics.kernel.links,normal.physics.kernel.links):
        assert x.business_rate_bit_s==pytest.approx(y.business_rate_bit_s*e.factor['capacity_multiplier']/.5)
        for k in ['start_s','end_s','solar_power_w','absorbed_external_w','tx_dc_power_w','window_id']:assert getattr(x,k)==getattr(y,k)
    for x,y in zip(e.tasks,normal.tasks):
        assert x.task_id==y.task_id and x.arrival_s==y.arrival_s and x.deadline_time_s==y.deadline_time_s
        assert x.product_requirement==y.product_requirement and x.metadata==y.metadata


def test_matrix_disjoint_complete_same_config_and_scientific_source():
    jobs=read(ROOT/'SENSITIVITY_MATRIX.json')['jobs']
    assert len(jobs)==len({j['job_id'] for j in jobs})==42
    assert sum(j['package']=='A' for j in jobs)==22
    assert sum(j['package']=='B' for j in jobs)==20
    for c in ['A1','A2','A3','A4','A5','B1','B2']:
        for s in [4101,4102,4103]:
            jj=[j for j in jobs if j['condition']==c and j['seed']==s]
            assert len(jj)==2 and len({j['config_sha256'] for j in jj})==1
            for j in jj:assert j['variant'].startswith('incremental') and sha(ROOT/f'configs/network_revision/{j["variant"]}.json')==j['config_sha256']


def test_exact_arrival_uses_integrator_and_refuses_unsafe_tail():
    from exact_arrival import install
    install(ROOT)
    e=small('B1');e.physics.execute(1.-4.5e-11)
    e._finish_exact_arrival(1.)
    assert e.physics.now==1. and e.physics.trajectory[-1]['thermal']['safe']
    bad=small('B1');bad.physics.execute(1.-4.5e-11)
    bad.physics.state=replace(bad.physics.state,temperatures_c=tuple(100. for _ in bad.physics.state.temperatures_c))
    with pytest.raises(RuntimeError,match='EXECUTION_SAFETY_STOP'):bad._finish_exact_arrival(1.)
