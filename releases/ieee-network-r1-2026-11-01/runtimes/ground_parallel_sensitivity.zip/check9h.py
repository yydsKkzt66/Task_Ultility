"""Bounded portable checks; no full formal experiment is started."""
from pathlib import Path
import argparse,sys,time
import run
from formal_common import ROOT,verify,write
from exact_arrival import install
install(ROOT)
sys.path.insert(0,str(ROOT/'tests'))

def main():
    import pytest
    p=argparse.ArgumentParser();p.add_argument('--out',default=str(ROOT.parent/'CHECK_OUTPUT'))
    p.add_argument('--development',action='store_true');a=p.parse_args()
    out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
    ids={} if a.development else verify();start=time.perf_counter()
    code=pytest.main(['-q','-p','no:cacheprovider',str(ROOT/'tests/test_sensitivity_ground9h.py'),
         str(ROOT/'tests/test_ground_parallel.py'),'--basetemp='+str(out/'temp'),
         '--junitxml='+str(out/'pytest.xml')])
    imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items()
             if n.startswith(('src.','formal_','sensitivity_','exact_arrival')) and getattr(m,'__file__',None)}
    outside={n:p for n,p in imports.items() if not Path(p).is_relative_to(ROOT)}
    result=dict(pass_=code==0 and not outside,pytest_exit=code,seconds=time.perf_counter()-start,
                imports=imports,outside_imports=outside,manifests=ids,python=sys.version,
                scope='Synthetic bounded mechanisms and real-input initialization; no complete formal run')
    write(out/'CHECK_ONLY.json',result);print('CHECK_PASSED',result['pass_'])
    raise SystemExit(0 if result['pass_'] else 1)

if __name__=='__main__':main()
