"""Unitful four-node diagnostic network; no implicit physical parameters.

The chip fit is conditional on the board boundary. Coupling it to the other
nodes requires separately sourced/author-approved parameters. Numerical test
parameters never qualify an eight-task physical scenario.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from collections import OrderedDict
from copy import deepcopy
import math
from typing import Mapping

import numpy as np
from scipy.integrate import solve_ivp
from scipy.integrate._ivp.rk import RK45, RkDenseOutput

NODES = ("chip", "board", "rf", "structure")
CC = 47.60011123461153
GCB = 0.24734214312372577
POTHER = 3.8652491912914764
SIGMA = 5.670374419e-8


class _ScalarDenseOutput(RkDenseOutput):
    """Same RK45 interpolation without the broken local BLAS GEMM entry."""
    def _call_impl(self, t):
        def one(at):
            x = (float(at)-self.t_old)/self.h
            return [float(y)+self.h*sum(float(q)*x**(j+1) for j,q in enumerate(row))
                    for y,row in zip(self.y_old,self.Q)]
        return np.asarray(one(t)) if np.ndim(t)==0 else np.asarray([one(at) for at in t]).T


class _ScalarDenseRK45(RK45):
    def _dense_output_impl(self):
        # Windows research-dl has a known native small-matrix failure. Keep
        # scipy's coefficients/error control; only multiply the tiny dense
        # output coefficient matrices in Python, without global monkeypatch.
        # Unoptimized einsum contracts the same seven terms in order, without
        # entering the defective BLAS GEMM. No solver/coefficient change.
        q = np.einsum('ki,kj->ij', self.K, self.P, optimize=False)
        return _ScalarDenseOutput(self.t_old,self.t,self.y_old,q)


class MissingCelsiusParameters(ValueError):
    def __init__(self, fields):
        self.fields = tuple(fields)
        super().__init__("MISSING_CELSIUS_PARAMETERS:" + ",".join(self.fields))


@dataclass(frozen=True)
class CelsiusNetworkParametersV1:
    board_capacity_j_k: float
    rf_capacity_j_k: float
    structure_capacity_j_k: float
    board_structure_conductance_w_k: float
    rf_structure_conductance_w_k: float
    emissivity_area_m2: float
    space_temperature_k: float
    board_idle_power_w: float
    rf_idle_power_w: float
    structure_idle_power_w: float
    rf_escaped_fraction: float
    chip_limit_c: float
    rf_limit_c: float
    chip_uncertainty_margin_c: float
    rf_uncertainty_margin_c: float
    source_by_field: Mapping[str, str]
    qualification: str
    # The following numbers are explicitly authorized, not guessed.
    initial_board_structure_rf_c: float = 15.0
    board_structure_limit_c: float = 30.0
    frozen_background_power_w: float = 8.86

    def __post_init__(self):
        vals = asdict(self)
        for k, v in vals.items():
            if k in {"source_by_field", "qualification"}:
                continue
            if not isinstance(v, (int, float)) or isinstance(v, bool) or not math.isfinite(v):
                raise ValueError("invalid Celsius parameter:" + k)
        for k in ("board_capacity_j_k", "rf_capacity_j_k", "structure_capacity_j_k"):
            if vals[k] <= 0:
                raise ValueError("positive heat capacity required:" + k)
        for k in ("board_structure_conductance_w_k", "rf_structure_conductance_w_k",
                  "emissivity_area_m2", "space_temperature_k", "board_idle_power_w",
                  "rf_idle_power_w", "structure_idle_power_w", "chip_uncertainty_margin_c",
                  "rf_uncertainty_margin_c"):
            if vals[k] < 0:
                raise ValueError("negative thermal parameter:" + k)
        if not 0 <= self.rf_escaped_fraction <= 1:
            raise ValueError("escaped RF fraction must be in [0,1]")
        if not math.isclose(self.board_idle_power_w + self.rf_idle_power_w + self.structure_idle_power_w,
                            self.frozen_background_power_w, abs_tol=1e-9):
            raise ValueError("BACKGROUND_POWER_MUST_BE_ALLOCATED_ONCE")
        if (self.initial_board_structure_rf_c, self.board_structure_limit_c,
                self.frozen_background_power_w) != (15.0, 30.0, 8.86):
            raise ValueError("AUTHOR_FROZEN_INITIAL_LIMIT_OR_BACKGROUND_CHANGED")
        needed = set(vals) - {"source_by_field", "qualification"}
        if not needed <= set(self.source_by_field) or any(not self.source_by_field[k].strip() for k in needed):
            raise ValueError("thermal parameter provenance incomplete")
        if self.qualification not in {"AUTHOR_APPROVED_ENGINEERING_DIAGNOSTIC", "SYNTHETIC_TEST_ONLY"}:
            raise ValueError("unqualified thermal network")
        for n in NODES:
            if self.safe_limits_c[n] <= self.initial_board_structure_rf_c:
                raise ValueError("nonpositive initial node range:" + n)

    @property
    def capacities_j_k(self):
        return dict(zip(NODES, (CC, self.board_capacity_j_k, self.rf_capacity_j_k,
                               self.structure_capacity_j_k)))

    @property
    def safe_limits_c(self):
        return dict(chip=self.chip_limit_c - self.chip_uncertainty_margin_c,
                    board=self.board_structure_limit_c,
                    rf=self.rf_limit_c - self.rf_uncertainty_margin_c,
                    structure=self.board_structure_limit_c)

    def initial_state(self, time_s=0.0):
        board = self.initial_board_structure_rf_c
        chip = board + max(self.board_idle_power_w - POTHER, 0.0) / GCB
        return CelsiusStateV1(time_s, (chip, board, board, board))

    def initial_derivation(self):
        return dict(board_idle_power_w=self.board_idle_power_w, p_other_w=POTHER,
                    chip_idle_heat_w=max(self.board_idle_power_w-POTHER, 0.), g_cb_w_k=GCB,
                    board_c=15., chip_c=self.initial_state().temperatures_c[0],
                    equation="Tc0=15+max(Pboard_idle-Pother,0)/Gcb",
                    qualification=self.qualification)


@dataclass(frozen=True)
class CelsiusStateV1:
    time_s: float
    temperatures_c: tuple[float, float, float, float]

    def __post_init__(self):
        if len(self.temperatures_c) != 4 or not all(math.isfinite(x) and x > -273.15 for x in self.temperatures_c):
            raise ValueError("invalid Kelvin/Celsius node state")
        if not math.isfinite(self.time_s) or self.time_s < 0:
            raise ValueError("invalid thermal event time")

    def to_dict(self):
        return dict(time_s=self.time_s, temperatures_c=dict(zip(NODES, self.temperatures_c)))


@dataclass(frozen=True)
class ThermalPowerV1:
    """All action powers incremental to the separately allocated idle load.

    Board = inference/encoding; RF = frozen TX DC curve including modulation
    if already counted there. Disabled acquisition/modulation adds no load.
    External absorbed heat has no electrical-energy attribution.
    """
    board_incremental_w: float = 0.0
    rf_incremental_dc_w: float = 0.0
    structure_incremental_w: float = 0.0
    absorbed_external_w: float = 0.0
    payload_incremental_w: float = 0.0

    def __post_init__(self):
        if any(not math.isfinite(x) or x < 0 for x in asdict(self).values()):
            raise ValueError("power must be finite nonnegative W")


@dataclass(frozen=True)
class CelsiusTrajectoryV1:
    before: CelsiusStateV1
    after: CelsiusStateV1
    peaks_c: Mapping[str, float]
    peak_times_s: Mapping[str, float]
    headroom_c: Mapping[str, float]
    safe: bool
    ledger_j: Mapping[str, float]
    node_input_heat_j: Mapping[str, float]
    qualification: str

    def to_dict(self):
        return dict(before=self.before.to_dict(), after=self.after.to_dict(),
                    peaks_c=dict(self.peaks_c), peak_times_s=dict(self.peak_times_s),
                    headroom_c=dict(self.headroom_c), safe=self.safe,
                    ledger_j=dict(self.ledger_j), node_input_heat_j=dict(self.node_input_heat_j),
                    qualification=self.qualification, units=dict(temperature="degC", energy="J", power="W"))


class CelsiusThermalNetworkV1:
    """One integrator for forecasts, admission, execution and idle cooling.

    Peak candidates include endpoints and all derivative-zero events resolved
    by the adaptive solver. The step bound is a numerical resolution, not a
    thermal restart temperature or a physical cooling coefficient.
    """
    def __init__(self, parameters: CelsiusNetworkParametersV1, *, max_step_s=1.0, cache_size=2048):
        self.p = parameters
        self.nodes = getattr(parameters, 'nodes', NODES)
        if not math.isfinite(max_step_s) or max_step_s <= 0:
            raise ValueError("positive numerical step required")
        self.max_step_s = max_step_s
        if not isinstance(cache_size,int) or cache_size<0:
            raise ValueError("nonnegative thermal memo capacity required")
        self.cache_size=cache_size
        self._advance_cache=OrderedDict()

    def advance(self, state: CelsiusStateV1, end_s: float, power: ThermalPowerV1,
                *, additional_node_heat_w=None) -> CelsiusTrajectoryV1:
        # Identical immutable physical inputs give identical solver output.
        # Return detached certificates: diagnostic consumers cannot poison a
        # later forecast or actuator hit. No approximate state/time bucketing.
        key=(state,end_s,power,self.max_step_s,tuple(sorted((additional_node_heat_w or {}).items())))
        if self.cache_size and key in self._advance_cache:
            self._advance_cache.move_to_end(key)
            return self._copy_certificate(self._advance_cache[key])
        result=self._advance_uncached(state,end_s,power,additional_node_heat_w=additional_node_heat_w)
        if self.cache_size:
            self._advance_cache[key]=self._copy_certificate(result)
            if len(self._advance_cache)>self.cache_size:self._advance_cache.popitem(last=False)
        return result

    @staticmethod
    def _copy_certificate(c):
        # Frozen states contain only scalar time and a temperature tuple;
        # each mutable numerical mapping receives a detached shallow copy.
        return CelsiusTrajectoryV1(c.before,c.after,dict(c.peaks_c),dict(c.peak_times_s),
            dict(c.headroom_c),c.safe,dict(c.ledger_j),dict(c.node_input_heat_j),c.qualification)

    def _advance_uncached(self, state, end_s, power, *, additional_node_heat_w=None):
        if not math.isfinite(end_s) or end_s < state.time_s:
            raise ValueError("THERMAL_CLOCK_ROLLBACK")
        p = self.p
        dt = end_s - state.time_s
        extra = dict(additional_node_heat_w or {})
        nodes = getattr(self, 'nodes', NODES)
        count = len(nodes)
        if len(state.temperatures_c) != count:
            raise ValueError('THERMAL_STATE_NODE_IDENTITY_MISMATCH')
        if set(extra) - set(nodes) or any(not math.isfinite(v) or v < 0 for v in extra.values()):
            raise ValueError("invalid explicitly declared sensitivity heat direction")
        if count == 4 and power.payload_incremental_w:
            raise ValueError('PAYLOAD_POWER_REQUIRES_EXPLICIT_FIVE_NODE_NETWORK')
        board_dc = p.board_idle_power_w + power.board_incremental_w
        chip_heat = max(board_dc - POTHER, 0.) + extra.get("chip", 0.)
        bypass_heat = min(board_dc, POTHER) + extra.get("board", 0.)
        rf_dc = p.rf_idle_power_w + power.rf_incremental_dc_w
        escaped = power.rf_incremental_dc_w * p.rf_escaped_fraction
        rf_heat = rf_dc - escaped + extra.get("rf", 0.)
        structure_heat = p.structure_idle_power_w + power.structure_incremental_w + extra.get("structure", 0.)
        inputs = np.array((chip_heat, bypass_heat, rf_heat, structure_heat))
        if count == 5:
            inputs = np.r_[inputs, power.payload_incremental_w + extra.get('payload', 0.)]
        caps = np.array(tuple(p.capacities_j_k.values()))

        def rhs(_t, y):
            c, b, r, s = y[:4]
            cb = GCB * (c - b)
            bs = p.board_structure_conductance_w_k * (b - s)
            rs = p.rf_structure_conductance_w_k * (r - s)
            emitted = p.emissivity_area_m2 * SIGMA * ((s + 273.15)**4 - p.space_temperature_k**4)
            structure_transfer = bs+rs+power.absorbed_external_w-emitted
            if count == 5:
                ps = p.payload_structure_conductance_w_k * (y[4] - s)
                structure_transfer += ps
            # Keep the original addition/division ordering; avoid creating
            # transfer, rate and concatenation arrays at every RK stage.
            out = np.empty(2*count)
            out[0]=(inputs[0]-cb)/caps[0]
            out[1]=(inputs[1]+(cb-bs))/caps[1]
            out[2]=(inputs[2]-rs)/caps[2]
            out[3]=(inputs[3]+structure_transfer)/caps[3]
            if count == 5:out[4]=(inputs[4]-ps)/caps[4]
            out[count:count+4]=(cb,bs,rs,emitted)
            if count == 5:out[count+4]=ps
            return out

        initial = np.r_[state.temperatures_c, np.zeros(4 + (count == 5))]
        points = [(state.time_s, initial)]
        if dt:
            # Same ordered arithmetic as rhs, without recomputing all other
            # nodes and allocating an 8/10-element derivative for each event.
            def chip_zero(t,y):return float((inputs[0]-GCB*(y[0]-y[1]))/caps[0])
            def board_zero(t,y):return float((inputs[1]+(GCB*(y[0]-y[1])-p.board_structure_conductance_w_k*(y[1]-y[3])))/caps[1])
            def rf_zero(t,y):return float((inputs[2]-p.rf_structure_conductance_w_k*(y[2]-y[3]))/caps[2])
            def structure_zero(t,y):
                bs=p.board_structure_conductance_w_k*(y[1]-y[3]);rs=p.rf_structure_conductance_w_k*(y[2]-y[3])
                emitted=p.emissivity_area_m2*SIGMA*((y[3]+273.15)**4-p.space_temperature_k**4)
                transfer=bs+rs+power.absorbed_external_w-emitted
                if count==5:transfer+=p.payload_structure_conductance_w_k*(y[4]-y[3])
                return float((inputs[3]+transfer)/caps[3])
            events=[chip_zero,board_zero,rf_zero,structure_zero]
            if count==5:
                def payload_zero(t,y):return float((inputs[4]-p.payload_structure_conductance_w_k*(y[4]-y[3]))/caps[4])
                events.append(payload_zero)
            result = solve_ivp(rhs, (state.time_s, end_s), initial, method=_ScalarDenseRK45, rtol=1e-10, atol=1e-11,
                               max_step=self.max_step_s, events=events, dense_output=True)
            if not result.success:
                raise RuntimeError("CELSIUS_INTEGRATOR_FAILED:"+result.message)
            points.extend(zip(result.t, result.y.T))
            for times in result.t_events:
                points.extend((float(t), result.sol(t)) for t in times)
            final = result.y[:, -1]
        else:
            final = initial
        peaks, peak_times = {}, {}
        for i, n in enumerate(nodes):
            t, y = max(points, key=lambda row: row[1][i])
            peaks[n], peak_times[n] = float(y[i]), float(t)
        stored = float(np.dot(caps, final[:count]-initial[:count]))
        electrical = (board_dc + rf_dc + p.structure_idle_power_w + power.structure_incremental_w + power.payload_incremental_w) * dt
        extra_j = sum(extra.values()) * dt
        emitted_j = float(final[count+3])
        expected = electrical + extra_j + power.absorbed_external_w*dt - escaped*dt - emitted_j
        residual = stored - expected
        if abs(residual) > 2e-7 * max(1., abs(expected), electrical):
            raise RuntimeError("THERMAL_ENERGY_CONSERVATION_FAILED")
        headroom = {n: p.safe_limits_c[n] - peaks[n] for n in nodes}
        return CelsiusTrajectoryV1(state, type(state)(end_s, tuple(float(v) for v in final[:count])),
            peaks, peak_times, headroom, all(v >= -1e-8 for v in headroom.values()),
            dict(electrical=electrical, escaped_rf=escaped*dt, absorbed_external=power.absorbed_external_w*dt,
                 emitted_external=emitted_j, sensitivity_heat=extra_j, stored=stored,
                 conservation_residual=residual, chip_to_board=float(final[count]),
                 board_to_structure=float(final[count+1]), rf_to_structure=float(final[count+2]),
                 **(dict(payload_to_structure=float(final[count+4])) if count == 5 else {})),
            dict(zip(nodes, (float(v)*dt for v in inputs))), p.qualification)


def load_celsius_network_v1(config) -> CelsiusThermalNetworkV1:
    required = set(CelsiusNetworkParametersV1.__dataclass_fields__) - {
        "initial_board_structure_rf_c", "board_structure_limit_c", "frozen_background_power_w"}
    missing = sorted(k for k in required if config.get(k) is None)
    if missing:
        raise MissingCelsiusParameters(missing)
    return CelsiusThermalNetworkV1(CelsiusNetworkParametersV1(**config))
