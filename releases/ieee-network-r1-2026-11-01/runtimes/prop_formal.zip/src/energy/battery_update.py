"""鐢垫睜涓?AI 鑳介噺棰勭畻鏇存柊銆?"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class BatteryTransition:
    """Auditable battery transition in bus-side joules and SOC."""

    soc_before: float
    soc_unclipped: float
    soc_after: float
    solar_energy_j: float
    common_energy_j: float
    incremental_energy_j: float
    total_load_energy_j: float
    net_bus_energy_j: float
    requested_battery_delta_j: float
    actual_battery_delta_j: float
    curtailed_solar_energy_j: float
    unserved_load_energy_j: float
    charge_efficiency: float
    discharge_efficiency: float

    def to_log_dict(self) -> dict[str, float]:
        return {key: float(value) for key, value in self.__dict__.items()}


def compute_battery_transition(
    battery_soc: float,
    solar_energy_j: float,
    base_power_w: float,
    slot_seconds: float,
    compute_energy_j: float,
    comm_energy_j: float,
    battery_capacity_j: float,
    charge_efficiency: float = 1.0,
    discharge_efficiency: float = 1.0,
    additional_common_energy_j: float = 0.0,
) -> BatteryTransition:
    """Compute SOC plus clipping diagnostics without hiding unmet energy.

    ``curtailed_solar_energy_j`` and ``unserved_load_energy_j`` are bus-side
    quantities.  The battery delta is stored-energy-side and therefore includes
    charge/discharge efficiency.
    """

    capacity = max(float(battery_capacity_j), 1.0e-9)
    eta_ch = max(float(charge_efficiency), 1.0e-9)
    eta_dis = max(float(discharge_efficiency), 1.0e-9)
    soc_before = max(0.0, min(1.0, float(battery_soc)))
    solar = max(0.0, float(solar_energy_j))
    base_energy_j = max(0.0, float(base_power_w)) * max(0.0, float(slot_seconds))
    common_energy_j = base_energy_j + max(0.0, float(additional_common_energy_j))
    incremental_energy_j = max(0.0, float(compute_energy_j)) + max(0.0, float(comm_energy_j))
    total_load_energy_j = common_energy_j + incremental_energy_j
    net_bus_energy_j = solar - total_load_energy_j

    if net_bus_energy_j >= 0.0:
        requested_delta = net_bus_energy_j * eta_ch
    else:
        requested_delta = net_bus_energy_j / eta_dis
    soc_unclipped = soc_before + requested_delta / capacity
    soc_after = max(0.0, min(1.0, soc_unclipped))
    actual_delta = (soc_after - soc_before) * capacity

    curtailed = 0.0
    unserved = 0.0
    if soc_unclipped > 1.0:
        unused_stored_energy_j = (soc_unclipped - 1.0) * capacity
        curtailed = unused_stored_energy_j / eta_ch
    elif soc_unclipped < 0.0:
        unavailable_stored_energy_j = -soc_unclipped * capacity
        unserved = unavailable_stored_energy_j * eta_dis

    return BatteryTransition(
        soc_before=soc_before,
        soc_unclipped=soc_unclipped,
        soc_after=soc_after,
        solar_energy_j=solar,
        common_energy_j=common_energy_j,
        incremental_energy_j=incremental_energy_j,
        total_load_energy_j=total_load_energy_j,
        net_bus_energy_j=net_bus_energy_j,
        requested_battery_delta_j=requested_delta,
        actual_battery_delta_j=actual_delta,
        curtailed_solar_energy_j=curtailed,
        unserved_load_energy_j=unserved,
        charge_efficiency=eta_ch,
        discharge_efficiency=eta_dis,
    )


def update_battery_soc(
    battery_soc: float,
    solar_energy_j: float,
    base_power_w: float,
    slot_seconds: float,
    compute_energy_j: float,
    comm_energy_j: float,
    battery_capacity_j: float,
    charge_efficiency: float = 1.0,
    discharge_efficiency: float = 1.0,
) -> float:
    """鏇存柊鐢垫睜鑽风數鐘舵€併€?
    鍦ㄦ湁鍏夌収鏃舵寜 charge efficiency 璁＄畻鍏呯數锛屽湪鏈夎礋杞戒簭绌烘椂鎸?discharge efficiency
    璁＄畻鏀剧數锛屼粠鑰屼綋鐜?multi-orbit / multi-day 鐨勫厖鏀剧數鍔ㄦ€併€?"""

    return compute_battery_transition(
        battery_soc=battery_soc,
        solar_energy_j=solar_energy_j,
        base_power_w=base_power_w,
        slot_seconds=slot_seconds,
        compute_energy_j=compute_energy_j,
        comm_energy_j=comm_energy_j,
        battery_capacity_j=battery_capacity_j,
        charge_efficiency=charge_efficiency,
        discharge_efficiency=discharge_efficiency,
    ).soc_after


def update_ai_energy_budget(
    ai_energy_budget: float,
    compute_energy_j: float,
    E_AI_ref: float,
    recharge: float,
) -> float:
    """鏇存柊 AI 棰勭畻鐘舵€併€?"""

    next_value = ai_energy_budget - compute_energy_j / max(E_AI_ref, 1.0e-9) + recharge
    return max(0.0, min(1.0, next_value))
