"""Network decision adapters; physical feasibility is supplied by one owner.

Scientific scheduler ranks actions, never declares bytes delivered. Retains
the old four-term score and Mode biases; C changes only declared pressures.
"""
from __future__ import annotations
from types import SimpleNamespace
from dataclasses import asdict
import math
from src.controllers.mode_controller import RuleBasedModeController
from src.routers import decoupled_prop_v2 as core
from src.routers.requirement_aware_projection import product_satisfies, residual_required_product, normalize_product


def clip(x):return min(1.,max(0.,x))


def energy_pressure(soc,unit='fraction'):
    if not math.isfinite(soc):raise ValueError('NONFINITE_SOC')
    if unit=='percent':soc/=100.
    elif unit!='fraction':raise ValueError('UNKNOWN_SOC_UNIT')
    if unit=='fraction' and soc>1.:raise ValueError('SOC_FRACTION_EXPECTED_NOT_PERCENT')
    return clip(1.-soc)


def thermal_pressure(state,parameters):
    return max(clip((t-15.)/(parameters.safe_limits_c[n]-15.))
        for n,t in zip(('chip','board','rf','structure'),state.temperatures_c))


class NetworkController:
    def __init__(self,cfg,variant):
        self.cfg=cfg;self.variant=variant
        self.mode=RuleBasedModeController(cfg['mode_controller'])
        self.mode_name='balanced';self.last_mode_slot=-10;self.last_observed_slot=-1
        self.history=[];self.mode_updates=[];self.no_contact=0

    def observe_slot(self,slot,physics,task):
        if slot==self.last_observed_slot:return
        self.last_observed_slot=slot
        link=physics.kernel.link_at(physics.now)
        self.no_contact=0 if link.business_rate_bit_s else self.no_contact+1
        # Frozen ContextBuilder.build; idle slots contribute zero.
        urgency=0. if task is None else 1.-min(task.deadline_s/120.,1.)
        hv=float(task is not None and task.task_value>=self.cfg['reward']['high_value_threshold'])
        q=sum(x.remaining_bits for x in physics.order)/8e6
        self.history=(self.history+[(urgency,hv,q)])[-self.mode.update_interval_slots:]
        temp=thermal_pressure(physics.state,physics.network.p)
        if self.variant=='physics_fixed':temp=clip((max(physics.state.temperatures_c)+10.)/40.)
        state=SimpleNamespace(battery_soc=physics.soc,thermal_pressure=temp,queue_mb=q,queue_max_mb=5120.,
            recent_deadline_urgency=sum(x[0] for x in self.history)/len(self.history),
            recent_high_value_ratio=sum(x[1] for x in self.history)/len(self.history),
            next_contact_s=self.no_contact*20.,queue_growth_rate=(q-self.history[0][2])/max(1,len(self.history)-1))
        if slot-self.last_mode_slot>=self.mode.update_interval_slots:
            self.mode_name=self.mode.select_mode(state);self.last_mode_slot=slot
            self.mode_updates.append(dict(slot=slot,time_s=physics.now,mode=self.mode_name))

    def guidance(self,physics,margin):
        p=self.cfg['lyapunov_pricing'];s=self.cfg['simulator']
        q=sum(x.remaining_bits for x in physics.order)/8e6
        pq=clip(q/s['queue_max_mb'])
        pd=sum(x[0] for x in self.history)/max(1,len(self.history))
        if self.variant=='pressure_fixed':
            pe=energy_pressure(physics.soc)
            ph=thermal_pressure(physics.state,physics.network.p)
            # Scarcity is occupied fraction of *remaining executable service*.
            # Zero available service is rejected by admission, never priced inf.
            available=margin.get('safe_available_bits',margin['offered_bits'])
            total=margin.get('window_total_bits',available)
            remaining=max(0.,available-margin['committed_bits'])
            pw=clip(1.-remaining/total) if total else 1.
        else:
            pe=clip((s['battery_min']-physics.soc)/s['battery_min'])
            ph=clip(clip((max(physics.state.temperatures_c)+10.)/40.)/s['thermal_max'])
            link=physics.kernel.link_at(physics.now)
            future=[x for x in physics.kernel.links if x.window_id==link.window_id and x.window_id]
            remaining=max((x.end_s for x in future),default=physics.now)-physics.now
            low=1.-clip(remaining/80.) if link.business_rate_bit_s else 1.
            pw=clip(pq*low)
        prices=dict(lambda_E=p['base_lambda_E']*(1+p['alpha_energy']*pe+p['alpha_thermal']*ph),
            lambda_L=p['base_lambda_L']*(1+p['alpha_deadline']*pd),
            lambda_Q=p['base_lambda_Q']*(1+p['alpha_queue']*pq),
            lambda_S=p['base_lambda_S']*(1+p['alpha_egress']*pw))
        g=self.mode.build_guidance(prices,self.mode_name)
        g['pressure']=dict(E=pe,H=ph,Q=pq,deadline=pd,window=pw)
        g['window_margin']=margin
        g['unit_contract']='E/100J,L/DDL,Qnext/5120MB,Sgen/5120MB; effective prices already include base'
        return g


def score(cfg,task,action,predicted,delivered,guidance,ground,qmap):
    # Keep exact historical helper and q-once mapping. Process-local immutable
    # config, no candidate-dependent quality writes or detector calls.
    core.FROZEN_QUALITY_PROXY.update(qmap)
    sc=core.score_action_q_once(task=task,action=action,predicted=predicted,
        delivered_products=delivered,product_utility_cfg=cfg['product_requirement_utility'],
        guidance_bundle=guidance,simulator_cfg=cfg['simulator'],beta_resource_cost=1.,
        beta_hard_penalty=1.,ground_arrival_s=ground,slot_seconds=20.)
    row=asdict(sc)
    for name,term,price in [('energy','energy_term','lambda_E'),('latency','latency_term','lambda_L'),
                          ('queue','queue_term','lambda_Q'),('payload','payload_term','lambda_S')]:
        row[name+'_cost']=row[term]*guidance.get(price,0.)
    return row


def choose_prop(candidates,task,delivered):
    """Literal old V2 + conditional nonnegative guard + Metadata repair."""
    feasible=[x for x in candidates if x['feasible']]
    ranked=sorted(feasible,key=lambda x:(x['score']['net_score'],x['action'].action_name),reverse=True)
    if not ranked:return None,'no_executable_candidate'
    if task.value_level not in {'high','urgent'}:
        best=ranked[0]
        return (best,'ordinary_soft_one_shot') if best['score']['net_score']>=-1e-12 else (None,'negative_net_defer')
    required=normalize_product(residual_required_product(task.product_requirement,delivered))
    direct=[x for x in ranked if x['product']==required]
    meta=[x for x in ranked if x['product']=='metadata' and 'metadata' not in delivered]
    best=direct[0] if direct else (meta[0] if meta else None)
    if best and best['score']['net_score'] < -1e-12:best=None
    positive_direct=[x for x in direct if x['score']['net_score']>1e-12]
    positive_meta=[x for x in meta if x['score']['net_score']>1e-12]
    if not positive_direct and positive_meta:return positive_meta[0],'hv_metadata_residual_repair'
    return best,('hv_direct_required_product' if best and best['product']==required else 'hv_metadata_first' if best else 'hv_defer_for_reentry')


def choose_offload(candidates):
    eligible={x['route']:x for x in candidates if x['feasible']}
    local,ground=eligible.get('LOCAL'),eligible.get('GROUND')
    if local is None:return ground,'only_ground_feasible' if ground else 'both_infeasible'
    if ground is None:return local,'only_local_feasible'
    for key,tol in [('ground_s',1e-6),('size_mb',1e-6),('energy_j',1e-9)]:
        a,b=local[key],ground[key]
        if abs(a-b)>tol:return (local if a<b else ground),'earliest_finish_or_legacy_tie_'+key
    return local,'deterministic_final_tie'
