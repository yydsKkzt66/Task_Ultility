"""PROP incremental economics and slow Mode; no physical execution authority.

Prices are provisional heuristic scarcity corrections, never public charges.
Terminal projections contain only arrived/committed work, no future arrivals.
"""
from dataclasses import asdict
from src.network_revision.policy import clip, energy_pressure, thermal_pressure, choose_prop
from src.payload.information_sufficiency import delta_information_utility

TOLERANCE = 1e-12


def terminal_quote(physics, order, projection, endpoint):
    """Same expiry and ready semantics as execute()/ledger(), at formal end.

    Expiry of every known item before settlement proves zero terminal bytes
    without integrating empty spacecraft time after the last expiry. Unsafe
    or incomplete projections never silently receive a zero certificate.
    """
    known_end=min(endpoint,max([physics.now]+[x.deadline_s for x in order]))
    if not projection['safe'] or projection['state'].time_s < known_end-1e-7:
        return dict(resolved=False,backlog_mb=None,endpoint_s=endpoint,
                    projection_end_s=projection['state'].time_s,reason='INCOMPLETE_KNOWN_WORK_PROJECTION')
    survivors=[x for x in order if x.deadline_s>endpoint+1e-9 and x.ready_time_s<=endpoint+1e-10]
    q=sum(projection['remaining'][x.product_id] for x in survivors)/8e6
    return dict(resolved=True,backlog_mb=q,endpoint_s=endpoint,
        projection_end_s=projection['state'].time_s,
        certificate='KNOWN_WORK_EXPIRY' if not survivors else 'COMMON_KERNEL_FORMAL_TERMINAL',
        expired_before_or_at_end=[x.product_id for x in order if x.deadline_s<=endpoint+1e-9],
        no_future_arrivals=True)


def incremental_score(task, product, delivered, q, ground, plan, projection, baseline,
                      terminal, baseline_terminal, guidance, prices):
    pid=plan['item'].product_id
    delta=delta_information_utility(product,delivered,task.product_requirement,guidance['product_utility_cfg'])
    timely=clip(1.-(ground-task.arrival_s)/task.deadline_s) if ground is not None else 0.
    deliverable=float(ground is not None and ground<=min(task.deadline_time_s,terminal['endpoint_s'])+1e-9)
    gross=task.task_value*delta*q*deliverable*timely
    flows=[f for f in projection['flows'] if f['product_id']==pid]
    tx=sum(f['energy_j'] for f in flows);b=sum(f['business_bits'] for f in flows)/8e6
    energy=plan['inference_j']+plan['encoding_j']+tx
    ke=prices['energy_price_per_Wh']/3600.;kb=prices['downlink_price_per_MB'];kq=prices['terminal_backlog_price_per_MB']
    resolved=terminal['resolved'] and baseline_terminal['resolved']
    dq=terminal['backlog_mb']-baseline_terminal['backlog_mb'] if resolved else None
    costs=dict(energy=ke*energy,downlink=kb*b,terminal_backlog=kq*dq if resolved else None)
    fixed=gross-sum(costs.values()) if resolved else None
    scarcity=guidance['mu_E']*energy+guidance['mu_B']*b
    impacts=[]
    for existing in baseline['order']:
        old=baseline['finishes'].get(existing.product_id);new=projection['finishes'].get(existing.product_id)
        old_remaining=baseline['remaining'][existing.product_id];new_remaining=projection['remaining'][existing.product_id]
        if old!=new or old_remaining!=new_remaining:
            impacts.append(dict(product_id=existing.product_id,baseline_finish_s=old,candidate_finish_s=new,
                delayed=(old is not None and (new is None or new>old+1e-7)),
                baseline_remaining_bits=old_remaining,candidate_remaining_bits=new_remaining))
    return dict(net_score=fixed-scarcity if resolved else None,positive_benefit=gross,
        value=task.task_value,delta_information=delta,q=q,deliverable_indicator=deliverable,timeliness=timely,
        energy_new_j=energy,tx_new_mb=b,inference_new_j=plan['inference_j'],encoding_new_j=plan['encoding_j'],tx_new_j=tx,
        delta_Q_end_mb=dq,terminal=terminal,baseline_terminal=baseline_terminal,
        fixed_costs=costs,fixed_net=fixed,scarcity_cost=scarcity,
        scarcity_energy_cost=guidance['mu_E']*energy,scarcity_downlink_cost=guidance['mu_B']*b,
        kappa_E=ke,kappa_B=kb,kappa_Q=kq,effective_price_E=ke+guidance['mu_E'],effective_price_B=kb+guidance['mu_B'],
        economic_projection_resolved=resolved,commitment_impacts=impacts,
        qualification='CANDIDATE_INCREMENT_WITH_TERMINAL_DIFFERENCE_NOT_EXACT_SYSTEM_MARGINAL_GROSS',
        selection_score_source='PROP_INCREMENTAL_FIXED_PLUS_SCARCITY_V1')


def choose_incremental(candidates, task, delivered):
    eligible=[c for c in candidates if c['feasible'] and c['score']['economic_projection_resolved']
              and c['score']['net_score']>TOLERANCE]
    chosen,reason=choose_prop(eligible,task,delivered)
    return chosen,reason if chosen else 'no_positive_executable_increment'


class IncrementalController:
    """Slow contextual multipliers only; accepted service is never repriced."""
    def __init__(self,cfg,settings,prices):
        self.cfg=cfg;self.settings=settings;self.prices=prices
        self.mode_name='balanced';self.last_mode_slot=-10;self.last_observed_slot=-1
        self.mode_updates=[];self.history=[];self.recent={};self.signals={}

    def select_mode(self,s):
        t=self.settings['mode_thresholds'];old=self.mode_name
        energy=s['soc']<=t['soc_exit' if old=='energy_saving' else 'soc_enter'] or s['thermal']>=t['thermal_exit' if old=='energy_saving' else 'thermal_enter'] or s['replenishment_soc_estimate']<=.55
        queue=s['queue_congestion']>=t['queue_exit' if old=='queue_draining' else 'queue_enter']
        egress=s['known_work_count']>0 and s['next_contact_s'] is not None and s['next_contact_s']>=t['contact_exit_s' if old=='egress_conservative' else 'contact_enter_s']
        latency=s['urgency']>=t['urgency_exit' if old=='latency_critical' else 'urgency_enter']
        mission=s['hv_fraction']>=t['hv_exit' if old=='mission_priority' else 'hv_enter'] and s['hv_denominator']>0
        return next((name for name,yes in [('energy_saving',energy),('queue_draining',queue),('egress_conservative',egress),('latency_critical',latency),('mission_priority',mission)] if yes),'balanced')

    def observe_arrival(self,physics,task):
        """Record only a real arrival; never perform an extra slow update."""
        if task.arrival_s>physics.now+1e-9:raise ValueError('EARLY_ARRIVAL_OBSERVATION')
        self.recent[task.task_id]=(physics.now,task)

    def observe_slot(self,slot,physics,task,*,arrived=None,pending=None,closed=None):
        if slot==self.last_observed_slot:return
        self.last_observed_slot=slot
        if task is not None:self.observe_arrival(physics,task)
        if slot-self.last_mode_slot<self.settings['interval_slots']:return
        now=physics.now;self.recent={k:v for k,v in self.recent.items() if now-v[0]<200.}
        arrived=arrived or {};closed=closed or {};pending=pending or {}
        known={x.task_id:arrived[x.task_id] for x in physics.order if x.task_id in arrived}
        known.update({k:arrived[k] for k in pending if k in arrived and k not in closed and arrived[k].deadline_time_s>now})
        observed={k:v[1] for k,v in self.recent.items()};observed.update(known)
        future=[x for x in physics.kernel.links if x.business_rate_bit_s>0 and x.end_s>now]
        contact=max(now,future[0].start_s)-now if future else None
        queue=sum(x.remaining_bits for x in physics.order)/8e6
        calendar_end=physics.kernel.links[-1].end_s
        requested_end=min([x.deadline_s for x in physics.order if x.deadline_s>now]+[now+200.])
        end=min(requested_end,calendar_end)
        due=sum(x.remaining_bits for x in physics.order if x.deadline_s<=end+1e-9)/8e6
        # If no DDL in the next slow interval, quote to the first real DDL.
        if physics.order:
            requested_end=min(x.deadline_s for x in physics.order if x.deadline_s>now)
            end=min(requested_end,calendar_end)
            due=sum(x.remaining_bits for x in physics.order if x.deadline_s<=end+1e-9)/8e6
            base=physics.project(end_s=end)
            margin=physics.executable_margin(now,end,base)
            capacity=margin['safe_available_bits']/8e6
            congestion=clip(due/capacity) if capacity>0 else float(due>0)
        else:base=None;capacity=0.;congestion=0.
        urgency=[]
        for tid,t in known.items():
            finishes=[base['finishes'].get(x.product_id) for x in physics.order if x.task_id==tid] if base else []
            finish=max(finishes) if finishes and all(v is not None for v in finishes) else None
            completion=max(0.,finish-now) if finish is not None else (contact+1.44 if contact is not None else t.deadline_time_s-now)
            urgency.append(clip(completion/max(t.deadline_time_s-now,1e-9)))
        # 200s solar/background estimate, explicitly not a safety certificate;
        # fast common kernel still owns all battery/thermal admission checks.
        delta=0.
        for x in physics.kernel.links:
            duration=max(0.,min(now+200.,x.end_s)-max(now,x.start_s))
            solar=x.solar_power_w
            net=solar-8.86
            delta+=duration*(net*.9 if net>=0 else net/.95)
        s=dict(soc=physics.soc,thermal=thermal_pressure(physics.state,physics.network.p),
            temperatures_c=dict(zip(('chip','board','rf','structure'),physics.state.temperatures_c)),
            queue_storage_mb=queue,storage_fraction=queue/5120.,queue_congestion=congestion,
            queue_due_mb=due,queue_capacity_mb=capacity,queue_scope_start_s=now,queue_scope_end_s=end,
            queue_zero_denominator='positive_due=>1; zero_due=>0',next_contact_s=contact,
            urgency=max(urgency,default=0.),urgency_source='known finish or next-contact+Balanced latency estimate',
            hv_fraction=sum(t.value_level in {'high','urgent'} for t in observed.values())/len(observed) if observed else 0.,
            hv_denominator=len(observed),observed_task_ids=sorted(observed),known_work_count=len(known),
            hv_scope='distinct real arrivals in trailing200s UNION active pending/queued; no idle slots',
            replenishment_soc_estimate=clip(physics.soc+delta/828000.),replenishment_estimate_j=delta)
        if requested_end>end+1e-9:
            s.update(queue_requested_end_s=requested_end,queue_calendar_end_s=calendar_end,
                queue_forecast_censored=True,
                queue_scope_note='Only known calendar is projected; original task deadlines remain unchanged')
        old=self.mode_name;self.mode_name=self.select_mode(s);self.signals=s;self.last_mode_slot=slot
        self.mode_updates.append(dict(slot=slot,time_s=now,previous_mode=old,mode=self.mode_name,changed=old!=self.mode_name,signals=s))

    def guidance(self,physics,margin):
        pe=energy_pressure(physics.soc);ph=thermal_pressure(physics.state,physics.network.p)
        available=margin['safe_available_bits'];remaining=max(0.,available-margin['committed_bits'])
        total=margin['window_total_bits'];pw=clip(1.-remaining/total) if total else 1.
        multipliers=self.cfg['mode_controller']['modes'][self.mode_name]['price_multipliers']
        me=max(0.,multipliers.get('lambda_E',1.));mb=max(0.,multipliers.get('lambda_S',1.))
        if not self.settings['use_mode']:me=mb=1.
        ke=self.prices['energy_price_per_Wh']/3600.;kb=self.prices['downlink_price_per_MB']
        mu_e=ke*me*(self.settings['a_E']*pe+self.settings['a_H']*ph)
        mu_b=kb*mb*self.settings['a_W']*pw
        if not self.settings['use_dynamic']:mu_e=mu_b=0.
        return dict(mode_name=self.mode_name,last_mode_update_s=self.last_mode_slot*20.,
            pressure=dict(E=pe,H=ph,Q=self.signals.get('queue_congestion',0.),window=pw,deadline=self.signals.get('urgency',0.)),
            mu_E=mu_e,mu_B=mu_b,m_E=me,m_B=mb,window_margin=margin,
            product_utility_cfg=self.cfg['product_requirement_utility'],mode_signals=self.signals,
            unit_contract='utility/J and utility/decimal MB; Mode applies only to mu',
            qualification='PROVISIONAL_HEURISTIC_NOT_CALIBRATED')
