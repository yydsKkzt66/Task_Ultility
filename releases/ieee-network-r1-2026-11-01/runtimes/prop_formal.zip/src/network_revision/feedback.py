"""Slow observed-progress feedback, preserving frozen guarantee coefficients.

Only arrived pending/queued high-value tasks accrue age. Miss feedback requires
a recorded feasible service opportunity and a later actual progress outcome.
"""
from src.payload.bounded_guarantee_queue import is_high_value_guarantee_eligible, stage_from_delivered, stage_rank

class ProgressFeedback:
    def __init__(self,cfg):
        self.cfg=cfg;self.age={};self.miss={};self.observations={};self.trace=[];self.last_slot=-1

    def debts(self):return {t:min(self.cfg['z_total_max'],self.age.get(t,0.)+self.miss.get(t,0.)) for t in set(self.age)|set(self.miss)}

    def slot(self,slot,physics,arrived,pending,delivered,closed):
        if slot==self.last_slot:return
        self.last_slot=slot
        for tid,task in arrived.items():
            if tid in closed or task.deadline_time_s<=physics.now:
                self.age[tid]=self.miss[tid]=0.;continue
            active=tid in pending or any(x.task_id==tid for x in physics.order)
            if not active or not is_high_value_guarantee_eligible(task.value_level,task.product_requirement,self.cfg):continue
            future=any(x.business_rate_bit_s>0 and x.end_s>physics.now and x.start_s<task.deadline_time_s for x in physics.kernel.links)
            if not future:continue
            gamma=self.cfg['gamma_age_urgent_per_slot'] if task.value_level=='urgent' else self.cfg['gamma_age_high_per_slot']
            self.age[tid]=min(self.cfg['z_age_max'],self.age.get(tid,0.)+gamma)
            self.trace.append(dict(time_s=physics.now,slot=slot,task_id=tid,kind='AGE',Z_age=self.age[tid],Z_miss=self.miss.get(tid,0.)))

    def opportunity(self,task,product,window,delivered):
        if not is_high_value_guarantee_eligible(task.value_level,task.product_requirement,self.cfg):return
        obs=self.observations.setdefault((window,task.task_id),dict(start=stage_rank(stage_from_delivered(delivered)),minimum=False,target=False))
        obs['minimum']|=product=='roi';obs['target']|=product=='roi_context'

    def window_end(self,window,physics,arrived,delivered,closed):
        for (wid,tid),o in list(self.observations.items()):
            if wid!=window:continue
            task=arrived[tid];after=stage_rank(stage_from_delivered(delivered.get(tid,set())))
            minimum=o['start']<stage_rank('ROI')<=after;target=o['start']<stage_rank('ROI+Ctx')<=after
            future=any(x.business_rate_bit_s>0 and x.start_s>=physics.now and x.start_s<task.deadline_time_s for x in physics.kernel.links)
            weight=(self.cfg['min_stage_miss_weight'] if o['minimum'] and not minimum else 0.)+(self.cfg['target_stage_miss_weight'] if o['target'] and not target else 0.)
            gamma=self.cfg['gamma_miss_urgent'] if task.value_level=='urgent' else self.cfg['gamma_miss_high']
            self.miss[tid]=min(self.cfg['z_miss_max'],self.miss.get(tid,0.)+(gamma*weight if future else 0.))
            if minimum:
                self.miss[tid]=max(0.,self.miss[tid]-self.cfg['progress_credit_min_stage']);self.age[tid]=max(0.,self.age.get(tid,0.)-1.)
            if target or tid in closed:self.age[tid]=self.miss[tid]=0.
            self.trace.append(dict(time_s=physics.now,task_id=tid,kind='WINDOW_END',window=window,
                min_progress=minimum,target_progress=target,future_contact=future,Z_age=self.age.get(tid,0.),Z_miss=self.miss[tid]))
            del self.observations[(wid,tid)]
