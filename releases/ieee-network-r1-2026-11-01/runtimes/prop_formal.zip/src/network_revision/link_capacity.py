"""Transparent link-only upper bound; never a thermal/electric certificate."""
import math


def link_remaining_capacity(*, now_s, ready_s, window_start_s, window_end_s,
                            deadline_s, rate_segments, committed_service=(),
                            business_intervals=None):
    """rate_segments=(start,end,effective Mbps), service=(start,end,unsent MB).

    Each service record describes detached future service from the current
    queue, not original payload or already sent bytes. Business allocation is
    a time mask, separate from effective rate reductions already in Mbps.
    No protocol overhead is added; caller must declare its effective rate.
    """
    begin=max(now_s,ready_s,window_start_s);end=min(window_end_s,deadline_s)
    rates=sorted(rate_segments)
    masks=sorted(business_intervals if business_intervals is not None else [(window_start_s,window_end_s)])
    for rows in (rates,masks):
        if any(not all(math.isfinite(v) for v in x) or x[1]<=x[0] for x in rows):
            raise ValueError('INVALID_LINK_INTERVAL')
        if any(a[1]>b[0] for a,b in zip(rows,rows[1:])):
            raise ValueError('OVERLAPPING_LINK_INTERVALS')
    if any(r<0 for a,b,r in rates):raise ValueError('NEGATIVE_LINK_RATE')
    spans=[]
    for a,b,rate in rates:
        for c,d in masks:
            lo=max(begin,a,c);hi=min(end,b,d)
            if hi>lo:spans.append((lo,hi,rate))
    offered=sum((b-a)*rate/8. for a,b,rate in spans)
    committed=0.
    for a,b,mb in committed_service:
        if b<=a or mb<0 or not all(math.isfinite(v) for v in (a,b,mb)):
            raise ValueError('INVALID_FUTURE_COMMITMENT')
        committed+=sum(max(0.,min(b,y)-max(a,x))/(b-a)*mb for x,y,_ in spans)
    return dict(scope_start_s=begin,scope_end_s=end,nominal_business_mb=offered,
        unfinished_committed_mb=committed,link_remaining_mb=max(0.,offered-committed),
        rate_unit='Mbps',capacity_unit='decimal MB',allocation='explicit time mask; no additional rate reduction',
        qualification='LINK_ONLY_UPPER_BOUND_NOT_SAFE_EXECUTABLE_CAPACITY')
