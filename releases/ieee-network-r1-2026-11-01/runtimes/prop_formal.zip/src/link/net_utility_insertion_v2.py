"""整队列剩余净收益的纯插入报价；不生成 reservation、物理服务或 ACK。

预测 owner 必须提供同一状态/价格下每个顺序的因果投影及承诺校验。
禁止用原始接触容量替代 thermal-safe executable-service。
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Callable, Mapping, Sequence

NET_TOLERANCE_V2 = 1e-10


def queue_tie_key_v2(order, fifo_order):
    """Deadline first, then stable first-arrival order, after legal checks."""
    rank={}
    for pid in fifo_order:
        if pid not in rank:rank[pid]=len(rank)
    return tuple((x.deadline_s,rank.get(x.product_id,len(rank))) for x in order)


def best_net_trial_v2(trials, *, net, tie):
    if not trials:return None
    top=max(net(x) for x in trials)
    return min((x for x in trials if top-net(x)<=NET_TOLERANCE_V2),key=tie)


@dataclass(frozen=True)
class IndependentQueueStageV2:
    product_id: str
    task_id: str
    product_type: str
    ready_time_s: float
    deadline_s: float
    remaining_bits: int
    dependencies: tuple[str, ...] = ()
    partially_served: bool = False
    sent_bits: int = 0

    def __post_init__(self) -> None:
        if not all(str(v).strip() for v in (self.product_id, self.task_id, self.product_type)):
            raise ValueError("queue stage identity missing")
        if not isinstance(self.remaining_bits, int) or isinstance(self.remaining_bits, bool) or self.remaining_bits <= 0:
            raise ValueError("remaining bits must be positive integer")
        if not isinstance(self.sent_bits,int) or isinstance(self.sent_bits,bool) or self.sent_bits<0:
            raise ValueError('invalid already-sent bits')
        if not all(math.isfinite(x) and x >= 0 for x in (self.ready_time_s, self.deadline_s)):
            raise ValueError("invalid stage time")
        if self.product_id in self.dependencies or len(set(self.dependencies)) != len(self.dependencies):
            raise ValueError("invalid stage dependency")


@dataclass(frozen=True)
class QueueRemainingNetProjectionV2:
    snapshot_identity: str
    forecast_identity: str
    remaining_net_by_product: Mapping[str, float]
    service_start_by_product: Mapping[str, float]
    completion_by_product: Mapping[str, float | None]
    consumed_bits_by_product: Mapping[str, int]
    committed_capacity_preserved: bool
    # Already authorized products still completing inference/encoding are
    # part of the known future queue, not a forecast of unknown arrivals.
    protected_future_remaining_net: float = 0.0


def best_legal_insertion_v2(*, existing: Sequence[IndependentQueueStageV2],
    candidate: IndependentQueueStageV2, now_s: float, snapshot_identity: str,
    completed_dependency_times: Mapping[str, float],
    project: Callable[[tuple[IndependentQueueStageV2, ...]], QueueRemainingNetProjectionV2],
    allow_conditional_preemption: bool=False,require_positive_gain: bool=True,
    require_candidate_completion: bool=False,fifo_order=None) -> dict[str, object]:
    """保留现有顺序，对所有合法插入位置投影整条队列；不无条件置顶 Metadata。

    已开始的部分续传必须在插入点前；承诺容量由原 reservation owner
    对每次投影核验。暂不划算返回 WAIT，调用方保留原 pending 至截止。
    """
    if not math.isfinite(now_s) or now_s < 0 or not snapshot_identity.strip():
        raise ValueError("missing/invalid queue snapshot")
    if len({x.product_id for x in existing}) != len(existing):
        raise ValueError("duplicate existing products")
    if candidate.product_id in {x.product_id for x in existing}:
        return dict(status="ALREADY_QUEUED", selected_order=None, trials=[])
    if now_s > candidate.deadline_s:
        return dict(status="EXPIRED", selected_order=None, trials=[])

    def checked_projection(order):
        p = project(order)
        if p.snapshot_identity != snapshot_identity or not p.forecast_identity.strip():
            raise ValueError("STALE_OR_UNBOUND_QUEUE_PROJECTION")
        ids = {x.product_id for x in order}
        maps = (p.remaining_net_by_product, p.service_start_by_product,
                p.completion_by_product, p.consumed_bits_by_product)
        if any(set(m) != ids for m in maps):
            raise ValueError("INCOMPLETE_WHOLE_QUEUE_PROJECTION")
        for item in order:
            pid = item.product_id
            start = p.service_start_by_product[pid]
            finish = p.completion_by_product[pid]
            bits = p.consumed_bits_by_product[pid]
            net = p.remaining_net_by_product[pid]
            if not math.isfinite(net) or not math.isfinite(start) or start < max(now_s, item.ready_time_s)-1e-9:
                raise ValueError("EARLY_OR_NONFINITE_QUEUE_PROJECTION")
            if not isinstance(bits, int) or isinstance(bits, bool) or not 0 <= bits <= item.remaining_bits:
                raise ValueError("INVALID_PROJECTED_PARTIAL_SERVICE")
            if finish is not None:
                if not math.isfinite(finish) or finish < start or finish > item.deadline_s+1e-9 or bits != item.remaining_bits:
                    raise ValueError("INVALID_PROJECTED_COMPLETION")
            for dep in item.dependencies:
                completed = completed_dependency_times.get(dep, p.completion_by_product.get(dep))
                if bits > 0 and (completed is None or not math.isfinite(completed) or completed > start+1e-9):
                    raise ValueError("QUEUE_DEPENDENCY_NOT_READY")
        if not math.isfinite(p.protected_future_remaining_net):
            raise ValueError("INVALID_AUTHORIZED_FUTURE_QUEUE_NET")
        return p, sum(p.remaining_net_by_product.values()) + p.protected_future_remaining_net

    baseline, baseline_net = checked_projection(tuple(existing))
    if not baseline.committed_capacity_preserved:
        raise ValueError("BASELINE_COMMITMENT_INVALID")
    trials = []
    continuation_floor=1+max((i for i,x in enumerate(existing) if x.partially_served),default=-1)
    floor=0 if allow_conditional_preemption else continuation_floor
    for index in range(floor, len(existing)+1):
        order = tuple(existing[:index]) + (candidate,) + tuple(existing[index:])
        known = set(completed_dependency_times)
        valid = True
        for item in order:
            if not set(item.dependencies) <= known:
                valid = False
                break
            known.add(item.product_id)
        if not valid:
            trials.append(dict(index=index, legal=False, reason="DEPENDENCY_ORDER", order=[x.product_id for x in order]))
            continue
        projection, net = checked_projection(order)
        valid = projection.committed_capacity_preserved
        trials.append(dict(index=index, legal=valid, reason="LEGAL" if valid else "COMMITTED_CAPACITY_CHANGED",
            net=net, increment=net-baseline_net, forecast_identity=projection.forecast_identity,
            conditional_preemption=index<continuation_floor,
            candidate_completion_s=projection.completion_by_product[candidate.product_id],
            order=[x.product_id for x in order]))
    continuing=[r['net'] for r in trials if r['legal'] and not r.get('conditional_preemption')]
    continuation_best=max(continuing,default=baseline_net)
    winners = [r for r in trials if r['legal'] and (not require_positive_gain or r['increment']>0)
        and (not require_candidate_completion or r['candidate_completion_s'] is not None)
        and (not r['conditional_preemption'] or r['net']>continuation_best+NET_TOLERANCE_V2)]
    items={x.product_id:x for x in tuple(existing)+(candidate,)}
    fifo=list(fifo_order) if fifo_order is not None else [x.product_id for x in existing]+[candidate.product_id]
    best=best_net_trial_v2(winners,net=lambda r:r['net'],
        tie=lambda r:queue_tie_key_v2(tuple(items[pid] for pid in r['order']),fifo))
    return dict(status="INSERT" if best else "WAIT", baseline_remaining_net=baseline_net,
        selected_order=None if best is None else best["order"], trials=trials,
        snapshot_identity=snapshot_identity, prediction_is_not_actual_service=True)
