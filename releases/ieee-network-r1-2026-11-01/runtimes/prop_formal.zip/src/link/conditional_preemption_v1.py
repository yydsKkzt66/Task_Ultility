"""Explicit event-edge resume contract; no unpriced implicit preemption.

An ideal zero-overhead contract must be labelled as an assumption. Positive
switch/RF and replay overhead is consumed by the same event kernel as data.
"""
from dataclasses import dataclass
import math


@dataclass(frozen=True)
class ConditionalPreemptionContractV1:
    switch_seconds: float
    resume_retransmit_bits: int
    source: str
    qualification: str
    boundary: str = 'COMPLETED_INTEGER_BUSINESS_BIT_EVENT_EDGE'

    def __post_init__(self):
        if not math.isfinite(self.switch_seconds) or self.switch_seconds<0:
            raise ValueError('INVALID_SWITCH_OVERHEAD')
        if isinstance(self.resume_retransmit_bits,bool) or not isinstance(self.resume_retransmit_bits,int) or self.resume_retransmit_bits<0:
            raise ValueError('INVALID_RESUME_RETRANSMISSION')
        if self.boundary!='COMPLETED_INTEGER_BUSINESS_BIT_EVENT_EDGE' or not self.source.strip():
            raise ValueError('EXPLICIT_PREEMPTION_BOUNDARY_AND_SOURCE_REQUIRED')
        if self.qualification not in {'DECLARED_ENGINEERING_ASSUMPTION','AUTHOR_APPROVED_ENGINEERING_DIAGNOSTIC','SYNTHETIC_TEST_ONLY'}:
            raise ValueError('UNQUALIFIED_PREEMPTION_MODEL')


def empty_service_context_v1():
    return dict(active_product_id='',suspended_products=[],overhead={})
