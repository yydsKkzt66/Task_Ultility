from pathlib import Path
from collections import defaultdict
import argparse,json,statistics,shutil,math
from formal_common import ROOT,read,write,sha,verify,job_for
from formal_audit import csvwrite

def completed(out):
    rows=[]
    for jobdir in sorted(Path(out).glob('*_*')):
        if not jobdir.is_dir():continue
        for attempt in reversed(sorted(p for p in jobdir.glob('attempt_*') if p.is_dir())):
            if (attempt/'COMPLETED.json').exists() and (attempt/'AUDIT.json').exists() and read(attempt/'AUDIT.json')['pass']:
                s=read(attempt/'RESULT/AUDITED_SUMMARY.json');s['runtime']=read(attempt/'COMPLETED.json');s['identity']=read(attempt/'IDENTITY.json');s['result_path']=str(attempt);rows.append(s);break
    return rows
def flatten(s):
    g=s['groups'];return dict(method=s['arm'],seed=s['seed'],arrivals=s['arrivals'],gross=s['gross'],net=s['net'],E_cost=s['costs']['energy'],B_cost=s['costs']['downlink'],Q_cost=s['costs']['terminal_backlog'],
        HV_gross=g['high_value']['gross'],HV_net=g['high_value']['net'],HV_closed=g['high_value']['closed'],HV_rate=g['high_value']['closed']/g['high_value']['tasks'],
        ordinary_closed=g['ordinary']['closed'],ordinary_rate=g['ordinary']['closed']/g['ordinary']['tasks'],controlled_J=s['ledger']['controlled_j'],downlink_MB=s['ledger']['downlink_mb'],Q_end_MB=s['ledger']['backlog_mb'],
        chip_peak_C=s['peak_temperatures_c']['chip'],RF_peak_C=s['peak_temperatures_c']['rf'],SOC_min=s['min_soc'],violations=s['actual_safety_violations'],thermal_wait_s=s['thermal_wait_s'],
        wall_s=s['runtime']['active_wall_s'],CPU_s=s['runtime']['cpu_s'],peak_RSS_MB=s['runtime']['peak_rss_bytes']/1e6,candidate_count=s['candidate_denominator'],feasible_candidates=s['feasible_candidates'],
        right_censored=sum(v for k,v in g['all']['status_counts'].items() if k.startswith('right_censored')),DDL_failed=g['all']['status_counts'].get('deadline_elapsed_unclosed',0),
        metadata=sum(v for k,v in s['ground_state_counts'].items() if k.startswith('metadata')),ROI=sum(v for k,v in s['ground_state_counts'].items() if k.startswith('roi_') and not k.startswith('roi_context')),ROI_Ctx=sum(v for k,v in s['ground_state_counts'].items() if k.startswith('roi_context')))
def summarize(out,plots=False):
    out=Path(out);records=completed(out);rows=[flatten(s) for s in records]
    write(out/'COMPLETED_RESULTS.json',records);csvwrite(out/'COMPLETED_COMPARISON.csv',rows)
    prop={r['seed']:r for r in rows if r['method']=='PROP'};deltas=[]
    for r in rows:
        if r['method']=='PROP' or r['seed'] not in prop:continue
        for k in ['net','gross','HV_net','HV_closed','ordinary_closed','controlled_J','downlink_MB','Q_end_MB']:
            base=prop[r['seed']][k];deltas.append(dict(method=r['method'],seed=r['seed'],metric=k,value=r[k],PROP=base,absolute=r[k]-base,percent=100*(r[k]-base)/abs(base) if base else None))
    csvwrite(out/'PAIRED_DELTA.csv',deltas)
    groups=defaultdict(list)
    for r in rows:groups[r['method']].append(r)
    agg=[]
    for method,rr in groups.items():
        if len(rr)!=5:continue
        for metric in rows[0]:
            if metric in {'method','seed'}:continue
            vals=[r[metric] for r in rr];agg.append(dict(method=method,metric=metric,n=5,mean=statistics.mean(vals),sd=statistics.stdev(vals)))
    csvwrite(out/'FIVE_SEED_MEAN_SD.csv',agg)
    text=['# 已完成结果（独立审计通过）','','未完成作业不计零，少于五种子的组不生成正式均值±标准差。','', '|方法|种子|净效用|HV净效用|HV闭环|普通闭环|能耗J|下传MB|期末ready MB|','|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for r in rows:text.append(f"|{r['method']}|{r['seed']}|{r['net']:.6f}|{r['HV_net']:.6f}|{r['HV_closed']}|{r['ordinary_closed']}|{r['controlled_J']:.3f}|{r['downlink_MB']:.3f}|{r['Q_end_MB']:.6f}|")
    text+=['','基于资源状态的定价；固定公共E/B/Q扣分。GROUND的地面最终产品不是实际下传产品。','NO_RESOURCE_MODULATION与NO_MODE有嵌套；REQUIRED_PRODUCT_ONLY与NO_PROGRESSIVE_REFINEMENT的差值不能视作可相加贡献。']
    (out/'00_SUMMARY_CN.md').write_text('\n'.join(text)+'\n',encoding='utf-8')
    if plots and all(len(groups.get(m,[]))==5 for m in ['GROUND','OFFLOAD','TUT_ADAPTED','PROP']):make_plot(out,groups)
    return rows
def make_plot(out,groups):
    import matplotlib;matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    names=['GROUND','OFFLOAD','TUT_ADAPTED','PROP'];x=np.arange(4)
    def stats(key):return [statistics.mean(r[key] for r in groups[m]) for m in names],[statistics.stdev(r[key] for r in groups[m]) for m in names]
    fig,axes=plt.subplots(2,2,figsize=(13,9));ax=axes[0,0];v,sd=stats('net');ax.bar(x,v,yerr=sd,capsize=4);ax.axhline(0,color='black',lw=.6);ax.set_title('Net utility: mean +/- sample SD (5 seeds)')
    ax=axes[0,1]
    for shift,key,label in [(-.18,'HV_closed','HV'),(.18,'ordinary_closed','Ordinary')]:
        v,sd=stats(key);ax.bar(x+shift,v,.36,yerr=sd,capsize=3,label=label)
    ax.legend();ax.set_title('Required-product closures')
    ax=axes[1,0];bottom=np.zeros(4)
    for key,label in [('metadata','Metadata'),('ROI','ROI'),('ROI_Ctx','ROI+Ctx')]:
        v,sd=stats(key);ax.bar(x,v,bottom=bottom,label=label);bottom+=v
    ax.legend();ax.set_title('Highest effective ground information / task')
    for ax in [axes[0,0],axes[0,1],axes[1,0]]:ax.set_xticks(x,names,rotation=12)
    ax=axes[1,1]
    for m in names:
        r=groups[m];en=statistics.mean(v['controlled_J'] for v in r);mb=statistics.mean(v['downlink_MB'] for v in r);net=statistics.mean(v['net'] for v in r)
        ax.scatter(en,mb,s=max(abs(net),.001)*8,marker='o' if net>=0 else 'X',facecolors='none' if net<0 else None,label=m);ax.annotate(m,(en,mb))
    ax.set_xlabel('Controlled energy (J)');ax.set_ylabel('Actual TX (decimal MB)');ax.set_title('Area proportional to |net|; X = negative net')
    fig.tight_layout();fig.savefig(out/'MAIN_FIVE_SEED_FOUR_PANELS.png',dpi=200);fig.savefig(out/'MAIN_FIVE_SEED_FOUR_PANELS.pdf');plt.close(fig)
def main():
    p=argparse.ArgumentParser();p.add_argument('--out',default='outputs');a=p.parse_args();summarize(Path(a.out).resolve(),plots=True)
def import_prop():
    p=argparse.ArgumentParser();p.add_argument('--from-dir',required=True);p.add_argument('--out',default='outputs');a=p.parse_args();ids=verify();target=Path(a.out).resolve()
    imported=[]
    for s in completed(Path(a.from_dir)):
        if s['arm']!='PROP':continue
        expected=job_for(s['seed'],'PROP');identity=s['identity']
        if identity['job']!=expected or identity['manifests']!=ids:raise ValueError('PROP_REFERENCE_SOURCE_INPUT_CONFIG_MISMATCH')
        src=Path(s['result_path']);dest=target/f"{s['seed']}_PROP"/'attempt_imported'
        if dest.exists():raise ValueError('IMPORT_DEST_ALREADY_EXISTS')
        dest.mkdir(parents=True)
        for name in ['IDENTITY.json','COMPLETED.json','AUDIT.json']:shutil.copy2(src/name,dest/name)
        shutil.copytree(src/'RESULT',dest/'RESULT');imported.append(s['seed'])
    write(target/'IMPORTED_PROP.json',dict(seeds=imported,comparison_tolerance='Exact integer counts/bits, time1e-7s, utility1e-8 absolute +1e-9 relative; safety unchanged'))
    summarize(target);print('Imported PROP seeds:',imported)
