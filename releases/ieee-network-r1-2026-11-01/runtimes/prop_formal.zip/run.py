"""Portable entry point. Resolve every runtime input relative to this file."""
from pathlib import Path
import os,sys
ROOT=Path(__file__).resolve().parent
for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[n]='1'
_dll_handles=[]
if os.name=='nt':
    d=Path(sys.prefix)/'Library/bin'
    if d.exists():
        os.environ['PATH']=str(d)+os.pathsep+os.environ.get('PATH','')
        _dll_handles.append(os.add_dll_directory(str(d)))
sys.path.insert(0,str(ROOT))
if __name__=='__main__':
    command=sys.argv.pop(1) if len(sys.argv)>1 else 'help'
    if command=='selfcheck':
        from formal_check import main
    elif command=='worker':
        from formal_worker import main
    elif command=='launch':
        from formal_supervisor import main
    elif command=='summarize':
        from formal_summary import main
    elif command=='import-prop':
        from formal_summary import import_prop as main
    else:raise SystemExit('python run.py {selfcheck|launch|summarize|import-prop}; use --help')
    main()
