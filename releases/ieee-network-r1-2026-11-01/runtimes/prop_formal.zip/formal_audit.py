"""Post-execution accounting; never feeds policy decisions."""
from collections import Counter,defaultdict
import csv,json,math
from formal_common import write
from src.payload.information_sufficiency import product_information_utility
from src.routers.requirement_aware_projection import product_satisfies

TOL=dict(time_s=1e-7,energy_j_abs=1e-5,utility_abs=1e-8,relative=1e-9,integer_bits=0,
    note='Comparison tolerances only; no relaxed physical limit, no modified safety predicate')
def csvwrite(path,rows):
    if not rows:return
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def union_duration(intervals):
    result=0.;last=None
    for a,b in sorted(intervals):
        if last is None:lo,hi=a,b;last=True
        elif a<=hi:hi=max(hi,b)
        else:result+=hi-lo;lo,hi=a,b
    return result+(hi-lo if last else 0.)
def audit(e,job,out,candidate_path,require_all=True):
    p=e.physics;s=e.evaluate();fail=[];checks={}
    def check(name,yes):
        checks[name]=bool(yes)
        if not yes:fail.append(name)
    near=lambda a,b:math.isclose(a,b,rel_tol=TOL['relative'],abs_tol=TOL['utility_abs'])
    ids=[r['task_id'] for r in e.arrival_events]
    check('arrival_identity',len(ids)==len(set(ids))==len(e.arrived) and all(r['time_s']==e.arrived[r['task_id']].arrival_s for r in e.arrival_events))
    if require_all:
        check('1600_tasks',len(e.arrived)==1600 and len(e.tasks)==1600)
        check('end21600',p.now==21600 and e.config['horizon_s']==21600 and s['terminal_settled'])
        check('quotas',Counter(t.value_level for t in e.arrived.values())==dict(low=322,medium=830,high=323,urgent=125))
    work=sorted(p.work,key=lambda w:(w.start_s,w.end_s,w.event_id))
    check('CPU_serial_and_unique',len({w.event_id for w in work})==len(work) and all(a.end_s<=b.start_s+1e-9 for a,b in zip(work,work[1:])))
    check('no_early_work',all(w.start_s>=e.arrived[w.task_id].arrival_s-1e-9 for w in work))
    check('causal_ready',all(v['decision_s']>=e.arrived[v['task_id']].arrival_s-1e-9 and v['encoding_start_s']>=v['inference_end_s']-1e-9 and v['ready_s']>=v['encoding_start_s'] for v in p.products.values()))
    check('TX_ready_window',all(f['start_s']>=p.products[f['product_id']]['ready_s']-1e-9 and f['end_s']<=p.kernel.link_at(f['start_s']).end_s+1e-9 and p.kernel.link_at(f['start_s']).business_rate_bit_s>0 for f in p.flows))
    sent=Counter();remaining=Counter();expired=Counter()
    for f in p.flows:sent[f['product_id']]+=f['progress_bits']
    for x in p.order:remaining[x.product_id]+=x.remaining_bits
    for x in p.expired:expired[x['product_id']]+=x['remaining_bits']
    check('integer_bit_conservation',all(v['original_bits']==sent[k]+remaining[k]+expired[k] for k,v in p.products.items()))
    check('ground_causal_and_period',all(r['ground_available_s']>=r['tx_end_s']>=p.products[r['product_id']]['ready_s']-1e-9 and r['ground_available_s']<=p.now+1e-9 for r in e.ground_ledger))
    gross=0.;delivered=defaultdict(set);bytask=Counter();closure=set()
    for r in e.ground_ledger:
        t=e.arrived[r['task_id']];seen=delivered[t.task_id]
        valid=r['ground_available_s']<=min(t.deadline_time_s,p.now)+1e-9
        delta=max(0.,product_information_utility(seen|{r['product']},t.product_requirement,e.cfg['product_requirement_utility'])-product_information_utility(seen,t.product_requirement,e.cfg['product_requirement_utility'])) if valid else 0.
        g=max(0.,t.task_value)*r['q']*delta*max(0.,1.-(r['ground_available_s']-t.arrival_s)/t.deadline_s)
        gross+=g;bytask[t.task_id]+=g
        if valid:seen.add(r['product'])
        if valid and product_satisfies(r['product'],t.product_requirement):closure.add(t.task_id)
    check('independent_gross_and_closure',near(gross,s['gross']) and closure==set(e.closed))
    energy=sum(max(0.,min(p.now,w.end_s)-w.start_s)*w.incremental_power_w for w in work)+sum(f['energy_j'] for f in p.flows)
    mb=sum(f['business_bits'] for f in p.flows)/8e6
    q=sum(x.remaining_bits for x in p.order if x.ready_time_s<=p.now+1e-10)/8e6
    prices=e.config['public_prices'];ec=energy*prices['energy_price_per_Wh']/3600.;bc=mb*prices['downlink_price_per_MB'];qc=q*prices['terminal_backlog_price_per_MB'] if s['terminal_settled'] else 0.
    check('actual_E_B_Q_and_fixed_net',math.isclose(energy,s['ledger']['controlled_j'],rel_tol=1e-9,abs_tol=1e-5) and near(mb,s['ledger']['downlink_mb']) and near(q,s['ledger']['backlog_mb']) and near(gross-ec-bc-qc,s['net']))
    check('background_separate',math.isclose(s['ledger']['background_j'],8.86*p.now,rel_tol=1e-9,abs_tol=1e-5))
    peaks={k:max([p.network.p.initial_state().to_dict()['temperatures_c'][k]]+[r['thermal']['peaks_c'][k] for r in p.trajectory]) for k in ('chip','board','rf','structure')}
    violations=sum(not r['thermal']['safe'] for r in p.trajectory)+sum(r['battery']['unserved_load_energy_j']>0 for r in p.trajectory)
    check('physical_safety',violations==0)
    byreason=Counter();reason_tasks=defaultdict(set);categories=Counter();feasible=0;denom=0;deltaq=[];models=Counter();progressive=0;bad_switch=[]
    with candidate_path.open(encoding='utf-8') as f:
        for line in f:
            r=json.loads(line);denom+=1;categories[r['admission_category']]+=1;feasible+=bool(r['feasible'])
            if r['score'].get('delta_Q_end_mb') is not None:deltaq.append(r['score']['delta_Q_end_mb'])
            for why in set(r['reasons']):byreason[why]+=1;reason_tasks[why].add(r['task_id'])
            if r['admission_category']=='admitted':models[r['model']]+=1;progressive+=bool(r['continuation'])
            arm=job['arm'];g=r['guidance'];sc=r['score']
            if arm=='NO_RESOURCE_MODULATION' and (g['mu_E']!=0 or g['mu_B']!=0 or not near(sc['effective_price_E'],prices['energy_price_per_Wh']/3600.) or not near(sc['effective_price_B'],prices['downlink_price_per_MB'])):bad_switch.append('NO_RESOURCE_MODULATION')
            if arm=='NO_MODE' and (g['m_E']!=1 or g['m_B']!=1):bad_switch.append('NO_MODE')
            if arm=='FIXED_HIGH' and r['model']!='high_accuracy':bad_switch.append('FIXED_HIGH')
            if arm=='NO_PROGRESSIVE_REFINEMENT' and r['continuation']:bad_switch.append('NO_PROGRESSIVE_REFINEMENT')
            if arm=='REQUIRED_PRODUCT_ONLY' and not product_satisfies(r['product'],e.arrived[r['task_id']].product_requirement):bad_switch.append('REQUIRED_PRODUCT_ONLY')
    check('candidate_denominator',denom==sum(sum(d['candidate_categories'].values()) for d in e.decisions))
    check('arm_switch',not bad_switch)
    periods=[]
    for wid in dict.fromkeys(x.window_id for x in p.kernel.links if x.window_id):
        links=[x for x in p.kernel.links if x.window_id==wid];a=min(x.start_s for x in links);b=max(x.end_s for x in links)
        flows=[f for f in p.flows if a<=f['start_s']<b];tx=union_duration([(f['start_s'],f['end_s']) for f in flows]);cap=sum(x.business_rate_bit_s*(x.end_s-x.start_s) for x in links)/8e6;used=sum(f['business_bits'] for f in flows)/8e6
        periods.append(dict(window=wid,start_s=a,end_s=b,business_seconds=b-a,nominal_MB=cap,TX_union_s=tx,downlink_MB=used,RF_energy_J=sum(f['energy_j'] for f in flows),time_utilization=tx/(b-a),capacity_utilization=used/cap if cap else None))
    rows=[]
    for tid,t in e.arrived.items():
        d=delivered[tid];highest=next((k for k in ('roi_context','roi','metadata') if k in d),'none')
        fees=s['ledger']['by_task'].get(tid,{});E=sum(fees.get(k,0.) for k in ['inference_j','encoding_j','tx_j']);B=fees.get('downlink_mb',0.);Q=sum(x.remaining_bits for x in p.order if x.task_id==tid and x.ready_time_s<=p.now+1e-10)/8e6
        rows.append(dict(task_id=tid,value_level=t.value_level,HV=t.value_level in {'high','urgent'},required=t.product_requirement,arrival_s=t.arrival_s,deadline_s=t.deadline_time_s,
            gross=bytask[tid],E_cost=E*prices['energy_price_per_Wh']/3600.,B_cost=B*prices['downlink_price_per_MB'],Q_cost=Q*prices['terminal_backlog_price_per_MB'] if s['terminal_settled'] else 0.,
            highest_effective_ground_product=highest,satisfies_requirement=tid in closure,partial_only=bool(d) and tid not in closure,lateDDL=t.deadline_time_s>p.now,
            status=s['task_status'][tid],ready_backlog_MB=Q,actual_TX_product='compressed_image' if any(v['task_id']==tid and v['route'] in {'B1','GROUND'} for v in p.products.values()) else 'onboard_product_or_none'))
    csvwrite(out/'task_accounting.csv',rows);csvwrite(out/'windows.csv',periods)
    mode_times=Counter()
    for i,r in enumerate(e.controller.mode_updates):mode_times[r['mode']]+=min(p.now,e.controller.mode_updates[i+1]['time_s'] if i+1<len(e.controller.mode_updates) else p.now)-r['time_s']
    summary=dict(**s,arm=job['arm'],peak_temperatures_c=peaks,min_soc=min([e.cfg['simulator']['battery_init']]+[r['battery']['soc_after'] for r in p.trajectory]),
        actual_safety_violations=violations,thermal_protection_count=len(p.actual_thermal_protection),thermal_wait_s=union_duration([(r['start_s'],r['end_s']) for r in p.trajectory if r.get('thermal_blocked_product')]),
        selected_models=dict(models),progressive_authorizations=progressive,progressive_ground_events=sum(bool(p.products[r['product_id']].get('continuation')) and r['valid'] for r in e.ground_ledger),
        ground_state_counts=dict(Counter((r['highest_effective_ground_product']+('_satisfied' if r['satisfies_requirement'] else '_partial' if r['partial_only'] else '')) for r in rows)),
        candidate_denominator=denom,feasible_candidates=feasible,rejection_reasons=[dict(reason=k,candidates=v,distinct_tasks=len(reason_tasks[k])) for k,v in byreason.items()],candidate_categories=dict(categories),
        delta_Q_end=dict(nonzero=sum(abs(v)>1e-12 for v in deltaq),min=min(deltaq,default=None),max=max(deltaq,default=None),evaluated=len(deltaq)),mode_seconds=dict(mode_times),windows=periods)
    write(out/'AUDITED_SUMMARY.json',summary)
    return dict(pass_=not fail,**{'pass':not fail},checks=checks,failures=fail,tolerances=TOL,claim='Finite-period five-seed engineering proxy experiment; not measured onboard compute')
