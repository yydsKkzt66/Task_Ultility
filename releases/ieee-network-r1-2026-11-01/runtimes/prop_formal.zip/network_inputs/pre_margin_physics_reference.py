"""Single physical owner using the hash-verified C06 kernel, with no R06 prices.

Module contract: Physical event actuator owns work/energy/materialization;
Downlink queue owns ready ordering and partial bytes; evaluator consumes actual
ground events only. Prediction receives immutable state and detached orders.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict, replace
from types import SimpleNamespace
from copy import deepcopy
import hashlib, json, math

from src.energy.celsius_thermal_network_v1 import CelsiusNetworkParametersV1, CelsiusThermalNetworkV1
from src.link.event_queue_runtime_v3 import EventQueueKernelV3, ComputeIntervalV3
from src.link.net_utility_insertion_v2 import IndependentQueueStageV2


@dataclass(frozen=True)
class NoHeatPrice:
    qualification: str = 'NETWORK_NO_INDEPENDENT_HEAT_CHARGE'


def fingerprint(x):
    return hashlib.sha256(json.dumps(x,sort_keys=True,default=str,allow_nan=False).encode()).hexdigest()


def ground_receipt(tx_s, info, pending, free_s):
    """Pure shared receive/admission rule for forecast and execution.

    Capacity is 32 waiting jobs, plus the one in service. A full receiver
    rejects the already transmitted input; TX energy/bytes remain real.
    """
    start=tx_s
    if info['ground_s'] and info['route'] in {'GROUND','B1'}:
        waiting=sum(r['route'] in {'GROUND','B1'} and r['ground_start_s']>tx_s+1e-9 for r in pending)
        if waiting>=32:return None,free_s
        start=max(tx_s,free_s);free_s=start+info['ground_s']
    available=start+info['ground_s']
    row=dict(product_id=info['product_id'],task_id=info['task_id'],product=info['product'],
        route=info['route'],q=info['q'],model=info['model'],tx_end_s=tx_s,
        ground_start_s=start,ground_available_s=available,deadline_s=info['deadline_s'],
        valid=available<=info['deadline_s']+1e-9)
    return row,free_s


class NetworkPhysics:
    def __init__(self, network_config, simulator, links):
        self.network=CelsiusThermalNetworkV1(CelsiusNetworkParametersV1(**network_config),max_step_s=20.)
        # Only battery properties are consumed with bill=False. C06 pricing is
        # deliberately absent, so no second fixed fee or independent H fee.
        pricing=SimpleNamespace(h=NoHeatPrice(),kappa={},refs={},beta=1.,gamma=1.,
            battery_capacity_j=simulator['battery_capacity_j'],
            charge_efficiency=simulator['battery_charge_efficiency'],
            discharge_efficiency=simulator['battery_discharge_efficiency'])
        self.kernel=EventQueueKernelV3(network=self.network,pricing=pricing,links=links)
        self.state=self.network.p.initial_state()
        self.soc=simulator['battery_init']
        self.order=[];self.work=[];self.completed={};self.window_transmitted={}
        self.products={};self.inference_cache={};self.materialization_cache={}
        self.flows=[];self.trajectory=[];self.events=[];self.expired=[]
        self.ground_pending=[];self.ground_events=[];self.ground_free=0.
        self.trace_enabled=True

    @property
    def now(self): return self.state.time_s

    def identity(self):
        return fingerprint(dict(state=asdict(self.state),soc=self.soc,order=[asdict(x) for x in self.order],
            work=[asdict(x) for x in self.work],completed=self.completed,products=self.products,
            inference=self.inference_cache,materialization=self.materialization_cache,
            window_transmitted=self.window_transmitted,ground_pending=self.ground_pending,
            ground_free=self.ground_free,ground_events=self.ground_events,
            expired=self.expired,flows=self.flows,trajectory=self.trajectory,events=self.events))

    def project(self, *, order=None, work=None, end_s):
        return self.kernel.project(thermal_state=self.state,soc=self.soc,
            order=tuple(self.order if order is None else order),completed=dict(self.completed),
            work=tuple(self.work if work is None else work),end_s=end_s,bill=False,
            window_transmitted_bits=dict(self.window_transmitted))

    def plan(self, *, task_id, model, product, size_mb, inference_s, inference_j,
             encoding_s, encoding_j, deadline_s, q, route='DIRECT',ground_s=0.):
        """Create dated work without mutating cache, time, queue or RNG."""
        pid=f'{task_id}:{product}:{route}'
        if pid in self.products: raise ValueError('DUPLICATE_PRODUCT')
        cache_key=f'{task_id}:{model}'
        compute_free=max([self.now]+[w.end_s for w in self.work])
        new=[];cached=self.inference_cache.get(cache_key)
        if cached:
            infer_start=cached['start_s'];infer_end=cached['end_s']
        elif inference_s:
            infer_start=compute_free;infer_end=infer_start+inference_s
            new.append(ComputeIntervalV3(cache_key+':inference',task_id,'inference',infer_start,infer_end,inference_j/inference_s))
        else: infer_start=infer_end=compute_free
        encode_start=max(compute_free,infer_end)
        ready=encode_start+encoding_s
        if encoding_s:
            new.append(ComputeIntervalV3(pid+':encoding',task_id,'encoding',encode_start,ready,encoding_j/encoding_s))
        bits=math.ceil(size_mb*8e6-1e-8)
        if bits<=0: raise ValueError('EMPTY_PRODUCT')
        item=IndependentQueueStageV2(pid,task_id,product,ready,deadline_s,bits)
        return dict(item=item,work=new,cache_key=cache_key,cached=bool(cached),model=model,q=q,
            inference_start_s=infer_start,inference_end_s=infer_end,encoding_start_s=encode_start,
            ready_s=ready,ground_s=ground_s,route=route,original_bits=bits,
            decision_s=self.now,inference_j=0. if cached else inference_j,encoding_j=encoding_j)

    def authorize(self,plan):
        item=plan['item']
        if item.product_id in self.products: raise ValueError('DUPLICATE_AUTHORIZATION')
        self.order.append(item);self.work.extend(plan['work'])
        info={k:v for k,v in plan.items() if k not in {'item','work'}}
        info.update(task_id=item.task_id,product=item.product_type,deadline_s=item.deadline_s,
                    authorization_id='auth:'+item.product_id,product_id=item.product_id)
        self.products[item.product_id]=info
        if plan['inference_end_s']>plan['inference_start_s']:
            self.inference_cache.setdefault(plan['cache_key'],dict(start_s=plan['inference_start_s'],end_s=plan['inference_end_s']))
        self.materialization_cache[item.product_id]=item.ready_time_s
        self.events.append(dict(kind='AUTHORIZED',time_s=self.now,product_id=item.product_id,task_id=item.task_id))

    def execute(self,end_s,*,service_order=None):
        """Only this method commits physical truth. No policy selection here."""
        p=self.project(end_s=end_s,order=service_order)
        if not p['safe']: raise RuntimeError('EXECUTION_SAFETY_STOP:'+p['reason'])
        oldnow=self.now
        self.state=p['state'];self.soc=p['soc'];self.completed=p['completed']
        self.window_transmitted=p['transmitted_by_window']
        self.flows.extend(p['flows']);self.trajectory.extend(p['trajectory'])
        for pid,info in self.products.items():
            if oldnow<info['ready_s']<=end_s:
                self.events.append(dict(kind='MATERIALIZED_READY',time_s=info['ready_s'],product_id=pid,task_id=info['task_id']))
        finished=sorted(((t,pid) for pid,t in p['finishes'].items() if t is not None))
        for t,pid in finished:
            info=self.products[pid]
            self.events.append(dict(kind='TX_COMPLETE',time_s=t,product_id=pid,task_id=info['task_id']))
            row,self.ground_free=ground_receipt(t,info,self.ground_pending,self.ground_free)
            if row is None:
                self.events.append(dict(kind='GROUND_QUEUE_OVERFLOW',time_s=t,product_id=pid,task_id=info['task_id']))
                continue
            self.ground_pending.append(row)
        for row in list(self.ground_pending):
            if row['ground_available_s']<=end_s+1e-9:
                self.ground_events.append(row);self.ground_pending.remove(row)
                self.events.append(dict(kind='GROUND_AVAILABLE',time_s=row['ground_available_s'],
                    product_id=row['product_id'],task_id=row['task_id']))
        keep=[]
        for item in self.order:
            remaining=int(round(p['remaining'][item.product_id]))
            if remaining<=0: continue
            if item.deadline_s<=end_s+1e-9:
                self.expired.append(dict(product_id=item.product_id,task_id=item.task_id,time_s=item.deadline_s,remaining_bits=remaining))
                continue
            sent=item.sent_bits+item.remaining_bits-remaining
            keep.append(replace(item,remaining_bits=remaining,sent_bits=sent,partially_served=sent>0))
        self.order=keep
        return p

    def service_margin(self,ready,deadline,baseline):
        """Usable, future known service minus overlapping committed actual plan.

        Business rate already includes the old capacity multiplier. Thermal
        reduction is obtained from the shared kernel; no second link loss.
        This is a quotation, never a claim of actual TX.
        """
        offered=self.kernel.offered_bits_between(max(self.now,ready),deadline)
        booked=sum(max(0.,min(deadline,f['end_s'])-max(self.now,ready,f['start_s']))
            *f['business_bits']/(f['end_s']-f['start_s']) for f in baseline['flows'])
        return dict(offered_bits=offered,committed_bits=booked,remaining_bits=max(0.,offered-booked))

    def executable_margin(self,ready,end,baseline):
        """Thermal/electric service quote with existing service protected.

        Uses the exact C06 physical kernel, not time-to-window-end. Probe bytes
        and energy remain detached. If the saturated probe cannot certify its
        own whole prefix, binary-search a safe useful volume; do not charge it.
        """
        margin=self.service_margin(ready,end,baseline)
        upper=int(math.floor(margin['remaining_bits']))
        if upper<=0 or ready>=end:
            margin['safe_available_bits']=margin['committed_bits'];return margin
        reservations=tuple((f['product_id'],f['start_s'],f['end_s']) for f in baseline['flows'] if f['start_s']<end)
        def trial(bits):
            probe=IndependentQueueStageV2('__capacity_probe__','__probe__','probe',max(self.now,ready),end,bits)
            p=self.kernel.project(thermal_state=self.state,soc=self.soc,
                order=tuple(self.order)+(probe,),completed=dict(self.completed),work=tuple(self.work),end_s=end,
                bill=False,window_transmitted_bits=dict(self.window_transmitted),reserved_slices=reservations)
            protected=all(baseline['finishes'].get(x.product_id) is None or baseline['finishes'][x.product_id]>end
                or (p['finishes'].get(x.product_id) is not None and p['finishes'][x.product_id]<=baseline['finishes'][x.product_id]+1e-7)
                for x in self.order)
            served=sum(f['business_bits'] for f in p['flows'] if f['product_id']=='__capacity_probe__')
            return p['safe'] and protected,served
        good,served=trial(upper)
        if not good:
            lo,hi=0,upper
            while hi-lo>1:
                mid=(lo+hi)//2;ok,_=trial(mid)
                if ok:lo=mid
                else:hi=mid
            served=lo
        margin.update(safe_available_bits=margin['committed_bits']+served,remaining_bits=served,
            qualification='DETACHED_COMMON_KERNEL_EXECUTABLE_SERVICE_NOT_ACTUAL_TX')
        return margin

    def ledger(self):
        compute={w.event_id:w for w in self.work};by_task={}
        background=solar=delta=curtailed=0.
        for row in self.trajectory:
            b=row['battery'];background+=b['common_energy_j'];solar+=b['solar_energy_j']
            delta+=b['actual_battery_delta_j'];curtailed+=b['curtailed_solar_energy_j']
            for wid in row['active_compute']:
                w=compute[wid];rec=by_task.setdefault(w.task_id,dict(inference_j=0.,encoding_j=0.,tx_j=0.,downlink_mb=0.))
                rec[w.kind+'_j']+=(row['end_s']-row['start_s'])*w.incremental_power_w
        for f in self.flows:
            rec=by_task.setdefault(f['task_id'],dict(inference_j=0.,encoding_j=0.,tx_j=0.,downlink_mb=0.))
            rec['tx_j']+=f['energy_j'];rec['downlink_mb']+=f['business_bits']/8e6
        return dict(by_task=by_task,background_j=background,solar_j=solar,
            battery_delta_j=delta,curtailed_solar_j=curtailed,
            controlled_j=sum(r['inference_j']+r['encoding_j']+r['tx_j'] for r in by_task.values()),
            downlink_mb=sum(r['downlink_mb'] for r in by_task.values()),
            backlog_mb=sum(x.remaining_bits for x in self.order)/8e6,
            expired_mb=sum(x['remaining_bits'] for x in self.expired)/8e6)
