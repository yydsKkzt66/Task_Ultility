"""Portable hash and eventful regression gate, no formal workload execution."""
from pathlib import Path
import argparse,sys,time,os
from formal_common import ROOT,write,verify
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--development',action='store_true');ap.add_argument('--out',default='SELF_CHECK');a=ap.parse_args()
    out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
    identities={} if a.development else verify()
    sys.path.insert(0,str(ROOT/'tests'))
    import pytest
    files=['test_network_formal6h.py','test_network_revision_physics.py','test_network_revision_runtime.py','test_network_revision_review_regressions.py','test_network_incremental.py','test_network_incremental_independent.py','test_network_multiarrival.py','test_network_prop_ablations.py']
    begin=time.perf_counter()
    result=pytest.main(['-q','-p','no:cacheprovider','--junitxml='+str(out/'pytest.xml'),'-k','not unmodified_full_prop_short_real_prefix_exact_parity',*[str(ROOT/'tests'/f) for f in files]])
    imports={}
    for name,module in list(sys.modules.items()):
        if (name=='src' or name.startswith('src.') or name.startswith('network_frozen_')) and getattr(module,'__file__',None):
            path=Path(module.__file__).resolve();imports[name]=str(path)
            if not path.is_relative_to(ROOT):raise RuntimeError('OUTSIDE_PACKAGE_IMPORT:'+str(path))
    report=dict(pass_=result==0,pytest_exitcode=result,source_root=str(ROOT),cwd=str(Path.cwd()),python=sys.version,seconds=time.perf_counter()-begin,manifests=identities,imports=imports,
        external_project_PYTHONPATH=os.environ.get('PYTHONPATH'),invariants='eventful windows, independent ledger, multiarrival, causal ready, crosswindow bytes, terminal Q nonzero, five switches, checkpoint resume for four methods')
    write(out/'SELF_CHECK.json',report)
    raise SystemExit(result)
