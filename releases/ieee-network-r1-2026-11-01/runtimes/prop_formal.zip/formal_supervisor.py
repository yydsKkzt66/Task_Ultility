"""Five independent jobs maximum; 60s status, exact-version resume."""
from pathlib import Path
import argparse,sys,os,time,subprocess,signal
import psutil
from formal_common import ROOT,read,write,verify,alive

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--group',choices=['main','ablation'],required=True);ap.add_argument('--out',default='outputs');ap.add_argument('--max-workers',type=int,default=5);ap.add_argument('--detach',action='store_true');ap.add_argument('--poll-seconds',type=float,default=60.)
    a=ap.parse_args();assert 1<=a.max_workers<=5 and 1<=a.poll_seconds<=60
    out=Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True);verify()
    lock=out/'SUPERVISOR.json'
    if lock.exists() and alive(read(lock)):raise SystemExit('Existing supervisor is active; see '+str(lock))
    if a.detach:
        command=[sys.executable,str(ROOT/'run.py'),'launch','--group',a.group,'--out',str(out),'--max-workers',str(a.max_workers),'--poll-seconds',str(a.poll_seconds)]
        log=(out/'supervisor.log').open('ab')
        flags=(subprocess.CREATE_NO_WINDOW|subprocess.CREATE_BREAKAWAY_FROM_JOB) if os.name=='nt' else 0
        proc=subprocess.Popen(command,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,creationflags=flags,start_new_session=os.name!='nt')
        write(out/'LAUNCH.json',dict(command=command,pid=proc.pid,created_epoch=time.time(),max_workers=a.max_workers));print('SUPERVISOR_PID',proc.pid,'OUTPUT',out);return
    write(lock,dict(pid=os.getpid(),process_created=psutil.Process().create_time(),group=a.group,command=sys.argv))
    jobs=[j for j in read(ROOT/'RUN_MATRIX.json')['jobs'] if j['group']==a.group]
    if a.group=='main':jobs.sort(key=lambda j:(j['arm']!='PROP',j['seed'],['PROP','GROUND','OFFLOAD','TUT_ADAPTED'].index(j['arm'])))
    running={};logs={}
    def attempts(job):
        folder=out/f"{job['seed']}_{job['arm']}";return sorted(p for p in folder.glob('attempt_*') if p.is_dir())
    def state(job):
        aa=attempts(job)
        key=(job['seed'],job['arm'])
        if not aa:
            if key in running and running[key].poll() is None:return 'STARTING',None,None
            if key in running:return 'INTERRUPTED',None,None
            return 'PENDING',None,None
        p=aa[-1];s=read(p/'STATUS.json') if (p/'STATUS.json').exists() else {}
        if (p/'COMPLETED.json').exists() and read(p/'AUDIT.json')['pass']:return 'COMPLETED',p,s
        if alive(s):return 'RUNNING',p,s
        if key in running and running[key].poll() is None:return 'STARTING',p,s
        if (p/'FAILED.json').exists():return 'FAILED',p,s
        if (p/'LATEST_CHECKPOINT.json').exists() and len(aa)<4:return 'RESUMABLE',p,s
        return 'INTERRUPTED',p,s
    try:
        while True:
            states=[(j,*state(j)) for j in jobs];active=sum(st in {'RUNNING','STARTING'} for _,st,_,_ in states)
            # Seed barrier on portable machine: never run next seed until A-E finished.
            pending_seed=next((seed for seed in sorted({j['seed'] for j in jobs}) if any(j['seed']==seed and st!='COMPLETED' for j,st,_,_ in states)),None)
            for j,st,p,s in states:
                if active>=a.max_workers:break
                if st not in {'PENDING','RESUMABLE'}:continue
                if a.group=='ablation' and j['seed']!=pending_seed:continue
                if psutil.virtual_memory().available<2.0*1024**3:break
                folder=out/f"{j['seed']}_{j['arm']}";folder.mkdir(exist_ok=True)
                attempt=folder/f'attempt_{len(attempts(j))+1:02d}'
                command=[sys.executable,str(ROOT/'run.py'),'worker','--seed',str(j['seed']),'--arm',j['arm'],'--out',str(attempt)]
                if st=='RESUMABLE':command+=['--resume',str(p/read(p/'LATEST_CHECKPOINT.json')['path'])]
                log=(folder/(attempt.name+'.log')).open('ab')
                child=subprocess.Popen(command,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
                running[(j['seed'],j['arm'])]=child;logs[child.pid]=log;active+=1
                write(folder/(attempt.name+'_LAUNCH.json'),dict(command=command,pid=child.pid,epoch=time.time()))
                print('START',j['seed'],j['arm'],child.pid,flush=True)
            rows=[]
            for j in jobs:
                st,p,s=state(j);row=dict(seed=j['seed'],arm=j['arm'],status=st,attempt=str(p) if p else None,**{k:s.get(k) if s else None for k in ['time_s','arrivals','closed','active_wall_s','total_wall_s','cpu_s','rss_bytes','peak_rss_bytes','pid','process_created']})
                if st=='RUNNING':
                    try:
                        proc=psutil.Process(row['pid']);row['rss_bytes']=proc.memory_info().rss;row['live_process_cpu_s']=sum(proc.cpu_times()[:2]);row['live_process_wall_s']=time.time()-proc.create_time()
                    except psutil.Error:pass
                t=row.get('time_s') or 0;wall=row.get('active_wall_s') or 0
                row['ETA_remaining_s_linear_observed']=wall/t*(21600-t) if t>=3600 and st=='RUNNING' else None
                rows.append(row)
            write(out/'PROGRESS.json',dict(updated_epoch=time.time(),rows=rows,memory_available_bytes=psutil.virtual_memory().available,ETA_note='Per-job observed average only; window load and later queue growth can change speed'))
            lines=['# 正式运行进度','',time.strftime('更新时间：%Y-%m-%d %H:%M:%S'),'', '|方法|种子|状态|仿真秒|到达|闭环|有效墙钟秒|含中断墙钟秒|CPU秒|内存MB|PID|','|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|']
            for r in rows:
                f=lambda x:'—' if x is None else f'{x:.1f}' if isinstance(x,float) else str(x)
                lines.append('|'+ '|'.join(f(x) for x in [r['arm'],r['seed'],r['status'],r['time_s'],r['arrivals'],r['closed'],r['active_wall_s'],r['total_wall_s'],r['cpu_s'],r['rss_bytes']/1e6 if r['rss_bytes'] else None,r['pid']])+'|')
            lines+=['','每60s更新；未完成不计零。墙钟/CPU是桌面运行开销。每小时、每个窗口结束保存账本和完整恢复状态。','ETA使用已运行速度估计，尚未经过首窗的作业不作完工承诺。']
            (out/'00_PROGRESS_CN.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
            from formal_summary import summarize
            summarize(out,plots=all(r['status']=='COMPLETED' for r in rows))
            terminal={'COMPLETED','FAILED','INTERRUPTED'}
            if all(r['status'] in terminal for r in rows) or (not any(r['status'] in {'RUNNING','STARTING','RESUMABLE'} for r in rows) and a.group=='ablation' and any(r['status'] in {'FAILED','INTERRUPTED'} and r['seed']==pending_seed for r in rows)):
                write(out/'SUPERVISOR_FINISHED.json',dict(epoch=time.time(),all_completed=all(r['status']=='COMPLETED' for r in rows),rows=rows));break
            time.sleep(a.poll_seconds)
    finally:
        for log in logs.values():log.close()
        # Workers are independent; controller exit never kills authorized work.
        write(out/'SUPERVISOR_EXIT.json',dict(epoch=time.time(),pid=os.getpid()))
if __name__=='__main__':main()
