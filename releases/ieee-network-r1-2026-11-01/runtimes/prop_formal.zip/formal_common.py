from pathlib import Path
import hashlib,json,os,time,pickle
from collections import OrderedDict
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,value):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    q=p.with_name(p.name+'.tmp');q.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False,default=str)+'\n',encoding='utf-8');os.replace(q,p)
def verify():
    manifests={}
    for name in ['SOURCE_MANIFEST.json','INPUT_MANIFEST.json']:
        m=read(ROOT/name)
        for r,h in m['files'].items():
            if not (ROOT/r).is_file() or sha(ROOT/r)!=h:raise ValueError('FROZEN_HASH_MISMATCH:'+r)
        manifests[name]=sha(ROOT/name)
    return manifests
def job_for(seed,arm):
    return next(x for x in read(ROOT/'RUN_MATRIX.json')['jobs'] if x['seed']==seed and x['arm']==arm)
def load_dynamic(method):
    from src.network_revision.runtime import private_module,load_b1_scheduler
    if method=='TUT':private_module('network_frozen_tut',ROOT/'vendor/frozen_runtime_v1/tut/src/routers/tut_uoi_rate_router.py')
    if method=='B1':return load_b1_scheduler(ROOT/'vendor/frozen_runtime_v1/b1_offload/src/baselines/b1_enhanced.py')
def dump_checkpoint(e,path):
    removed={k:e.__dict__.pop(k) for k in ('decide','slot_complete_hook','b1_module') if k in e.__dict__}
    b1safe=e.b1.__dict__.pop('_hard_safety_feasible',None) if e.b1 else None
    cache=e.physics.kernel._projection_cache;e.physics.kernel._projection_cache=OrderedDict()
    tmp=Path(str(path)+'.tmp')
    try:
        with tmp.open('wb') as f:pickle.dump(e,f,pickle.HIGHEST_PROTOCOL)
        os.replace(tmp,path)
    finally:
        e.physics.kernel._projection_cache=cache;e.__dict__.update(removed)
        if b1safe is not None:e.b1._hard_safety_feasible=b1safe
def load_checkpoint(path,method):
    mod=load_dynamic(method)
    with Path(path).open('rb') as f:e=pickle.load(f)
    e.root=ROOT
    if mod:e.b1_module=mod
    return e
def alive(status):
    import psutil
    try:
        p=psutil.Process(status['pid'])
        return p.is_running() and abs(p.create_time()-status['process_created'])<.1
    except (psutil.Error,KeyError):return False
