"""Independent, synthetic mechanism audit for the incremental pricing contract.

These short scenes copy only the frozen input schema. They are not historical
task replays, tuning evidence, a real prefix, or a formal full-horizon run.
"""
from copy import deepcopy
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace as NS
import math

import pytest

from src.network_revision.incremental import incremental_score, terminal_quote, choose_incremental
from src.network_revision.physics import NetworkPhysics, fingerprint
from src.network_revision.runtime import NetworkExperiment
from src.payload.payload_policy import get_payload_policy_profile
from src.payload.payload_sizer import (
    _estimate_label_roi_size_mb, estimate_payload_size_with_diagnostics,
    estimate_payload_encoding_cost,
)
from test_network_revision_runtime import interval, action, authorize_mechanism, full_decision_state


ROOT = Path(__file__).resolve().parents[1]


def scene(variant='incremental', method='PROP', links=None, requirement='verification'):
    e = NetworkExperiment(ROOT, variant, method)
    t = deepcopy(e.tasks[0])
    t.task_id = 'synthetic_independent_incremental_a'
    t.arrival_slot = 0
    t.arrival_s = 0.
    t.deadline_s = t.deadline_time_s = 60.
    t.product_requirement = requirement
    t.quality_requirement = t.information_requirement = .1
    t.value_level = 'low'
    t.high_value_flag = t.emergency_flag = 0
    t.metadata['raw_payload_mb'] = 32.
    e.tasks = [t]
    e.arrived = {t.task_id: t}
    # Formal settlement stays 86400 even though the synthetic scene ends at 60.
    assert e.config['horizon_s'] == 86400.
    e.physics = NetworkPhysics(e.config['physics']['network'], e.cfg['simulator'],
                               links or [interval(0., 60.)])
    return e, t


def plan(e, t, product='roi', size=1., **kwargs):
    values = dict(task_id=t.task_id, model='lightweight', product=product,
                  size_mb=size, inference_s=0., inference_j=0., encoding_s=0.,
                  encoding_j=0., deadline_s=t.deadline_time_s, q=.6)
    values.update(kwargs)
    return e.physics.plan(**values)


def score_projection(e, t, new, order, end, ground=None):
    p = e.physics
    baseline = p.project(end_s=end)
    projected = p.project(order=order, work=p.work + new['work'], end_s=end)
    terminal = terminal_quote(p, order, projected, end)
    base_terminal = terminal_quote(p, p.order, baseline, end)
    guide = dict(mu_E=0., mu_B=0., product_utility_cfg=e.cfg['product_requirement_utility'])
    scored = incremental_score(t, new['item'].product_type, set(), .6, ground, new,
                               projected, baseline, terminal, base_terminal,
                               guide, e.config['public_prices'])
    return scored, projected, baseline


def test_label_byte_conversion_is_decimal_before_clamp():
    params = dict(estimated_roi_count_fraction=.2, min_estimated_roi_count=1,
                  max_estimated_roi_count=16, chip_area_padding_factor=1.5,
                  min_chip_area_px=100., max_chip_area_px=10000., bytes_per_pixel=2.,
                  compression_ratio=4., small_target_area_multiplier=.2,
                  min_payload_mb=.0001, max_payload_mb=10.)
    labels = dict(target_count=10, bbox_area_mean=400., bbox_area_max=900., small_target_ratio=.5)
    # 2 crops * 600 px * 2 byte/px * 1.1 / 4 = 660 bytes.
    size, diagnostics = _estimate_label_roi_size_mb(params, labels)
    assert size == pytest.approx(660. / 1_000_000)
    assert diagnostics['estimated_roi_size_kb'] == pytest.approx(.660)
    assert size != pytest.approx(660. / 1_048_576)
    limited = dict(params, max_payload_mb=.0005)
    assert _estimate_label_roi_size_mb(limited, labels)[0] == .0005


def test_metadata_and_declared_mb_fallback_are_not_globally_scaled():
    e, t = scene()
    profiles = e.cfg['payload_profiles']
    t.metadata['offline_label_summary'] = dict(target_count=7, bbox_area_mean=400.)
    meta_profile = get_payload_policy_profile('metadata', profiles)
    params = meta_profile.parameters
    expected = (params['base_size_kb'] + 7 * params['per_detection_record_bytes'] / 1000.) / 1000.
    assert estimate_payload_size_with_diagnostics('metadata', task=t, payload_profiles_cfg=profiles)[0] == pytest.approx(expected)
    t.metadata.pop('offline_label_summary')
    for product in ('roi', 'roi_context'):
        profile = get_payload_policy_profile(product, profiles)
        params = profile.parameters
        expected = params.get('fallback_roi_size_mb', params.get('fallback_size_mb', profile.base_size_mb))
        if product == 'roi_context':
            expected *= max(params.get('context_multiplier', params.get('context_margin_factor', 1.)), 1.)
            expected = min(params.get('max_payload_mb', 8.), max(params.get('min_payload_mb', .20), expected))
        observed, diag = estimate_payload_size_with_diagnostics(product, task=t, payload_profiles_cfg=profiles)
        assert diag['payload_size_source'] == 'fallback'
        assert observed == pytest.approx(expected)


def test_decimal_payload_propagates_to_encoding_integer_bits_and_tx_charge():
    e, t = scene()
    size = .123456789
    duration, energy = estimate_payload_encoding_cost('roi', size, e.cfg['payload_profiles'])
    profile = get_payload_policy_profile('roi', e.cfg['payload_profiles'])
    defaults = e.cfg['payload_profiles']['calibrated_profile']['defaults']
    assert duration == pytest.approx(size * defaults['encoding_latency_s_per_mb'] * profile.parameters.get('encoding_latency_scale', 1.))
    assert energy == pytest.approx(size * defaults['encoding_energy_j_per_mb'] * profile.parameters.get('encoding_energy_scale', 1.))
    new = plan(e, t, size=size, encoding_s=duration, encoding_j=energy)
    assert new['item'].remaining_bits == math.ceil(size * 8e6)
    scored, projected, _ = score_projection(e, t, new, [new['item']], 60., ground=1.)
    actual_mb = math.ceil(size * 8e6) / 8e6
    assert scored['tx_new_mb'] == pytest.approx(actual_mb)
    assert scored['fixed_costs']['downlink'] == pytest.approx(actual_mb * .09202386055743175)
    assert sum(f['business_bits'] for f in projected['flows']) == new['item'].remaining_bits


def test_common_terminal_backlog_cancels_when_candidate_completes_in_unused_service():
    e, t = scene(links=[interval(0., 1.), interval(1., 60., 0.)])
    old = deepcopy(t)
    old.task_id += '_existing'
    existing = plan(e, old, size=2.)
    # Known bytes released after the only contact, no inference is implied.
    existing['item'] = replace(existing['item'], ready_time_s=3.)
    existing['ready_s'] = 3.
    e.physics.authorize(existing)
    new = plan(e, t, size=.5)
    scored, projected, _ = score_projection(e, t, new, [new['item']] + e.physics.order, 20., ground=.5)
    assert projected['finishes'][new['item'].product_id] == pytest.approx(.5)
    assert scored['terminal']['backlog_mb'] == pytest.approx(2.)
    assert scored['baseline_terminal']['backlog_mb'] == pytest.approx(2.)
    assert scored['delta_Q_end_mb'] == 0.
    assert scored['fixed_costs']['terminal_backlog'] == 0.
    assert scored['commitment_impacts'] == []


def test_terminal_difference_includes_actual_candidate_remaining_and_expiry_boundary():
    e, t = scene(links=[interval(0., 60., 0.)])
    old = deepcopy(t)
    old.task_id += '_existing'
    e.physics.authorize(plan(e, old, size=2.))
    new = plan(e, t, size=1.)
    scored, _, _ = score_projection(e, t, new, e.physics.order + [new['item']], 20.)
    assert scored['baseline_terminal']['backlog_mb'] == 2.
    assert scored['terminal']['backlog_mb'] == 3.
    assert scored['delta_Q_end_mb'] == 1.
    assert scored['fixed_costs']['terminal_backlog'] == pytest.approx(.09202386055743175)
    expired, _, _ = score_projection(e, t, new, e.physics.order + [new['item']], 60.)
    assert expired['terminal']['certificate'] == 'KNOWN_WORK_EXPIRY'
    assert expired['delta_Q_end_mb'] == 0.


def test_completed_candidate_still_records_displaced_commitment_and_terminal_delta():
    e, t = scene(links=[interval(0., 1.), interval(1., 60., 0.)])
    old = deepcopy(t)
    old.task_id += '_existing'
    existing = plan(e, old, size=1.)
    e.physics.authorize(existing)
    new = plan(e, t, size=.5)
    scored, projected, baseline = score_projection(e, t, new, [new['item']] + e.physics.order,
                                                  20., ground=.5)
    assert projected['finishes'][new['item'].product_id] == pytest.approx(.5)
    assert baseline['finishes'][existing['item'].product_id] == pytest.approx(1.)
    assert scored['delta_Q_end_mb'] == pytest.approx(.5)
    assert scored['tx_new_mb'] == pytest.approx(.5)  # Existing-task TX is not charged to this task.
    assert len(scored['commitment_impacts']) == 1
    impact = scored['commitment_impacts'][0]
    assert impact['product_id'] == existing['item'].product_id
    assert impact['delayed'] and impact['candidate_finish_s'] is None
    assert impact['candidate_remaining_bits'] == 4e6


def test_terminal_quote_never_fills_missing_or_unsafe_projection_with_zero():
    e, t = scene(links=[interval(0., 60., 0.)])
    new = plan(e, t)
    short = e.physics.project(order=[new['item']], end_s=20.)
    unresolved = terminal_quote(e.physics, [new['item']], short, 86400.)
    assert not unresolved['resolved'] and unresolved['backlog_mb'] is None
    unsafe = dict(short, safe=False)
    assert not terminal_quote(e.physics, [new['item']], unsafe, 20.)['resolved']
    baseline = e.physics.project(end_s=20.)
    guide = dict(mu_E=0., mu_B=0., product_utility_cfg=e.cfg['product_requirement_utility'])
    scored = incremental_score(t, 'roi', set(), .6, 1., new, short, baseline, unresolved,
        terminal_quote(e.physics, [], baseline, 86400.), guide, e.config['public_prices'])
    assert scored['net_score'] is None and scored['fixed_net'] is None
    candidate = dict(feasible=True, score=scored, product='roi', action=action(e, 'roi'))
    assert choose_incremental([candidate], t, set())[0] is None


def test_failed_partial_tx_keeps_real_bytes_and_all_paid_work_in_evaluation():
    e, t = scene(links=[interval(0., .5), interval(.5, 60., 0.)])
    new = plan(e, t, size=1., inference_s=.2, inference_j=4., encoding_s=.1, encoding_j=2.)
    scored, projection, _ = score_projection(e, t, new, [new['item']], 60.)
    assert projection['finishes'][new['item'].product_id] is None
    assert scored['positive_benefit'] == 0.
    assert scored['tx_new_mb'] == pytest.approx(.2)
    assert scored['tx_new_j'] == pytest.approx(2.)
    assert scored['energy_new_j'] == pytest.approx(8.)
    e.physics.authorize(new)
    e.physics.execute(60.)
    e.observe_ground()
    result = e.evaluate()
    assert result['gross'] == 0. and result['ground_events'] == 0
    assert result['ledger']['expired_mb'] == pytest.approx(.8)
    assert result['ledger']['controlled_j'] == pytest.approx(8.)
    assert result['ledger']['downlink_mb'] == pytest.approx(.2)
    assert result['net'] == pytest.approx(scored['fixed_net'])
    assert result['net'] < 0.


def test_cached_continuation_pays_only_new_encoding_and_tx_and_inference_once():
    e, t = scene()
    authorize_mechanism(e, t)
    e.physics.execute(3.)
    e.observe_ground()
    assert e.delivered[t.task_id] == {'metadata'}
    row = e.candidate(t, action(e, 'roi'), continuation=True)
    assert row['cached_inference'] and row['score']['inference_new_j'] == 0.
    assert not any(w.kind == 'inference' for w in row['plan']['work'])
    assert row['score']['energy_new_j'] == pytest.approx(row['score']['encoding_new_j'] + row['score']['tx_new_j'])
    e.physics.authorize(row['plan'])
    e.physics.execute(20.)
    e.observe_ground()
    assert e.physics.ledger()['by_task'][t.task_id]['inference_j'] == pytest.approx(10.)


def test_positive_gross_negative_net_cached_continuation_is_rejected():
    e, t = scene()
    authorize_mechanism(e, t)
    e.physics.execute(3.)
    e.observe_ground()
    t.task_value = t.calibrated_task_value = 1e-6
    before = e.physics.identity()
    chosen = e.decide(t, continuation=True)
    assert chosen is None
    assert e.candidates and all(c['score']['positive_benefit'] > 0. for c in e.candidates)
    assert all(c['score']['net_score'] < 0. for c in e.candidates)
    assert e.physics.identity() == before
    assert e.decisions[-1]['candidate_categories']['economics'] > 0


@pytest.mark.parametrize('net, admitted', [(0., False), (1e-12, False), (1.0001e-12, True), (-1e-9, False)])
def test_zero_and_tolerance_ties_never_consume_resources(net, admitted):
    e, t = scene()
    row = dict(feasible=True, product='roi', action=action(e, 'roi'),
               score=dict(economic_projection_resolved=True, net_score=net))
    before = e.physics.identity()
    assert (choose_incremental([row], t, set())[0] is not None) == admitted
    assert e.physics.identity() == before


def test_candidate_purity_includes_policy_feedback_and_rng_in_both_action_orders():
    e, t = scene(requirement='evidence')
    authorize_mechanism(e, t)
    e.physics.execute(3.)
    e.observe_ground()
    e.controller.observe_slot(0, e.physics, t, arrived=e.arrived, pending=e.pending, closed=e.closed)
    before = (full_decision_state(e), fingerprint(vars(e.feedback)))
    actions = [action(e, 'roi'), action(e, 'roi_context')]
    forward = [e.public_candidate(e.candidate(t, a, continuation=True)) for a in actions]
    reverse = [e.public_candidate(e.candidate(t, a, continuation=True)) for a in reversed(actions)][::-1]
    assert fingerprint(forward) == fingerprint(reverse)
    assert (full_decision_state(e), fingerprint(vars(e.feedback))) == before


@pytest.mark.parametrize('method', ['MYOPIC', 'TUT', 'OFFLOAD', 'B1'])
def test_legacy_adapter_scores_selection_and_execution_match_pressure_fixed(method):
    observed = []
    for variant in ('pressure_fixed', 'incremental'):
        e, t = scene(variant, method)
        chosen = e.decide(t)
        assert all(c['score']['adapter'] == 'LEGACY_' + method + '_DECISION_PARADIGM' for c in e.candidates)
        e.advance_slot_events(20., 0)
        observed.append(dict(action=chosen['action'].action_name if chosen else None,
            scores=[c['score'] for c in e.candidates], physical=e.physics.identity(),
            ground=e.ground_ledger, costs=e.evaluate()['costs']))
    assert fingerprint(observed[0]) == fingerprint(observed[1])


@pytest.mark.parametrize('method', ['PROP', 'MYOPIC', 'TUT', 'OFFLOAD', 'B1'])
def test_incremental_all_five_methods_use_common_physical_owner_and_actual_evaluation(method, monkeypatch):
    e, t = scene(method=method)
    counts = dict(project=0, execute=0)
    project, execute = e.physics.project, e.physics.execute
    def observed_project(*args, **kwargs):
        counts['project'] += 1
        return project(*args, **kwargs)
    def observed_execute(*args, **kwargs):
        counts['execute'] += 1
        return execute(*args, **kwargs)
    monkeypatch.setattr(e.physics, 'project', observed_project)
    monkeypatch.setattr(e.physics, 'execute', observed_execute)
    e.run(20.)
    result = e.evaluate()
    assert counts['project'] and counts['execute']
    assert result['physics_owner'] == 'NetworkPhysics/C06_EventQueueKernelV3'
    assert set(result['costs']) == {'energy', 'downlink', 'terminal_backlog'}
    assert result['gross'] == sum(r['gross'] for r in e.ground_ledger)


def test_incremental_prop_trace_off_on_nonempty_execution_and_evaluation_parity(tmp_path):
    observed = []
    for trace in (False, True):
        e, t = scene()
        e.trace = trace
        e.run(20.)
        assert e.decisions and any(d['action'] != 'delay/store' for d in e.decisions)
        assert e.physics.flows and e.ground_ledger and e.evaluate()['gross'] > 0.
        destination = tmp_path / str(trace)
        e.save(destination)
        assert (destination / 'candidates.json').exists() == trace
        assert (destination / 'case_arrival_states.json').exists() == trace
        assert (destination / 'ground_ledger.json').exists()
        observed.append(fingerprint(dict(summary=e.evaluate(), ground=e.ground_ledger,
            decisions=e.decisions, candidates=e.candidates, state=e.physics.identity(),
            work=e.physics.work, flows=e.physics.flows, mode=e.controller.mode_updates,
            staged=e.staged_trace, feedback=vars(e.feedback))))
    assert observed[0] == observed[1]


def test_ablations_keep_fixed_prices_and_evaluator_but_only_remove_named_scarcity_piece():
    rows, evaluated = {}, []
    for variant in ('incremental', 'incremental_no_mode', 'incremental_no_dynamic'):
        e, t = scene(variant)
        e.controller.mode_name = 'energy_saving'
        row = e.candidate(t, action(e, 'roi'))
        rows[variant] = row
        e.physics.authorize(row['plan'])
        e.physics.execute(20.)
        e.observe_ground()
        result = e.evaluate()
        evaluated.append(dict(gross=result['gross'], costs=result['costs'], net=result['net'], ledger=result['ledger']))
    full, nomode, nodynamic = (rows[k] for k in ('incremental', 'incremental_no_mode', 'incremental_no_dynamic'))
    assert nomode['guidance']['m_E'] == nomode['guidance']['m_B'] == 1.
    assert nomode['guidance']['mu_E'] > 0. and nomode['guidance']['mu_B'] > 0.
    assert nodynamic['guidance']['mu_E'] == nodynamic['guidance']['mu_B'] == 0.
    assert nodynamic['score']['net_score'] == nodynamic['score']['fixed_net']
    assert full['score']['fixed_costs'] == nomode['score']['fixed_costs'] == nodynamic['score']['fixed_costs']
    assert full['score']['kappa_E'] == pytest.approx(2.981261194297225 / 3600.)
    assert full['score']['kappa_B'] == full['score']['kappa_Q'] == .09202386055743175
    assert fingerprint(evaluated[0]) == fingerprint(evaluated[1]) == fingerprint(evaluated[2])


def test_prefix_censoring_does_not_change_original_deadline_or_settle_terminal_fee():
    e, t = scene(links=[interval(0., 60., 0.)])
    authorize_mechanism(e, t, product='roi', size=1.)
    e.physics.execute(20.)
    e.observe_ground()
    result = e.evaluate()
    assert result['formal_settlement_s'] == 86400.
    assert not result['terminal_settled']
    assert result['task_status'][t.task_id] == 'right_censored_pending'
    assert e.physics.order[0].deadline_s == t.deadline_time_s == 60.
    assert result['costs']['terminal_backlog'] == 0.
    assert result['observation_backlog_snapshot_charge'] == pytest.approx(.09202386055743175)
    assert result['net'] == pytest.approx(-11. * 2.981261194297225 / 3600.)


def test_slow_mode_uses_future_calendar_and_distinct_arrivals_not_idle_slots():
    e, high = scene(links=[interval(0., 400., 0.), interval(400., 420.), interval(420., 1000., 0.)])
    high.value_level = 'high'
    high.deadline_s = high.deadline_time_s = 900.
    low = deepcopy(high)
    low.task_id += '_low'
    low.value_level = 'low'
    low.arrival_s = 20.
    e.arrived[low.task_id] = low
    e.pending[high.task_id] = 'retry_initial'
    e.controller.observe_slot(0, e.physics, high, arrived=e.arrived, pending=e.pending)
    assert e.controller.signals['next_contact_s'] == 400.
    assert e.controller.mode_name == 'egress_conservative'
    for slot in range(1, 11):
        e.physics.execute(slot * 20.)
        e.controller.observe_slot(slot, e.physics, low if slot == 1 else None,
                                  arrived=e.arrived, pending=e.pending)
    assert [r['time_s'] for r in e.controller.mode_updates] == [0., 200.]
    assert e.controller.signals['hv_denominator'] == 2
    assert e.controller.signals['hv_fraction'] == .5
    assert e.controller.signals['next_contact_s'] == 200.


@pytest.mark.parametrize('previous,soc,thermal,expected', [
    ('balanced', .70, .1, 'energy_saving'),
    ('balanced', .71, .1, 'balanced'),
    ('energy_saving', .73, .1, 'energy_saving'),
    ('energy_saving', .75, .1, 'balanced'),
    ('balanced', .9, .80, 'energy_saving'),
    ('energy_saving', .9, .71, 'energy_saving'),
    ('energy_saving', .9, .69, 'balanced'),
])
def test_energy_and_thermal_modes_act_before_hard_limits_with_hysteresis(previous, soc, thermal, expected):
    e, _ = scene()
    e.controller.mode_name = previous
    signals = dict(soc=soc, thermal=thermal, replenishment_soc_estimate=.8,
                   queue_congestion=0., known_work_count=0, next_contact_s=0.,
                   urgency=0., hv_fraction=0., hv_denominator=0)
    assert e.controller.select_mode(signals) == expected
