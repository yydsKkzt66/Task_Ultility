"""Independent review controls: synthetic scenarios, never historical replays."""
from copy import deepcopy

import pytest

from src.network_revision.physics import NetworkPhysics
from test_network_revision_runtime import experiment, interval, action, authorize_mechanism, b1_ready


def test_finite_ground_fifo_overflow_is_rejected_by_candidate_forecast():
    e,t=experiment('OFFLOAD')
    t.deadline_s=t.deadline_time_s=1000.
    e.config['horizon_s']=1000.
    e.physics=NetworkPhysics(e.config['physics']['network'],e.cfg['simulator'],[interval(0.,1000.)])
    # One job in service and 32 waiting; none finishes before new input arrives.
    for i in range(33):
        job=deepcopy(t);job.task_id=f'ground_occupied_{i:02d}'
        e.arrived[job.task_id]=job
        authorize_mechanism(e,job,product='roi_context',size=.001,route='GROUND',ground_s=20.,
            infer_s=0.,infer_j=0.,encoding_s=0.,encoding_j=0.)
    e.physics.execute(1.)
    before=e.physics.identity()
    candidate=e.candidate(t,action(e,'roi_context','high_accuracy'),route='GROUND')
    assert e.physics.identity()==before
    # Admission and execution must agree even though infinite-server completion
    # at 664.291 s would satisfy this synthetic 1000 s deadline.
    assert not candidate['feasible']
    assert candidate['ground_s'] is None
    # For the counterfactual mechanism control only, force the rejected plan.
    e.physics.authorize(candidate['plan'])
    e.physics.execute(17.)
    assert any(r['kind']=='GROUND_QUEUE_OVERFLOW' and r['task_id']==t.task_id for r in e.physics.events)
    assert not any(r['task_id']==t.task_id for r in e.physics.ground_pending+e.physics.ground_events)
    assert e.physics.ledger()['by_task'][t.task_id]['downlink_mb']==pytest.approx(4.)


def test_b1_forecast_skips_old_unfittable_payload_like_actual_scheduler():
    e,t=experiment('B1',links=[interval(0.,20.),interval(20.,60.,0.)])
    t.deadline_s=t.deadline_time_s=30.
    old=deepcopy(t);old.task_id='synthetic_unfittable_older';old.deadline_s=old.deadline_time_s=60.
    e.arrived[old.task_id]=old
    b1_ready(e,old,size=30.)
    before=e.physics.identity()
    candidate=e.candidate(t,action(e,'roi_context','high_accuracy'),route='B1')
    assert e.physics.identity()==before
    # The old 30 MB product cannot fit a 20 MB window. The frozen ranker skips
    # it; the new compressed 4 MB product is ready at 11 and finishes TX at 15.
    assert candidate['feasible']
    assert candidate['ground_s']==pytest.approx(19.29)
    e.physics.authorize(candidate['plan'])
    e.advance_slot_events(20.,0)
    actual=next(r for r in e.ground_ledger if r['task_id']==t.task_id)
    assert actual['ground_available_s']==pytest.approx(candidate['ground_s'])
    assert any(r['task_id']==old.task_id and r['reason']=='no_full_fit_current_contact' for r in e.b1_trace)
    assert not any(f['task_id']==old.task_id for f in e.physics.flows)


def test_myopic_defer_consumes_existing_queue_in_same_physical_baseline(monkeypatch):
    e,t=experiment('MYOPIC')
    queued=deepcopy(t);queued.task_id='synthetic_ready_backlog';e.arrived[queued.task_id]=queued
    authorize_mechanism(e,queued,product='roi',size=2.,infer_s=0.,infer_j=0.,encoding_s=0.,encoding_j=0.)
    baseline=e.physics.project(end_s=20.)
    remaining=sum(baseline['remaining'].values())/8e6
    assert remaining==0.  # A nontrivial draining queue, not an empty baseline.
    captured=[]
    original=e.myopic_reward
    def reward(task,pred,product):
        if product=='defer':captured.append(deepcopy(vars(pred)))
        return original(task,pred,product)
    monkeypatch.setattr(e,'myopic_reward',reward)
    e.decide(t)
    assert len(captured)==1
    assert captured[0]['predicted_Q_next_mb']==pytest.approx(remaining)
    assert captured[0]['predicted_detection_quality']==0.
@pytest.mark.parametrize('booked',[False,True])
def test_zero_service_probe_boundary_canonicalization_matches_frozen_reference(booked):
    import importlib.util,sys
    from test_network_revision_physics import owner,link,submit
    from pathlib import Path
    path=Path(__file__).resolve().parents[1]/'network_inputs/pre_margin_physics_reference.py'
    spec=importlib.util.spec_from_file_location('pre_margin_reference',path)
    ref=importlib.util.module_from_spec(spec);sys.modules[spec.name]=ref;spec.loader.exec_module(ref)
    p=owner([link(0.,40.,0.),link(40.,65.),link(65.,80.,0.)])
    if booked:submit(p,'prior',size_mb=2.,inference_s=0.,inference_j=0.,encoding_s=0.,encoding_j=0.)
    baseline=p.project(end_s=65.);before=p.identity()
    old=ref.NetworkPhysics.executable_margin(p,3.,65.,baseline)
    new=p.executable_margin(3.,65.,baseline)
    for key in ['offered_bits','committed_bits','remaining_bits','safe_available_bits']:
        assert new[key]==pytest.approx(old[key],abs=1.,rel=0.)
    hits=p.kernel.projection_cache_hits
    again=p.executable_margin(17.,65.,baseline)
    assert again==new
    assert p.kernel.projection_cache_hits>hits
    assert p.identity()==before
