from copy import deepcopy
from dataclasses import asdict
from pathlib import Path
import pickle
import pytest
from src.network_revision.runtime import NetworkExperiment
from src.network_revision.physics import NetworkPhysics
from src.link.event_queue_runtime_v3 import EventLinkIntervalV3

ROOT=Path(__file__).resolve().parents[1]
def make(method='PROP',trace=True):
    e=NetworkExperiment(ROOT,'incremental_dev1600',method,trace=trace)
    e.fast_nonpositive_bound=True
    times=[1.,1.,1.1,19.999,20.,39.999,40.,79.999]
    tasks=[]
    for i,time in enumerate(times):
        t=deepcopy(e.tasks[0]);t.task_id=f'test_{i}';t.arrival_s=time;t.arrival_slot=int(time//20)
        t.deadline_s=80.;t.deadline_time_s=time+80.;t.task_value=10.;t.calibrated_task_value=10.
        t.value_level='high';t.product_requirement='alert';t.information_requirement=.1;t.quality_requirement=.1
        tasks.append(t)
    e.tasks=tasks
    links=[EventLinkIntervalV3(i*20.,(i+1)*20.,8e6 if i in {1,3,5,7} else 0.,10. if i in {1,3,5,7} else 0.,0.,20.,
        f'w{i}' if i in {1,3,5,7} else '',160e6 if i in {1,3,5,7} else 0.) for i in range(10)]
    e.physics=NetworkPhysics(e.config['physics']['network'],e.cfg['simulator'],links)
    return e

@pytest.mark.parametrize('method',['PROP','OFFLOAD'])
def test_real_multiarrival_cpu_ready_and_boundaries(method):
    e=make(method)
    original=e.decide;seen=[]
    def checked(task,**kw):
        assert all(t.arrival_s<=e.physics.now for t in e.arrived.values())
        if not kw.get('continuation') and task.task_id not in {x[0] for x in seen}:
            assert e.physics.now==task.arrival_s
            seen.append((task.task_id,e.physics.now))
        return original(task,**kw)
    e.decide=checked;e.run(100.)
    assert len(e.arrived)==8 and len(e.arrival_events)==8 and len(seen)==8
    assert [r['time_s'] for r in e.arrival_events]==sorted(t.arrival_s for t in e.tasks)
    work=sorted(e.physics.work,key=lambda w:w.start_s)
    assert len(work)>2
    assert all(a.end_s<=b.start_s+1e-9 for a,b in zip(work,work[1:]))
    assert any(e.physics.products[k]['inference_start_s']>e.arrived[v['task_id']].arrival_s
        for k,v in e.physics.products.items())
    assert len(e.physics.flows)>0
    for f in e.physics.flows:
        info=e.physics.products[f['product_id']]
        assert f['start_s']>=info['ready_s']-1e-9
        assert e.physics.kernel.link_at(f['start_s']).business_rate_bit_s>0
        assert f['end_s']<=e.physics.kernel.link_at(f['start_s']).end_s+1e-9
    for pid,info in e.physics.products.items():
        sent=sum(f['progress_bits'] for f in e.physics.flows if f['product_id']==pid)
        remaining=sum(x.remaining_bits for x in e.physics.order if x.product_id==pid)
        expired=sum(x['remaining_bits'] for x in e.physics.expired if x['product_id']==pid)
        assert info['original_bits']==sent+remaining+expired
    assert e.physics.ledger()['background_j']==pytest.approx(886.)
    assert [x['time_s'] for x in e.controller.mode_updates]==[0.]
    if method=='PROP':
        assert len(e.controller.recent)==8
        assert e.controller.mode_updates[0]['signals']['hv_denominator']==0

def projection(e):
    return dict(decisions=e.decisions,ground=e.ground_ledger,identity=e.physics.identity(),
        modes=e.controller.mode_updates,arrivals=e.arrival_events)

def test_trace_and_completed_slot_resume_parity():
    a=make();a.run(100.)
    b=make(trace=False);b.run(40.);b=pickle.loads(pickle.dumps(b));b.run(100.)
    assert projection(a)==projection(b)

def test_manifest_identity_relative_ddl_and_freeze():
    import csv,json,hashlib
    base={r['task_id']:r for r in csv.DictReader((ROOT/'network_inputs/task_manifest.csv').open(encoding='utf-8-sig'))}
    rows=list(csv.DictReader((ROOT/'network_inputs/task_manifest_dev1600.csv').open(encoding='utf-8')))
    from collections import Counter
    assert Counter(r['value_level'] for r in rows)==dict(low=322,medium=830,high=323,urgent=125)
    assert len(set(r['task_id'] for r in rows))==1600
    for r in rows:
        t=base[r['template_task_id']]
        assert 0<=float(r['arrival_time_s'])<21600
        assert float(r['deadline_time_s'])-float(r['arrival_time_s'])==pytest.approx(float(t['deadline_s']))
        for key in ['effective_task_value','product_requirement','metadata_json','quality_requirement','information_requirement']:
            assert r[key]==t[key]
    old=json.loads((ROOT/'configs/network_revision/incremental.json').read_text())
    new=json.loads((ROOT/'configs/network_revision/incremental_dev1600.json').read_text())
    for key in old:
        if key!='input_hashes':assert new[key]==old[key]
    for key in old['input_hashes']:assert new['input_hashes'][key]==old['input_hashes'][key]
    assert hashlib.sha256((ROOT/'network_inputs/task_manifest_dev1600.csv').read_bytes()).hexdigest()==new['input_hashes']['task_manifest_dev1600.csv']
