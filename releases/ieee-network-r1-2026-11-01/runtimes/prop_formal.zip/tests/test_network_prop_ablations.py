"""Author-defined one-switch ablations; synthetic mechanism gates, not results."""
from copy import deepcopy
from pathlib import Path
import importlib.util,json,pickle,sys
import pytest
from src.network_revision.runtime import NetworkExperiment
from src.network_revision.physics import NetworkPhysics
from test_network_incremental import scene
from test_network_revision_runtime import action,authorize_mechanism,interval

WORK=Path(__file__).resolve().parents[1]
BASE=WORK.parent/'.network_dev1600_work'
PREFIX='incremental_dev1600_'


@pytest.mark.parametrize('arm,path,value',[
    ('no_dynamic',('incremental_pricing','use_dynamic'),False),
    ('no_mode',('incremental_pricing','use_mode'),False),
    ('fixed_b',('ablation','allowed_models'),['balanced']),
    ('no_prog',('ablation','allow_progressive'),False)])
def test_configs_differ_only_in_named_switch(arm,path,value):
    base=json.loads((WORK/'configs/network_revision/incremental_dev1600.json').read_text())
    cfg=json.loads((WORK/'configs/network_revision'/(PREFIX+arm+'.json')).read_text())
    expected=deepcopy(base);expected.setdefault(path[0],{})[path[1]]=value
    assert cfg==expected
    e=NetworkExperiment(WORK,PREFIX+arm,'PROP');full=NetworkExperiment(WORK,'incremental_dev1600','PROP')
    assert len(e.tasks)==1600 and e.tasks==full.tasks
    assert e.physics.identity()==full.physics.identity() and e.physics.kernel.links==full.physics.kernel.links


def test_no_dynamic_fixed_cost_safety_and_mode_nesting():
    full,t=scene('incremental_dev1600');off,u=scene(PREFIX+'no_dynamic')
    full.controller.mode_name=off.controller.mode_name='energy_saving'
    a=full.candidate(t,action(full,'roi_context'));b=off.candidate(u,action(off,'roi_context'))
    assert b['guidance']['mu_E']==b['guidance']['mu_B']==0.
    assert b['score']['effective_price_E']==off.config['public_prices']['energy_price_per_Wh']/3600
    assert b['score']['effective_price_B']==off.config['public_prices']['downlink_price_per_MB']
    assert a['score']['fixed_costs']==b['score']['fixed_costs'] and b['score']['fixed_costs']['energy']>0
    assert a['feasible']==b['feasible'] and a['projection']==b['projection']
    off.controller.settings['use_mode']=False
    c=off.candidate(u,action(off,'roi_context'))
    assert c['guidance']['m_E']==c['guidance']['m_B']==1.
    assert b['score']==c['score']  # Mode has no price contribution when dynamic pricing is off.


def test_no_mode_retains_dynamic_pressure_and_safety():
    full,t=scene('incremental_dev1600');off,u=scene(PREFIX+'no_mode')
    full.controller.mode_name=off.controller.mode_name='energy_saving'
    a=full.candidate(t,action(full,'roi_context'));b=off.candidate(u,action(off,'roi_context'))
    assert b['guidance']['m_E']==b['guidance']['m_B']==1.
    assert b['guidance']['mu_E']>0 and b['score']['effective_price_E']>b['score']['kappa_E']
    assert a['guidance']['pressure']==b['guidance']['pressure']
    assert a['score']['fixed_costs']==b['score']['fixed_costs'] and a['projection']==b['projection']


def test_dynamic_off_fast_nonpositive_logs_exact_zero_not_missing_price():
    e,t=scene(PREFIX+'no_dynamic');t.task_value=t.calibrated_task_value=1e-5;e.fast_nonpositive_bound=True
    c=e.candidate(t,action(e,'roi_context'))
    assert c['score']['net_score_evaluation']=='EXACT_FIXED_PRICE_SCORE_NO_DYNAMIC'
    assert c['guidance']['pressure']['window'] is None
    assert c['guidance']['mu_B']==0. and c['guidance']['mu_E']==0.
    assert c['score']['net_score']==c['score']['fixed_net']<0
    assert c['score']['effective_price_B']==c['score']['kappa_B']


def test_fixed_balanced_products_and_progressive_preserved():
    e,t=scene(PREFIX+'fixed_b')
    assert {a.model_name for a in e.actions}=={'balanced'}
    assert {a.payload_policy for a in e.actions}=={'metadata','roi','roi_context'}
    assert e.allow_progressive and e.controller.settings['use_mode'] and e.controller.settings['use_dynamic']
    t.task_value=t.calibrated_task_value=100.
    meta=e.candidate(t,action(e,'metadata','balanced'));e.physics.authorize(meta['plan'])
    e.physics.execute(3.);e.observe_ground()
    assert e.pending[t.task_id]=='closing'
    selected=e.decide(t,continuation=True)
    assert selected and selected['model']=='balanced' and selected['cached_inference']
    assert selected['score']['inference_new_j']==0
    assert all(c['model']=='balanced' for c in e.candidates)


def test_no_prog_suppresses_only_post_delivery_information():
    full,t=scene('incremental_dev1600');off,u=scene(PREFIX+'no_prog')
    for e,task in [(full,t),(off,u)]:
        authorize_mechanism(e,task,'metadata');e.physics.execute(3.);e.observe_ground()
    assert full.ground_ledger==off.ground_ledger and full.physics.identity()==off.physics.identity()
    assert full.pending[t.task_id]=='closing' and t.task_id in full.staged_requests
    assert u.task_id not in off.pending and not off.staged_requests
    off.process_closing(0);off.process_closing(0,same_slot=True)
    assert not off.decisions and len(off.physics.products)==1
    with pytest.raises(ValueError,match='INFORMATION_FOLLOWUP_DISABLED'):off.decide(u,continuation=True)


def test_no_prog_metadata_can_close_alert_requirement():
    e,t=scene(PREFIX+'no_prog');t.product_requirement='alert';t.value_level='high'
    selected=e.decide(t);assert selected and selected['product']=='metadata'
    e.advance_slot_events(10.,0)
    assert t.task_id in e.closed and e.ground_ledger[-1]['closes']


def test_no_prog_initial_deferral_and_retry_kept():
    e,t=scene(PREFIX+'no_prog');t.value_level='high';t.task_value=t.calibrated_task_value=1e-6
    e.physics=NetworkPhysics(e.config['physics']['network'],e.cfg['simulator'],[interval(0.,20.,0.),interval(20.,60.)])
    e.run(20.);assert e.pending[t.task_id]=='retry_initial'
    e.run(40.)
    assert [d['time_s'] for d in e.decisions]==[0.,20.]
    assert all(not d['continuation'] for d in e.decisions)


def test_no_prog_existing_payload_partial_service_cross_window_kept():
    e,t=scene(PREFIX+'no_prog')
    e.physics=NetworkPhysics(e.config['physics']['network'],e.cfg['simulator'],[
        interval(0.,2.,8e6,'first'),interval(2.,20.,0.),interval(20.,60.,8e6,'second')])
    plan=authorize_mechanism(e,t,'roi',size=3.,infer_s=0.,infer_j=0.,encoding_s=0.,encoding_j=0.)
    e.advance_slot_events(20.,0)
    assert e.physics.order and 0<e.physics.order[0].remaining_bits<plan['item'].remaining_bits
    saved=pickle.loads(pickle.dumps(e));e.advance_slot_events(40.,1);saved.advance_slot_events(40.,1)
    assert e.physics.identity()==saved.physics.identity()
    assert len(e.physics.products)==1 and not e.pending and not e.staged_requests
    assert sum(f['progress_bits'] for f in e.physics.flows)==24_000_000
    assert {e.physics.kernel.link_at(f['start_s']).window_id for f in e.physics.flows}=={'first','second'}


def test_unmodified_full_prop_short_real_prefix_exact_parity():
    spec=importlib.util.spec_from_file_location('frozen_prop_runtime_ablation_gate',BASE/'src/network_revision/runtime.py')
    old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
    a=old.NetworkExperiment(BASE,'incremental_dev1600','PROP',trace=False)
    b=NetworkExperiment(WORK,'incremental_dev1600','PROP',trace=False)
    a.fast_nonpositive_bound=b.fast_nonpositive_bound=True
    a.run(60.);b.run(60.)
    assert a.physics.identity()==b.physics.identity()
    for name in ['decisions','candidates','ground_ledger','arrival_events','pending','staged_requests','staged_trace']:
        assert getattr(a,name)==getattr(b,name),name
    assert a.controller.mode_updates==b.controller.mode_updates
