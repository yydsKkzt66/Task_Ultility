"""Synthetic short mechanism scenes for the Network policy/physics bridge.

Tasks copy the frozen manifest schema but use explicitly synthetic IDs, arrival
times and deadlines. These tests are not seed-2026 historical task replays.
No real prefix or complete flow is run here.
"""
from copy import deepcopy
from dataclasses import asdict, is_dataclass
from enum import Enum
from pathlib import Path
import random

import numpy as np
import pytest

from src.link.event_queue_runtime_v3 import EventLinkIntervalV3
from src.network_revision.physics import NetworkPhysics, fingerprint
from src.network_revision.runtime import NetworkExperiment


ROOT = Path(__file__).resolve().parents[1]


def interval(a,b,rate=8e6,window='mechanism'):
    return EventLinkIntervalV3(a,b,rate,10. if rate else 0.,0.,20.,window if rate else '',(b-a)*rate)


def experiment(method='PROP', requirement='verification', links=None):
    e = NetworkExperiment(ROOT,'pressure_fixed',method)
    task = deepcopy(e.tasks[0])
    task.task_id = 'synthetic_runtime_a'
    task.arrival_slot = 0
    task.arrival_s = 0.
    task.deadline_s = 60.
    task.deadline_time_s = 60.
    task.product_requirement = requirement
    task.quality_requirement = .1
    task.information_requirement = .1
    task.value_level = 'low'
    task.high_value_flag = task.emergency_flag = 0
    task.metadata['raw_payload_mb'] = 32.
    e.tasks = [task]
    e.arrived = {task.task_id:task}
    e.config['horizon_s'] = 60.
    e.physics = NetworkPhysics(e.config['physics']['network'],e.cfg['simulator'],links or [interval(0.,60.)])
    return e,task


def action(e,product='metadata',model='lightweight'):
    return next(a for a in e.actions if a.payload_policy==product and a.model_name==model)


def authorize_mechanism(e,task,product='metadata',size=.002,route='DIRECT',ground_s=0.,
                        infer_s=1.,infer_j=10.,encoding_s=.1,encoding_j=1.):
    plan=e.physics.plan(task_id=task.task_id,model='lightweight',product=product,size_mb=size,
        inference_s=infer_s,inference_j=infer_j,encoding_s=encoding_s,encoding_j=encoding_j,
        deadline_s=task.deadline_time_s,q=.6,route=route,ground_s=ground_s)
    plan['detection_quality']=.6
    e.physics.authorize(plan)
    return plan


def full_decision_state(e):
    """Include all policy-owned mutable state, not just the physical owner.

    Exact physical predictor memo caches/counters are deliberately excluded;
    they may change without committing execution or policy truth.
    """
    names=('arrived','decisions','candidates','delivered','ground_ledger','closed','pending',
           'retry_windows','staged_count_slot','staged_count_window','same_state','case_states',
           'staged_requests','staged_trace','proactive_slot_count','proactive_window_count','guarantee_debt')
    values={name:deepcopy(getattr(e,name)) for name in names}
    values.update(physical_identity=e.physics.identity(),controller=deepcopy(vars(e.controller)),
                  registry=deepcopy(vars(e.registry)),queue_policy=deepcopy(vars(e.queue_policy)),
                  actions=deepcopy([vars(a) for a in e.actions]),qmap=deepcopy(e.qmap),
                  config=deepcopy(e.config),legacy_config=deepcopy(e.cfg),tasks=deepcopy(e.tasks),
                  random=random.getstate(),numpy_random=np.random.get_state())
    def canonical(value):
        if value is None or isinstance(value,(str,int,float,bool)):
            return value
        if isinstance(value,np.ndarray):
            return dict(dtype=str(value.dtype),shape=value.shape,values=value.tolist())
        if isinstance(value,Enum):
            return dict(enum=type(value).__qualname__,value=value.value)
        if isinstance(value,Path):
            return str(value)
        if isinstance(value,dict):
            return {str(k):canonical(v) for k,v in value.items()}
        if isinstance(value,(list,tuple)):
            return [canonical(x) for x in value]
        if isinstance(value,set):
            return sorted((canonical(x) for x in value),key=repr)
        if is_dataclass(value):
            return canonical(asdict(value))
        if hasattr(value,'__dict__'):
            return dict(type=type(value).__qualname__,fields=canonical(vars(value)))
        raise TypeError('UNREGISTERED_TEST_SNAPSHOT_TYPE:'+str(type(value)))
    return fingerprint(canonical(values))


@pytest.mark.parametrize('requirement,delta,closes', [('alert',.8,True),('verification',.35,False),('evidence',.15,False)])
def test_ordinary_metadata_has_partial_or_complete_requirement_credit(requirement,delta,closes):
    e,t = experiment(requirement=requirement)
    authorize_mechanism(e,t)
    e.physics.execute(3.)
    e.observe_ground()
    row=e.ground_ledger[0]
    assert row['delta_information']==pytest.approx(delta)
    assert row['gross']==pytest.approx(t.task_value*.6*delta*(1-row['ground_available_s']/60.))
    assert (t.task_id in e.closed)==closes
    assert row['closes']==closes
    if not closes:
        assert e.pending[t.task_id]=='closing'
        assert t.task_id in e.staged_requests  # Ordinary continuation retained.


def test_ground_gross_is_incremental_and_observation_is_idempotent():
    e,t = experiment(requirement='evidence')
    for product,size in [('metadata',.002),('roi',.1),('roi_context',.2)]:
        authorize_mechanism(e,t,product,size)
        e.physics.execute(e.physics.now+3.)
        e.observe_ground()
        before=deepcopy(e.ground_ledger)
        e.observe_ground()
        assert e.ground_ledger==before
    assert [r['delta_information'] for r in e.ground_ledger]==pytest.approx([.15,.5,.3])
    expected=sum(t.task_value*.6*d*(1-r['ground_available_s']/60.)
                 for d,r in zip((.15,.5,.3),e.ground_ledger))
    assert e.evaluate()['gross']==pytest.approx(expected)
    assert len(e.closed)==1
    # Even an explicitly repeated receipt cannot claim incremental utility twice.
    e.physics.ground_events.append(deepcopy(e.physics.ground_events[-1]))
    e.observe_ground()
    assert e.ground_ledger[-1]['delta_information']==0.
    assert e.evaluate()['gross']==pytest.approx(expected)


def test_missing_quality_fails_closed_at_ground_evaluation():
    e,t=experiment()
    authorize_mechanism(e,t)
    e.physics.execute(3.)
    e.physics.ground_events[0]['q']=None
    with pytest.raises(ValueError,match='MISSING_QUALITY_PROVENANCE'):
        e.observe_ground()
    assert not e.ground_ledger and not e.closed


def test_no_delivery_keeps_paid_compute_and_terminal_backlog_cost():
    e,t=experiment(links=[interval(0.,60.,0.)])
    authorize_mechanism(e,t,product='roi',size=1.)
    e.physics.execute(5.)
    e.observe_ground()
    out=e.evaluate()
    assert out['gross']==0. and out['ground_events']==0
    assert out['ledger']['controlled_j']==pytest.approx(11.)
    assert out['costs']['energy']==pytest.approx(11./3600.*e.config['public_prices']['energy_price_per_Wh'])
    assert out['costs']['terminal_backlog']==pytest.approx(e.config['public_prices']['terminal_backlog_price_per_MB'])
    assert out['net']==pytest.approx(-sum(out['costs'].values()))
    # An expired product still carries its paid work, with no terminal backlog.
    e.physics.execute(60.)
    expired=e.evaluate()
    assert expired['ledger']['controlled_j']==pytest.approx(11.)
    assert expired['costs']['terminal_backlog']==0.
    assert expired['ledger']['expired_mb']==pytest.approx(1.)
    assert expired['net']<0.


def test_candidate_full_policy_state_and_rng_are_isolated_in_both_orders():
    e,t=experiment(requirement='evidence')
    # Exercise a populated ordinary staged request rather than only empty state.
    authorize_mechanism(e,t)
    e.physics.execute(3.)
    e.observe_ground()
    e.controller.observe_slot(0,e.physics,t)
    before=full_decision_state(e)
    actions=[action(e,'roi'),action(e,'roi_context')]
    forward=[e.public_candidate(e.candidate(t,a,continuation=True)) for a in actions]
    assert full_decision_state(e)==before
    reverse=[e.public_candidate(e.candidate(t,a,continuation=True)) for a in reversed(actions)][::-1]
    assert fingerprint(forward)==fingerprint(reverse)
    assert full_decision_state(e)==before


@pytest.mark.parametrize('method',['PROP','MYOPIC','TUT','OFFLOAD','B1'])
def test_all_five_methods_reach_the_shared_physics_and_evaluator(method,monkeypatch):
    e,t=experiment(method)
    assert isinstance(e.physics,NetworkPhysics)
    counts={'project':0,'execute':0}
    original_project=e.physics.project
    original_execute=e.physics.execute
    def project(*args,**kwargs):
        counts['project']+=1
        return original_project(*args,**kwargs)
    def execute(*args,**kwargs):
        counts['execute']+=1
        return original_execute(*args,**kwargs)
    monkeypatch.setattr(e.physics,'project',project)
    monkeypatch.setattr(e.physics,'execute',execute)
    e.run(20.)
    assert counts['project']>0 and counts['execute']>0
    assert e.evaluate()['physics_owner']=='NetworkPhysics/C06_EventQueueKernelV3'
    assert e.candidates and e.evaluate()['method']==method
    assert set(e.evaluate()['costs'])=={'energy','downlink','terminal_backlog'}


def test_offload_local_and_ground_payloads_and_processing_are_distinct():
    e,t=experiment('OFFLOAD')
    local=e.candidate(t,action(e,'roi','high_accuracy'),route='LOCAL')
    ground=e.candidate(t,action(e,'roi_context','high_accuracy'),route='GROUND')
    assert local['feasible'] and ground['feasible']
    assert local['size_mb']==pytest.approx(.85)
    assert ground['size_mb']==pytest.approx(4.)
    assert ground['product']=='roi_context'  # Final output, not uploaded bytes.
    assert local['plan']['ground_s']==0.
    assert ground['plan']['ground_s']==pytest.approx(4.29)
    assert ground['plan']['inference_j']==0.
    assert not any(w.kind=='inference' for w in ground['plan']['work'])
    assert ground['plan']['ready_s']==pytest.approx(11.)
    assert ground['ground_s']==pytest.approx(19.29)
    assert local['ground_s']==pytest.approx(2.79+.153+.85)
    assert e.decide(t)['route']=='LOCAL'
    # A stricter real requirement can legitimately select the other path.
    g,u=experiment('OFFLOAD')
    u.information_requirement=1.
    selected=g.decide(u)
    assert selected['route']=='GROUND'
    g.advance_slot_events(20.,0)
    row=g.ground_ledger[0]
    assert row['product']=='roi_context'
    assert row['ground_available_s']==pytest.approx(19.29)
    assert g.physics.ledger()['downlink_mb']==pytest.approx(4.)


def b1_ready(e,t,size=1.):
    return authorize_mechanism(e,t,product='roi_context',size=size,route='B1',
                              ground_s=4.29,infer_s=0.,infer_j=0.,encoding_s=0.,encoding_j=0.)


def test_b1_original_rank_is_called_and_changes_fifo_order(monkeypatch):
    e,low=experiment('B1')
    high=deepcopy(low);high.task_id='synthetic_runtime_high';high.task_value=low.task_value*3
    e.arrived[high.task_id]=high
    b1_ready(e,low)
    b1_ready(e,high)
    called=[]
    original=e.b1.rank
    def rank(*args,**kwargs):
        called.append(True)
        return original(*args,**kwargs)
    monkeypatch.setattr(e.b1,'rank',rank)
    order=e.b1_service_order(1.)
    assert called and len(e.b1_trace)==2
    eligible=[x for x in order if x.ready_time_s<=e.physics.now]
    assert [x.task_id for x in eligible]==[high.task_id]
    e.physics.execute(1.,service_order=order)
    assert {f['task_id'] for f in e.physics.flows}=={high.task_id}


def test_b1_full_fit_rule_blocks_partial_current_window_and_resumes_later():
    links=[interval(0.,.5,8e6,'small'),interval(.5,10.,0.),interval(10.,12.,8e6,'large'),interval(12.,60.,0.)]
    e,t=experiment('B1',links=links)
    b1_ready(e,t,size=1.)
    order=e.b1_service_order(.5)
    assert any(x['reason']=='no_full_fit_current_contact' for x in e.b1_trace)
    e.physics.execute(.5,service_order=order)
    assert not e.physics.flows and e.physics.order[0].remaining_bits==8e6
    e.physics.execute(10.)
    e.physics.execute(11.,service_order=e.b1_service_order(11.))
    assert e.physics.ledger()['downlink_mb']==pytest.approx(1.)
    assert e.physics.flows[0]['start_s']==pytest.approx(10.)


def test_tut_ground_forecast_and_execution_do_not_use_fifo_ground_server():
    e,t=experiment('TUT')
    other=deepcopy(t);other.task_id='synthetic_runtime_tut_second';e.arrived[other.task_id]=other
    first=authorize_mechanism(e,t,product='roi',size=.25,route='TUT',ground_s=1.87,
                              infer_s=0.,infer_j=0.,encoding_s=0.,encoding_j=0.)
    second=e.physics.plan(task_id=other.task_id,model='lightweight',product='roi',size_mb=.25,
        inference_s=0.,inference_j=0.,encoding_s=0.,encoding_j=0.,deadline_s=60.,q=.6,route='TUT',ground_s=1.87)
    projection=e.physics.project(order=e.physics.order+[second['item']],end_s=3.)
    expected=.5+1.87
    assert e.ground_forecast(projection,second['item'].product_id,second)==pytest.approx(expected)
    e.physics.authorize(second)
    e.physics.execute(3.)
    assert [r['ground_available_s'] for r in e.physics.ground_events]==pytest.approx([.25+1.87,expected])
    assert e.physics.ground_free==0.


def test_identical_seed_and_short_synthetic_input_are_deterministic():
    results=[]
    for _ in range(2):
        random.seed(2026);np.random.seed(2026)
        e,t=experiment('OFFLOAD')
        e.run(20.)
        assert e.ground_ledger  # A nonempty physical path, not two empty outputs.
        results.append(fingerprint(dict(summary=e.evaluate(),decisions=e.decisions,candidates=e.candidates,
                                       flows=e.physics.flows,ground=e.ground_ledger,mode=e.controller.mode_updates)))
    assert results[0]==results[1]


def test_trace_export_switch_suppresses_diagnostics_without_changing_actual_results(tmp_path):
    observations=[]
    for trace in (False,True):
        e,t=experiment('OFFLOAD');e.trace=trace
        e.run(20.)
        out=tmp_path/str(trace);e.save(out)
        assert (out/'candidates.json').exists()==trace
        assert (out/'case_arrival_states.json').exists()==trace
        assert (out/'ground_ledger.json').exists()
        observations.append(fingerprint(dict(summary=e.evaluate(),ground=e.ground_ledger,
            decisions=e.decisions,flows=e.physics.flows,work=e.physics.work)))
    assert observations[0]==observations[1]
