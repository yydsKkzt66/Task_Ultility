"""Synthetic mechanism checks, not replays of the seed-2026 task stream.

Configuration is frozen input; short artificial contacts expose causal edges.
No task/value/profile calibration is performed by these tests.
"""
from copy import deepcopy
from dataclasses import asdict, replace
import json
from pathlib import Path
import random
from types import SimpleNamespace

import numpy as np
import pytest

from src.energy.celsius_thermal_network_v1 import ThermalPowerV1
from src.link.event_queue_runtime_v3 import EventLinkIntervalV3
from src.network_revision.physics import NetworkPhysics, fingerprint
from src.network_revision.policy import NetworkController, energy_pressure, thermal_pressure


ROOT = Path(__file__).resolve().parents[1]
CFG = json.loads((ROOT / 'network_inputs/legacy_config.json').read_bytes())
R06 = json.loads((ROOT / 'network_inputs/r06_config_runtime_base.json').read_bytes())


def link(start, end, rate=8e6, window='mechanism', solar=0.):
    return EventLinkIntervalV3(start, end, rate, 10. if rate else 0., solar, 20.,
                               window if rate else '', (end-start)*rate)


def owner(links=None):
    return NetworkPhysics(R06['network'], CFG['simulator'], links or [link(0., 300.)])


def plan(p, task='synthetic_a', **changes):
    values = dict(task_id=task, model='lightweight', product='roi', size_mb=1.,
                  inference_s=2., inference_j=20., encoding_s=1., encoding_j=6.,
                  deadline_s=200., q=.5697178218395861)
    values.update(changes)
    return p.plan(**values)


def submit(p, task='synthetic_a', **changes):
    candidate = plan(p, task, **changes)
    p.authorize(candidate)
    return candidate


def state_summary(p):
    return dict(state=asdict(p.state), soc=p.soc, order=[asdict(x) for x in p.order],
                work=[asdict(x) for x in p.work], flows=p.flows, ground=p.ground_events,
                pending=p.ground_pending, completed=p.completed, ledger=p.ledger())


def test_candidate_projection_order_and_cache_are_isolated():
    p = owner()
    before = p.identity()
    random_before = random.getstate()
    numpy_before = np.random.get_state()
    candidates = [plan(p, 'a', size_mb=.5), plan(p, 'b', inference_s=5., inference_j=50.)]
    def quote(candidate):
        return p.project(order=[candidate['item']], work=candidate['work'], end_s=15.)
    forward = [quote(c) for c in candidates]
    reverse = [quote(c) for c in reversed(candidates)][::-1]
    assert [fingerprint(x) for x in forward] == [fingerprint(x) for x in reverse]
    assert p.identity() == before
    assert random.getstate() == random_before
    numpy_after = np.random.get_state()
    assert numpy_before[0] == numpy_after[0]
    np.testing.assert_array_equal(numpy_before[1], numpy_after[1])
    assert numpy_before[2:] == numpy_after[2:]
    # Returned cache certificates must not alias the next quotation.
    forward[0]['trajectory'][0]['thermal']['peaks_c']['chip'] = -999.
    assert quote(candidates[0])['trajectory'][0]['thermal']['peaks_c']['chip'] > 0.
    assert p.identity() == before


def test_forecast_temperature_is_not_next_execution_start():
    p = owner()
    candidate = plan(p)
    projected = p.project(order=[candidate['item']], work=candidate['work'], end_s=20.)
    original = p.state
    assert projected['state'] != original
    p.authorize(candidate)
    p.execute(20.)
    assert p.trajectory[0]['thermal']['before'] == original.to_dict()
    assert p.state == projected['state']


def test_inference_cache_reused_for_followup_with_incremental_charge():
    p = owner()
    first = submit(p, product='metadata', size_mb=.002)
    p.execute(5.)
    follow = plan(p, product='roi_context', size_mb=2., encoding_s=2., encoding_j=12.)
    assert follow['cached'] and follow['inference_j'] == 0.
    assert all(w.kind == 'encoding' for w in follow['work'])
    p.authorize(follow)
    p.execute(12.)
    bill = p.ledger()['by_task']['synthetic_a']
    assert bill['inference_j'] == pytest.approx(20.)
    assert bill['encoding_j'] == pytest.approx(18.)
    assert bill['downlink_mb'] == pytest.approx(2.002)
    assert len([w for w in p.work if w.kind == 'inference']) == 1


def test_inflight_cache_never_materializes_followup_before_inference():
    p = owner()
    first = submit(p, product='metadata', inference_s=25., inference_j=50.)
    follow = plan(p, product='roi_context')
    assert follow['cached']
    assert follow['encoding_start_s'] >= first['ready_s']
    assert not any(w.kind == 'inference' for w in follow['work'])
    p.authorize(follow)
    p.execute(20.)
    assert not p.flows and not p.ground_events


def test_cross_macro_work_is_carried_and_charged_once():
    p = owner()
    submit(p, inference_s=25., inference_j=50., encoding_s=2., encoding_j=10.)
    p.execute(20.)
    assert p.ledger()['by_task']['synthetic_a']['inference_j'] == pytest.approx(40.)
    assert not p.flows
    p.execute(30.)
    bill = p.ledger()['by_task']['synthetic_a']
    assert bill['inference_j'] == pytest.approx(50.)
    assert bill['encoding_j'] == pytest.approx(10.)
    assert p.flows[0]['start_s'] == pytest.approx(27.)
    assert p.ground_events[0]['tx_end_s'] == pytest.approx(28.)


def test_committed_future_product_is_not_materialized_terminal_backlog():
    p=owner()
    submit(p,inference_s=25.,inference_j=50.,encoding_s=2.,encoding_j=10.)
    p.execute(20.)
    assert p.ledger()['controlled_j']==pytest.approx(40.)
    assert p.ledger()['backlog_mb']==0.
    assert p.ledger()['unmaterialized_committed_mb']==pytest.approx(1.)
    assert not p.flows and not p.ground_events


def test_midwindow_ready_and_non_grid_contact_capacity():
    links = [link(0., 2.5, 0.), link(2.5, 5.5), link(5.5, 10.25, 0.),
             link(10.25, 15.25), link(15.25, 30., 0.)]
    p = owner(links)
    assert p.kernel.offered_bits_between(3.5, 12.25) == pytest.approx(4.*8e6)
    submit(p, size_mb=5., encoding_s=1.5)
    p.execute(6.)
    assert sum(f['business_bits'] for f in p.flows) == 2*8e6
    assert p.flows[0]['start_s'] == pytest.approx(3.5)
    assert p.order[0].remaining_bits == 3*8e6
    assert p.order[0].sent_bits == 2*8e6
    assert not p.ground_events
    p.execute(15.)
    assert p.ground_events[0]['tx_end_s'] == pytest.approx(13.25)
    assert p.ledger()['downlink_mb'] == pytest.approx(5.)
    assert all((2.5 <= f['start_s'] < f['end_s'] <= 5.5) or
               (10.25 <= f['start_s'] < f['end_s'] <= 15.25) for f in p.flows)


def test_multiple_products_share_airtime_without_overlap():
    p = owner([link(0., 2., 0.), link(2., 10.), link(10., 20., 0.)])
    for task in ('a', 'b'):
        submit(p, task, size_mb=3., inference_s=0., inference_j=0., encoding_s=0., encoding_j=0.)
    p.execute(12.)
    assert [r['tx_end_s'] for r in p.ground_events] == pytest.approx([5., 8.])
    flows = sorted(p.flows, key=lambda x: x['start_s'])
    assert all(a['end_s'] <= b['start_s']+1e-10 for a,b in zip(flows, flows[1:]))
    assert sum(x['business_bits'] for x in flows) == 6*8e6
    assert p.ledger()['controlled_j'] == pytest.approx(60.)


def test_ready_product_can_pass_not_ready_queue_entry():
    p = owner()
    submit(p, 'late', size_mb=.1, inference_s=10., inference_j=20., encoding_s=0., encoding_j=0.)
    # Independent incoming product is ready now; no computed-data dependency.
    ready = plan(p, 'ready', size_mb=.1, inference_s=0., inference_j=0., encoding_s=0., encoding_j=0.)
    ready['item'] = replace(ready['item'], ready_time_s=0.)
    ready['ready_s'] = 0.
    p.authorize(ready)
    p.execute(2.)
    assert p.flows[0]['task_id'] == 'ready'
    assert not any(f['task_id'] == 'late' for f in p.flows)


def test_deadline_expires_partial_bytes_keeps_real_cost():
    p = owner()
    submit(p, size_mb=10., inference_s=0., inference_j=0., encoding_s=0., encoding_j=0., deadline_s=2.5)
    p.execute(5.)
    assert not p.ground_events and not p.order
    assert p.ledger()['downlink_mb'] == pytest.approx(2.5)
    assert p.ledger()['expired_mb'] == pytest.approx(7.5)
    assert p.ledger()['controlled_j'] == pytest.approx(25.)
    assert all(f['end_s'] <= 2.5 for f in p.flows)


def test_zero_service_has_no_tx_or_ground_but_compute_cost_remains():
    p = owner([link(0., 30., 0.)])
    submit(p, deadline_s=10.)
    p.execute(20.)
    assert not p.flows and not p.ground_events
    assert p.ledger()['controlled_j'] == pytest.approx(26.)
    assert p.ledger()['expired_mb'] == pytest.approx(1.)


def test_offload_ground_processing_is_delayed_and_serial():
    p = owner()
    for task in ('a', 'b'):
        submit(p, task, route='GROUND', size_mb=.25, inference_s=0., inference_j=0.,
               encoding_s=0., encoding_j=0., ground_s=5.)
    p.execute(1.)
    assert not p.ground_events
    assert [r['ground_available_s'] for r in p.ground_pending] == pytest.approx([5.25, 10.25])
    p.execute(6.)
    assert len(p.ground_events) == 1
    assert p.ground_events[0]['ground_start_s'] == pytest.approx(.25)
    p.execute(11.)
    assert len(p.ground_events) == 2
    assert p.ground_events[1]['ground_start_s'] == pytest.approx(5.25)
    assert p.ledger()['controlled_j'] == pytest.approx(5.)  # Ground energy excluded.


def test_ground_result_after_deadline_is_not_valid_completion():
    p = owner()
    submit(p, route='GROUND', size_mb=.25, inference_s=0., inference_j=0.,
           encoding_s=0., encoding_j=0., ground_s=5., deadline_s=3.)
    p.execute(6.)
    assert p.ground_events and not p.ground_events[0]['valid']
    assert p.ledger()['downlink_mb'] == pytest.approx(.25)


def test_direct_product_does_not_wait_for_offload_ground_server():
    p = owner()
    submit(p, 'ground', route='GROUND', size_mb=.25, inference_s=0., inference_j=0.,
           encoding_s=0., encoding_j=0., ground_s=5.)
    submit(p, 'direct', route='DIRECT', size_mb=.25, inference_s=0., inference_j=0.,
           encoding_s=0., encoding_j=0., ground_s=0.)
    p.execute(1.)
    assert len(p.ground_events) == 1
    assert p.ground_events[0]['task_id'] == 'direct'
    assert p.ground_events[0]['ground_available_s'] == pytest.approx(.5)
    assert p.ground_pending[0]['ground_available_s'] == pytest.approx(5.25)


def test_tut_fixed_delay_is_independent_of_offload_server_and_other_tut():
    p = owner()
    submit(p, 'offload', route='GROUND', size_mb=.25, inference_s=0., inference_j=0.,
           encoding_s=0., encoding_j=0., ground_s=10.)
    for task in ('tut_a', 'tut_b'):
        submit(p, task, route='TUT', size_mb=.25, inference_s=0., inference_j=0.,
               encoding_s=0., encoding_j=0., ground_s=5.)
    p.execute(1.)
    by_task = {r['task_id']: r for r in p.ground_pending}
    assert by_task['tut_a']['ground_available_s'] == pytest.approx(5.5)
    assert by_task['tut_b']['ground_available_s'] == pytest.approx(5.75)
    assert p.ground_free == pytest.approx(10.25)
    p.execute(6.)
    assert {r['task_id'] for r in p.ground_events} == {'tut_a', 'tut_b'}
    assert [r['task_id'] for r in p.ground_pending] == ['offload']


@pytest.mark.parametrize('route', ['GROUND', 'B1'])
def test_ground_32_waiting_capacity_overflow_preserves_tx_and_reopens(route):
    p = owner()
    for i in range(34):
        submit(p, f'job_{i:02d}', route=route, size_mb=.001, inference_s=0., inference_j=0.,
               encoding_s=0., encoding_j=0., ground_s=2.)
    p.execute(1.)
    # Capacity is 32 waiting plus one processing; the 34th still paid TX.
    assert len(p.ground_pending) == 33
    assert not p.ground_events
    overflow = [e for e in p.events if e['kind'] == 'GROUND_QUEUE_OVERFLOW']
    assert len(overflow) == 1 and overflow[0]['task_id'] == 'job_33'
    assert len(p.completed) == 34
    assert len([e for e in p.events if e['kind'] == 'TX_COMPLETE']) == 34
    assert p.ledger()['downlink_mb'] == pytest.approx(.034)
    assert p.ledger()['controlled_j'] == pytest.approx(.34)
    # One real ground service completion frees one waiting slot; no reset.
    p.execute(2.1)
    assert len(p.ground_events) == 1
    submit(p, 'after_release', route=route, size_mb=.001, inference_s=0., inference_j=0.,
           encoding_s=0., encoding_j=0., ground_s=2.)
    p.execute(3.)
    assert len([e for e in p.events if e['kind'] == 'GROUND_QUEUE_OVERFLOW']) == 1
    assert any(r['task_id'] == 'after_release' for r in p.ground_pending)
    assert not any(r['task_id'] == 'job_33' for r in p.ground_pending+p.ground_events)


def test_thermal_and_soc_unsafe_projections_do_not_commit():
    p = owner()
    p.state = replace(p.state, temperatures_c=(60., 15., 15., 15.))
    before = p.identity()
    assert not p.project(end_s=1.)['safe']
    with pytest.raises(RuntimeError, match='EXECUTION_SAFETY_STOP'):
        p.execute(1.)
    assert p.identity() == before and not p.trajectory
    low = owner()
    low.soc = .549
    before = low.identity()
    projected = low.project(end_s=1.)
    assert not projected['safe'] and 'BATTERY_RESERVE' in projected['reason']
    assert low.identity() == before


@pytest.mark.parametrize('soc, expected', [(.85,.15),(.70,.30),(.55,.45),(1.,0.),(0.,1.),(-.1,1.)])
def test_energy_pressure_fraction_boundaries(soc, expected):
    assert energy_pressure(soc) == pytest.approx(expected)


def test_energy_pressure_percent_monotonic_and_bad_units():
    assert [energy_pressure(x, 'percent') for x in (85., 70., 55.)] == pytest.approx([.15,.30,.45])
    values = [energy_pressure(x) for x in (0., .2, .55, .7, .85, 1.)]
    assert values == sorted(values, reverse=True)
    with pytest.raises(ValueError, match='FRACTION'):
        energy_pressure(85.)
    with pytest.raises(ValueError, match='NONFINITE'):
        energy_pressure(float('nan'))
    with pytest.raises(ValueError, match='UNKNOWN_SOC_UNIT'):
        energy_pressure(.85, 'volts')


def test_thermal_units_background_and_source_nodes_conserve_energy():
    p = owner()
    net = p.network
    idle = net.advance(p.state, 2., ThermalPowerV1(absorbed_external_w=20.))
    compute = net.advance(p.state, 2., ThermalPowerV1(board_incremental_w=10., absorbed_external_w=20.))
    radio = net.advance(p.state, 2., ThermalPowerV1(rf_incremental_dc_w=10., absorbed_external_w=20.))
    assert idle.ledger_j['electrical'] == pytest.approx(8.86*2.)
    assert compute.ledger_j['electrical']-idle.ledger_j['electrical'] == pytest.approx(20.)
    assert compute.node_input_heat_j['chip']-idle.node_input_heat_j['chip'] == pytest.approx(20.)
    assert radio.node_input_heat_j['rf']-idle.node_input_heat_j['rf'] == pytest.approx(20.)
    assert net.p.safe_limits_c == dict(chip=53.9, board=30., rf=65., structure=30.)
    for c in (idle, compute, radio):
        assert abs(c.ledger_j['conservation_residual']) < 1e-5
        assert c.ledger_j['stored'] == pytest.approx(c.ledger_j['electrical']+
            c.ledger_j['absorbed_external']-c.ledger_j['emitted_external']-c.ledger_j['escaped_rf'], abs=1e-5)
    # Pressure is state headroom; energy is an action ledger, not temperature.
    at_origin = replace(p.state, temperatures_c=(15.,15.,15.,15.))
    at_limit = replace(p.state, temperatures_c=(53.9,15.,15.,15.))
    assert thermal_pressure(at_origin,net.p) == 0.
    assert thermal_pressure(at_limit,net.p) == pytest.approx(1.)


def test_physical_energy_soc_and_bytes_reconcile():
    p = owner()
    submit(p)
    initial_soc = p.soc
    p.execute(10.)
    ledger = p.ledger()
    assert ledger['controlled_j'] == pytest.approx(20.+6.+10.)
    assert ledger['background_j'] == pytest.approx(88.6)
    assert ledger['downlink_mb'] == pytest.approx(1.)
    expected_delta = -(ledger['controlled_j']+ledger['background_j'])/CFG['simulator']['battery_discharge_efficiency']
    assert ledger['battery_delta_j'] == pytest.approx(expected_delta, abs=1e-7)
    assert (p.soc-initial_soc)*CFG['simulator']['battery_capacity_j'] == pytest.approx(expected_delta, abs=1e-7)
    assert sum(p.window_transmitted.values()) == 8e6
    assert ledger['backlog_mb'] == 0.


def test_trace_flag_and_identical_inputs_preserve_physics():
    a,b = owner(),owner()
    a.trace_enabled = False
    b.trace_enabled = True
    for p in (a,b):
        submit(p, inference_s=25., inference_j=50.)
        p.execute(20.)
        p.execute(40.)
    assert state_summary(a) == state_summary(b)


def test_mode_updates_on_control_slots_not_events():
    p = owner()
    controller = NetworkController(CFG, 'pressure_fixed')
    for slot in range(12):
        p.execute(slot*20.)
        for _ in range(3):
            controller.observe_slot(slot,p,None)
    assert [r['slot'] for r in controller.mode_updates] == [0,10]
    assert len(controller.history) == 10


def test_pressure_price_keeps_base_once_and_fixed_unit_conversion():
    p = owner()
    c = NetworkController(CFG, 'pressure_fixed')
    margin = dict(offered_bits=80e6, committed_bits=20e6, remaining_bits=60e6, safe_available_bits=80e6)
    before = p.identity()
    g = c.guidance(p,margin)
    assert g['pressure']['E'] == pytest.approx(.15)
    assert g['pressure']['window'] == pytest.approx(.25)
    price = CFG['lyapunov_pricing']
    assert g['lambda_E'] == pytest.approx(price['base_lambda_E']*(1+1.2*.15+.8*g['pressure']['H']))
    assert g['lambda_S'] == pytest.approx(price['base_lambda_S']*(1+1.1*.25))
    assert price['base_lambda_S']/5120. == pytest.approx(.09202386055743175)
    assert p.identity() == before


def test_service_margin_deducts_only_overlapping_outstanding_service():
    p = owner()
    submit(p, size_mb=2., inference_s=0., inference_j=0., encoding_s=0., encoding_j=0.)
    baseline = p.project(end_s=10.)
    m = p.service_margin(1.,3.,baseline)
    assert m['offered_bits'] == pytest.approx(2*8e6)
    assert m['committed_bits'] == pytest.approx(1*8e6)
    assert m['remaining_bits'] == pytest.approx(1*8e6)
    p.execute(1.)
    after = p.service_margin(1.,3.,p.project(end_s=10.))
    assert after == pytest.approx(m)  # Already-sent prefix is not charged twice.
