from pathlib import Path
from copy import deepcopy
from dataclasses import asdict
import importlib.util,sys,random
import pytest
from test_network_multiarrival import make
from src.energy.celsius_thermal_network_v1 import CelsiusThermalNetworkV1,ThermalPowerV1

ROOT=Path(__file__).resolve().parents[2]
def old_thermal():
    path=ROOT/'handoff_out/NETWORK_DEV1600_6H_SEED2026_20261027_01/PERFORMANCE/BEFORE/src/energy/celsius_thermal_network_v1.py'
    spec=importlib.util.spec_from_file_location('thermal_before_exact_performance',path)
    m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
    return m

def test_same_solver_event_peaks_and_certificates_exact():
    old=old_thermal();params=make().physics.network.p
    a=old.CelsiusThermalNetworkV1(old.CelsiusNetworkParametersV1(**asdict(params)),max_step_s=20.,cache_size=0)
    b=CelsiusThermalNetworkV1(params,max_step_s=20.,cache_size=0)
    rng=random.Random(2026)
    for i in range(96):
        time=rng.uniform(0,20000);end=time+[0.,.001,.1,1.,20.,60.,200.,600.][i%8]
        temps=tuple(rng.uniform(15,65) for _ in range(4))
        power=dict(board_incremental_w=rng.uniform(0,30),rf_incremental_dc_w=rng.uniform(0,40),absorbed_external_w=rng.uniform(15,25))
        aa=a.advance(old.CelsiusStateV1(time,temps),end,old.ThermalPowerV1(**power)).to_dict()
        bb=b.advance(type(params.initial_state())(time,temps),end,ThermalPowerV1(**power)).to_dict()
        assert aa==bb

def test_certificate_cache_mutation_isolation():
    n=make().physics.network;s=n.p.initial_state();p=ThermalPowerV1(absorbed_external_w=20.)
    a=n.advance(s,20.,p);expected=deepcopy(a.to_dict())
    a.peaks_c['chip']=999.;a.ledger_j['stored']=999.;a.node_input_heat_j['board']=999.
    b=n.advance(s,20.,p);assert b.to_dict()==expected
    b.headroom_c['chip']=999.;b.peak_times_s['chip']=999.
    assert n.advance(s,20.,p).to_dict()==expected

def test_finished_work_filter_and_pickle_cache_exact_detached():
    e=make();e.run(40.);p=e.physics
    args=dict(thermal_state=p.state,soc=p.soc,order=tuple(p.order),completed=dict(p.completed),
        work=tuple(p.work),end_s=100.,bill=False,window_transmitted_bits=dict(p.window_transmitted))
    p.kernel._projection_cache.clear();p.kernel.projection_cache_codec='deepcopy'
    original=p.kernel.project(**args)
    p.kernel._projection_cache.clear();p.kernel.projection_cache_codec='pickle'
    result=p.project(end_s=100.)
    assert original==result
    expected=deepcopy(result)
    result['trajectory'][0]['thermal']['peaks_c']['chip']=999.
    result['remaining']['poison']=12
    result['completed']['poison']=1.
    assert p.project(end_s=100.)==expected

def test_no_future_service_is_zero_not_invalid_interval():
    e=make();p=e.physics
    base=p.project(end_s=59.)
    assert p.service_margin(45.,59.,base)['remaining_bits']==0.
    assert p.executable_margin(45.,59.,base)['remaining_bits']==0.

def test_shared_baseline_all_nine_candidates_exact_and_no_state_mutation():
    e=make();t=e.tasks[0];e.arrived[t.task_id]=t;e.physics.execute(t.arrival_s)
    before=e.physics.identity()
    standalone=[e.candidate(t,a) for a in e.actions]
    context={};shared=[e.candidate(t,a,decision_context=context) for a in e.actions]
    assert len(shared)==9
    assert standalone==shared
    assert len(context['baselines'])==1
    assert before==e.physics.identity()
