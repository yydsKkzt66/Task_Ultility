from pathlib import Path
from copy import deepcopy
from dataclasses import replace
from collections import Counter
import math,json,csv,pickle
import pytest
from formal_common import ROOT,read,job_for,dump_checkpoint,load_checkpoint
from formal_worker import execute
from src.network_revision.runtime import NetworkExperiment,load_inputs
from src.network_revision.physics import NetworkPhysics
from src.network_revision.incremental import terminal_quote,incremental_score
from test_network_revision_runtime import interval,action,authorize_mechanism,full_decision_state

SEED=read(ROOT/'FORMAL_AUTHORITY.json')['seeds'][0]
def scene(arm='PROP',method=None):
    j=job_for(SEED,arm);e=NetworkExperiment(ROOT,j['variant'],method or j['method'],trace=False);e.fast_nonpositive_bound=True
    e.config['horizon_s']=120.;e.config['incremental_pricing']['formal_settlement_s']=120.
    e.physics=NetworkPhysics(e.config['physics']['network'],e.cfg['simulator'],[interval(0,20,0),interval(20,40,8e6,'first'),interval(40,80,0),interval(80,100,8e6,'last'),interval(100,120,0)])
    tasks=[]
    for i,t in enumerate([1.,1.,1.1,19.999,20.,39.999,79.999,101.]):
        x=deepcopy(e.tasks[0]);x.task_id=f'synthetic_{i}';x.arrival_s=t;x.arrival_slot=int(t//20);x.task_value=x.calibrated_task_value=10.
        x.value_level='high';x.high_value_flag=1;x.emergency_flag=0;x.deadline_s=180.;x.deadline_time_s=t+180.;x.product_requirement='alert';x.information_requirement=x.quality_requirement=.1;tasks.append(x)
    e.tasks=tasks
    return e

def test_all_seed_inputs_calendar_phase_and_finite_evaluation():
    matrix=read(ROOT/'RUN_MATRIX.json')['jobs'];assert len(matrix)==45
    for seed in read(ROOT/'FORMAL_AUTHORITY.json')['seeds']:
        j=job_for(seed,'PROP');e=NetworkExperiment(ROOT,j['variant'],'PROP');c=e.config
        assert c['horizon_s']==c['incremental_pricing']['formal_settlement_s']==21600.
        assert Counter(t.value_level for t in e.tasks)==dict(low=322,medium=830,high=323,urgent=125)
        assert all(0<=t.arrival_s<20700 and math.isclose(t.deadline_time_s-t.arrival_s,t.deadline_s,abs_tol=1e-9) for t in e.tasks)
        assert sum(t.value_level in {'high','urgent'} for t in e.tasks)==448
        assert len({tuple(sorted(jj['input_hashes'].items())) for jj in matrix if jj['seed']==seed})==1
        old=NetworkExperiment(ROOT,'incremental_dev1600','PROP')
        for k in ['q_eff','public_prices','physics','capacity']:assert c[k]==old.config[k]
        assert e.physics.state==old.physics.state and e.physics.soc==old.physics.soc
        assert e.cfg['mode_controller']==old.cfg['mode_controller']
        a=e.physics.kernel.links;b=old.physics.kernel.links[126:1206]
        for x,y in zip(a,b):
            assert x.start_s==y.start_s-2520 and x.end_s==y.end_s-2520
            for key in ['business_rate_bit_s','tx_dc_power_w','solar_power_w','absorbed_external_w']:assert getattr(x,key)==getattr(y,key)

@pytest.mark.parametrize('method',['PROP','GROUND','OFFLOAD','TUT_ADAPTED'])
def test_eventful_four_methods_worker_audit_and_exact_checkpoint_resume(method,tmp_path):
    job=job_for(SEED,method);a=scene(method)
    execute(job,tmp_path/'straight',stop=120.,experiment=a,identities={'synthetic':'same'})
    b=scene(method)
    execute(job,tmp_path/'first',stop=60.,experiment=b,identities={'synthetic':'same'})
    restored=execute(job,tmp_path/'resumed',stop=120.,resume=tmp_path/'first/CHECKPOINTS/T00060.pkl',identities={'synthetic':'same'})
    assert a.physics.identity()==restored.physics.identity()
    assert a.decisions==restored.decisions and a.ground_ledger==restored.ground_ledger
    assert len(a.arrived)==8 and a.physics.flows and a.closed
    assert a.evaluate()['task_status']['synthetic_7'].startswith('right_censored')
    assert a.evaluate()['costs']==restored.evaluate()['costs']

@pytest.mark.parametrize('arm',['NO_RESOURCE_MODULATION','NO_MODE','FIXED_HIGH','REQUIRED_PRODUCT_ONLY','NO_PROGRESSIVE_REFINEMENT'])
def test_arm_isolation_actual_choices_and_ledger(arm,tmp_path):
    e=scene(arm);e.controller.mode_name='energy_saving';execute(job_for(SEED,arm),tmp_path/arm,stop=120.,experiment=e,identities={'synthetic':'arm'})
    assert e.physics.flows and e.closed
    if arm=='FIXED_HIGH':assert {v['model'] for v in e.physics.products.values()}=={'high_accuracy'}
    if arm=='REQUIRED_PRODUCT_ONLY':assert any(v['product']=='metadata' for v in e.physics.products.values())
    if arm=='NO_PROGRESSIVE_REFINEMENT':assert not any(v.get('continuation') for v in e.physics.products.values())

def test_post_period_forecast_has_zero_benefit_and_no_early_authorization():
    e=scene();e.fast_nonpositive_bound=False;t=e.tasks[-1];e.arrived={t.task_id:t};e.physics.execute(101.)
    before=full_decision_state(e);c=e.candidate(t,action(e,'metadata'))
    assert full_decision_state(e)==before and not c['feasible'] and c['score']['positive_benefit']==0
    s=c['score'];g=c['guidance'];base=e.physics.project(end_s=120.)
    term=terminal_quote(e.physics,e.physics.order,base,120.)
    scored=incremental_score(t,'metadata',set(),.8,120.1,c['plan'],c['projection'],base,term,term,g,e.config['public_prices'])
    assert scored['positive_benefit']==0 and scored['deliverable_indicator']==0

def test_nonzero_delta_terminal_ready_backlog_matches_execution():
    e=scene();old,new=deepcopy(e.tasks[0]),deepcopy(e.tasks[1]);old.task_id='old';new.task_id='new'
    for t in [old,new]:t.arrival_s=0.;t.arrival_slot=0;t.deadline_time_s=t.deadline_s=200.
    old.product_requirement='verification';new.product_requirement='alert';e.tasks=[old,new];e.arrived={t.task_id:t for t in e.tasks};e.config['horizon_s']=60.
    e.physics=NetworkPhysics(e.config['physics']['network'],e.cfg['simulator'],[interval(0,2,8e6,'tiny'),interval(2,60,0)])
    authorize_mechanism(e,old,'roi_context',size=3.,infer_s=0.,infer_j=0.,encoding_s=0.,encoding_j=0.)
    base=e.physics.project(end_s=60.);baseq=terminal_quote(e.physics,e.physics.order,base,60.)['backlog_mb']
    c=e.candidate(new,action(e,'metadata'));assert c['feasible'] and c['score']['delta_Q_end_mb']>0
    before=e.physics.identity();e.physics.executable_margin(0.,2.,base);assert e.physics.identity()==before
    e.physics.authorize(c['plan']);e.advance_slot_events(60.,0)
    assert e.physics.ledger()['backlog_mb']-baseq==pytest.approx(c['score']['delta_Q_end_mb'],abs=1/8e6)
    assert e.physics.ledger()['backlog_mb']>0 and e.evaluate()['costs']['terminal_backlog']>0

def test_required_only_removes_partial_but_retains_models_and_defer():
    e=scene('REQUIRED_PRODUCT_ONLY');t=e.tasks[0];t.arrival_s=0.;t.product_requirement='evidence';t.task_value=t.calibrated_task_value=.000001
    e.arrived={t.task_id:t};e.fast_nonpositive_bound=False
    chosen=e.decide(t);assert chosen is None
    assert {r['product'] for r in e.candidates}=={'roi_context'}
    assert {r['model'] for r in e.candidates}=={'lightweight','balanced','high_accuracy'}
    assert e.pending[t.task_id]=='retry_initial'

def test_no_progressive_preserves_existing_crosswindow_bytes(tmp_path):
    e=scene('NO_PROGRESSIVE_REFINEMENT');t=e.tasks[0];t.arrival_s=0.;e.arrived={t.task_id:t};t.product_requirement='verification'
    e.physics=NetworkPhysics(e.config['physics']['network'],e.cfg['simulator'],[interval(0,2,8e6,'first'),interval(2,20,0),interval(20,22,8e6,'second'),interval(22,120,0)])
    authorize_mechanism(e,t,'roi',size=3.,infer_s=0.,infer_j=0.,encoding_s=0.,encoding_j=0.)
    e.advance_slot_events(20.,0);assert e.physics.order[0].remaining_bits>0
    e.advance_slot_events(40.,1);assert sum(f['business_bits'] for f in e.physics.flows)==24_000_000
    assert len(e.physics.products)==1 and not e.pending and not e.staged_requests

def test_large_clock_reserved_empty_replay_bits_and_protection():
    # Synthetic large timestamp, not presented as a historical task0207 replay.
    e=scene();p=NetworkPhysics(e.config['physics']['network'],e.cfg['simulator'],[interval(72400,74520,0),interval(74520,75120,24.28e6,'contact')])
    p.state=replace(p.state,time_s=72400.)
    for i,size in enumerate([2.6955635,3.452321125]):
        plan=p.plan(task_id=f't{i}',model='lightweight',product='roi_context',size_mb=size,inference_s=0.,inference_j=0.,encoding_s=0.,encoding_j=0.,deadline_s=75120.,q=.8,route='DIRECT',ground_s=0.)
        p.authorize(plan)
    original=p.identity();baseline=p.project(end_s=75120.)
    reservations=tuple((f['product_id'],f['start_s'],f['end_s']) for f in baseline['flows'])
    empty=p.kernel.project(thermal_state=p.state,soc=p.soc,order=tuple(p.order),completed={},work=(),end_s=75120.,bill=False,window_transmitted_bits={},reserved_slices=reservations)
    assert empty['safe'] and empty['remaining']==baseline['remaining']
    assert empty['finishes']==baseline['finishes']
    assert sum(f['business_bits'] for f in empty['flows'])==sum(v['original_bits'] for v in p.products.values())
    margin=p.executable_margin(72400.,75120.,baseline)
    assert p.identity()==original and margin['remaining_bits']>8e6
    from src.link.net_utility_insertion_v2 import IndependentQueueStageV2
    probe=IndependentQueueStageV2('probe','probe','probe',74520.,75120.,8_000_000)
    trial=p.kernel.project(thermal_state=p.state,soc=p.soc,order=tuple(p.order)+(probe,),completed={},work=(),end_s=75120.,bill=False,window_transmitted_bits={},reserved_slices=reservations)
    assert trial['safe'] and trial['remaining']['probe']==0
    assert all(trial['finishes'][pid]<=t+1e-7 for pid,t in baseline['finishes'].items())

def test_new_ablation_configs_one_defined_switch_only():
    base=read(ROOT/'configs/network_revision'/f"{job_for(SEED,'PROP')['variant']}.json")
    for arm,key,setting,value in [('NO_RESOURCE_MODULATION','incremental_pricing','use_dynamic',False),('NO_MODE','incremental_pricing','use_mode',False),('NO_PROGRESSIVE_REFINEMENT','ablation','allow_progressive',False),('FIXED_HIGH','ablation','allowed_models',['high_accuracy']),('REQUIRED_PRODUCT_ONLY','ablation','required_product_only',True)]:
        c=read(ROOT/'configs/network_revision'/f"{job_for(SEED,arm)['variant']}.json");expect=deepcopy(base);expect['variant']=c['variant'];expect.setdefault(key,{})[setting]=value
        assert c==expect
