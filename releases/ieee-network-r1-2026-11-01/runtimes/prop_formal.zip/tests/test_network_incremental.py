from copy import deepcopy
from pathlib import Path
import pytest
from src.network_revision.runtime import NetworkExperiment
from src.network_revision.incremental import IncrementalController,choose_incremental
from src.network_revision.physics import NetworkPhysics
from test_network_revision_runtime import interval, action, authorize_mechanism, full_decision_state

ROOT=Path(__file__).resolve().parents[1]
def scene(variant='incremental',method='PROP',rate=8e6):
    e=NetworkExperiment(ROOT,variant,method)
    t=deepcopy(e.tasks[0]);t.task_id='synthetic_incremental';t.arrival_s=0.;t.arrival_slot=0
    t.deadline_s=t.deadline_time_s=60.;t.value_level='low';t.task_value=t.calibrated_task_value=2.
    t.product_requirement='evidence';t.quality_requirement=t.information_requirement=.1
    e.tasks=[t];e.arrived={t.task_id:t};e.config['horizon_s']=60.
    e.physics=NetworkPhysics(e.config['physics']['network'],e.cfg['simulator'],[interval(0.,60.,rate)])
    return e,t

def test_incremental_candidate_isolated_q_once_and_no_legacy_terms():
    e,t=scene();before=full_decision_state(e)
    c=e.candidate(t,action(e,'roi_context'))
    assert full_decision_state(e)==before
    s=c['score'];g=c['guidance']
    assert s['positive_benefit']==pytest.approx(t.task_value*.95*e.qmap['lightweight']*s['timeliness'])
    assert s['delta_Q_end_mb']==0 and s['terminal']['resolved']
    assert s['net_score']==pytest.approx(s['fixed_net']-g['mu_E']*s['energy_new_j']-g['mu_B']*s['tx_new_mb'])
    assert not {'mode_bias','latency_cost','queue_cost','payload_cost'} & s.keys()
    assert not {'model_complexity_bias','payload_size_bias','lambda_L'} & g.keys()

def test_negative_cached_continuation_rejected_and_no_new_work():
    e,t=scene();t.task_value=t.calibrated_task_value=.01
    authorize_mechanism(e,t,'roi',size=.01);e.physics.execute(3.);e.observe_ground()
    c=e.candidate(t,action(e,'roi_context'),continuation=True)
    assert c['feasible'] and c['score']['positive_benefit']>0
    assert c['cached_inference'] and c['score']['inference_new_j']==0
    assert c['score']['net_score']<0
    before=e.physics.identity()
    assert e.decide(t,continuation=True) is None
    assert e.physics.identity()==before

def test_zero_tie_does_not_authorize_even_high_value():
    e,t=scene();t.value_level='high'
    c=e.candidate(t,action(e,'roi_context'));c['score']['net_score']=0.
    assert choose_incremental([c],t,set())[0] is None

def test_prefix_is_not_terminal_and_pending_is_censored():
    e,t=scene(rate=0.)
    authorize_mechanism(e,t,'roi',size=1.)
    e.physics.execute(5.);e.observe_ground();r=e.evaluate()
    assert not r['terminal_settled'] and r['formal_settlement_s']==60.
    assert r['costs']['terminal_backlog']==0.
    assert r['observation_backlog_snapshot_charge']>0
    assert r['task_status'][t.task_id]=='right_censored_pending'
    assert r['costs']['energy']>0 and r['gross']==0

def test_ablations_change_only_scarcity():
    rows=[]
    for variant in ['incremental','incremental_no_mode','incremental_no_dynamic']:
        e,t=scene(variant);e.controller.mode_name='energy_saving'
        rows.append(e.candidate(t,action(e,'roi_context')))
    a,b,c=rows
    assert a['score']['fixed_net']==b['score']['fixed_net']==c['score']['fixed_net']
    assert a['guidance']['mu_E']>b['guidance']['mu_E']>c['guidance']['mu_E']==0.
    assert c['score']['net_score']==c['score']['fixed_net']
    assert b['guidance']['pressure']==a['guidance']['pressure']

def signals(**changes):
    s=dict(soc=.85,thermal=.2,replenishment_soc_estimate=.85,queue_congestion=0.,known_work_count=0,next_contact_s=0.,urgency=0.,hv_fraction=0.,hv_denominator=0)
    s.update(changes);return s

def test_mode_priority_entry_exit_and_celsius_thresholds():
    e,t=scene();c=e.controller
    assert c.select_mode(signals(soc=.69,hv_fraction=1.,hv_denominator=1))=='energy_saving'
    c.mode_name='energy_saving'
    assert c.select_mode(signals(soc=.72))=='energy_saving'
    assert c.select_mode(signals(soc=.75))=='balanced'
    c.mode_name='balanced'
    assert c.select_mode(signals(queue_congestion=.8,hv_fraction=1.,hv_denominator=1))=='queue_draining'
    assert c.select_mode(signals(known_work_count=1,next_contact_s=500.,hv_fraction=1.,hv_denominator=1))=='egress_conservative'
    assert c.select_mode(signals(urgency=.7))=='latency_critical'
    assert c.select_mode(signals(hv_fraction=1.,hv_denominator=1))=='mission_priority'
    for name,hard in e.physics.network.p.safe_limits_c.items():
        entry=15.+.8*(hard-15.);exit_=15.+.7*(hard-15.)
        assert exit_<entry<hard

def test_mode_calendar_hv_denominator_and_slow_clock():
    e,t=scene();e.physics=NetworkPhysics(e.config['physics']['network'],e.cfg['simulator'],[interval(0.,30.,0.),interval(30.,60.)])
    t.value_level='high'
    e.controller.observe_slot(0,e.physics,t,arrived=e.arrived,pending={t.task_id:'retry'},closed={})
    s=e.controller.signals
    assert s['next_contact_s']==30. and s['hv_denominator']==1 and s['hv_fraction']==1.
    assert s['urgency']>0
    e.physics.execute(20.);e.controller.observe_slot(1,e.physics,None,arrived=e.arrived,pending={},closed={})
    assert len(e.controller.mode_updates)==1

def test_accepted_queue_service_is_not_repriced():
    e,t=scene();selected=e.decide(t);assert selected
    e.controller.guidance=lambda *a,**k: (_ for _ in ()).throw(AssertionError('REPRICED_ACCEPTED_SERVICE'))
    e.advance_slot_events(10.,0)
    assert e.physics.ledger()['downlink_mb']>0

def test_full_scope_is_explicit_and_development_identity_is_required():
    e,t=scene()
    with pytest.raises(ValueError,match='FULL_LIFECYCLE'):e.run(60.)
    with pytest.raises(ValueError,match='INDEPENDENT_DEVELOPMENT'):e.run(60.,full_scope='development')
    e.config['dataset_scope']='INDEPENDENT_DEVELOPMENT'
    e.tasks=[]
    e.run(60.,full_scope='development')
    assert e.evaluate()['terminal_settled']

def test_prepared_independent_development_preserves_business_and_physics():
    a=NetworkExperiment(ROOT,'incremental');b=NetworkExperiment(ROOT,'incremental_development_3103')
    assert b.config['seed']==3103 and len(a.tasks)==len(b.tasks)==268
    aa={t.task_id:t for t in a.tasks};bb={t.task_id:t for t in b.tasks}
    assert sorted(t.arrival_slot for t in a.tasks)==sorted(t.arrival_slot for t in b.tasks)
    assert any(aa[k].arrival_slot!=bb[k].arrival_slot for k in aa)
    for k in aa:
        for field in ['task_value','product_requirement','value_level','deadline_s','difficulty','quality_requirement','information_requirement']:
            assert getattr(aa[k],field)==getattr(bb[k],field)
    assert a.physics.kernel.links==b.physics.kernel.links
    assert a.qmap==b.qmap and a.config['public_prices']==b.config['public_prices']
