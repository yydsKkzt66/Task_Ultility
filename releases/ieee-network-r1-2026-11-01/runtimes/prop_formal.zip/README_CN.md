# IEEE Network 6h 五种子实验运行包 V1

本包使用原完整 PROP 的“基于资源状态的定价”。不含 Mode A–H 筛选变体、ROI 补救、HV 额外授权或温度平滑。它是合成模板负载与工程代理 profile 下的独立五种子实验，不能称作 1600 幅独立实测图像、真实星历重算或星上硬件实测。论文未修改。

## Windows 从解压到启动

建议使用短路径。将 ZIP 解压后进入包含 `run.py` 的目录。PowerShell 示例：

```powershell
Expand-Archive -LiteralPath '.\NETWORK_FORMAL6H_ABLATION_PORTABLE_V1.zip' -DestinationPath '.\NetworkFormal6H'
Set-Location '.\NetworkFormal6H'
conda create -n network-formal6h python=3.11.15 pip -y
conda activate network-formal6h
python -m pip install -r requirements.txt
python -I run.py selfcheck --out SELF_CHECK
python -I run.py launch --group ablation --out outputs_ablation --max-workers 5 --detach
```

已验证 Python 3.11.15、64 位 Windows。原电脑使用 Conda；若使用官方 CPython 3.11，安装相同依赖并先自检。自检依赖 pytest；运行依赖 NumPy/SciPy/psutil/PyYAML，绘图依赖 Matplotlib。依赖轮子不包含在包内，首次安装需要联网或另备对应平台 wheel。源码、模板元数据、特征摘要、profile、vendor 及全部冻结输入均包含。代码以本目录定位，不读取原电脑 D 盘或原工程 PYTHONPATH。

`run.py` 在导入数值库前将进程内部线程限制为 1；Conda/Windows 下登记该 Python 环境的 Library/bin DLL 目录。物理积分器和精度不变。不要在同一机器重复启动两个正式调度器。默认最多 5 个作业；可通过 `--max-workers 3` 降低并发，不改变算法。

自检需要约几分钟，包含真实发送窗口的少量合成任务：多到达、串行 CPU、ready、地面事件、分包跨窗续传、有限终态、非零 ΔQ_end、五开关、四方法连续运行/完整状态恢复一致。输出 `SELF_CHECK/SELF_CHECK.json` 和 `pytest.xml`；预期退出码为 0。自检不是正式实验结果，不改变任何冻结配置。正式启动前再次验证 SHA。禁止修改冻结文件后继续同一张表。

## 运行顺序与恢复

消融机按种子屏障执行：4101 的 A–E 五组全部完成，再启动 4102，直至 4105。完整 PROP 由主机运行，消融机不会重复运行 PROP。

本机主实验命令：

```powershell
python -I run.py launch --group main --out outputs_main --max-workers 5 --detach
```

主机先排五个 PROP，空闲槽再排 GROUND/OFFLOAD/TUT_ADAPTED。`00_PROGRESS_CN.md` 和 `PROGRESS.json` 每 60s 更新，包含方法、种子、仿真时刻、到达/闭环、有效墙钟、CPU、内存、PID/状态。ETA 只有在经过首小时后依据观测速度给出，后续拥挤可使它变化。

每小时及 4200、9900、15600、21300s 保存账本和完整 pickle；另外每约 180 墙钟秒在下一个完成的宏槽保存恢复状态。文件位于 `种子_方法/attempt_XX/CHECKPOINTS`；快照在 `SNAPSHOTS`。检查点含温度、SOC、CPU 工作、产品、已发送字节、队列、待处理任务、控制和历史，不导入未来轨迹。恢复前核对源码、配置、输入 SHA、Python 版本和 pickle SHA，并仅复制已提交的候选日志前缀。

中断后再次执行相同 launch 命令，会识别已完成作业并从最新完整检查点创建新的 attempt；旧日志保留。程序异常写 FAILED 的作业不会无限自动重跑；无 FAILED 的外部中断最多自动恢复三次。可手工指定同版本恢复点：

```powershell
python -I run.py worker --seed 4101 --arm NO_MODE --out outputs_ablation\4101_NO_MODE\attempt_manual01 --resume outputs_ablation\4101_NO_MODE\attempt_01\CHECKPOINTS\T03600.pkl
```

不要加载来源不明的 pickle。移动整个输出目录后恢复可用；候选前缀从检查点同一 attempt 回找。若失败涉及决策或物理源码修改，必须另建版本并明确重跑受影响正式比较，不混表。

## 冻结场景

种子 4101–4105；2026 仅为历史开发种子。本地可访问运行记录显式种子声明审计未发现这五个种子被使用，审计范围和不可读路径保存在 PREPARATION/SEED_AUDIT.json。

每种子从原 268 个模板按等级独立有放回重采样，配额 low322/medium830/high323/urgent125，HV448/普通1152。先抽模板，再均匀抽取 [0,20700) 到达时刻；绝对 DDL = 新到达 + 原相对期限。任务需求、价值、profile、质量和元数据保留。所有方法及消融共享同种子任务、日历和外生文件 SHA；运行阶段不抽取随候选数或缓存顺序变化的外生随机量。

业务窗口：[3600,4200]、[9300,9900]、[15000,15600]、[20700,21300]；5700s 间隔、600s 时长不变。使用完整参考业务日历源起点 2520s（第126个20s槽），所有速率、光照、太阳补能和吸收热使用同一源索引。原太阳记录288槽=5760s周期，与5700s业务周期不同，照实保留。不是重新计算的几何可见星历。

有效速率已按未缩放名义容量的0.50冻结，不可再乘0.50。源bundle原含0.35，生成时按0.50/0.35迁移并保留原有效率。新四窗速率约19.5001–29.0545 Mbps，时间均值24.2877 Mbps。容量采用十进制MB=8e6 bit；业务时段与有效速率不重复扣损耗。

统一初态保持原声明值（SOC=0.85，板/RF/结构15°C，芯片由原初始化推导），不按新结果调初态，也未从旧2520s轨迹取热启动。背景8.86W×21600=191376J另列，不能把任务可控能耗称整星能耗。

在线预测、实际收益和公共终态均对齐21600s。21300–21600s继续已有执行/地面处理，不新增任务；晚于21600的交付不计本周期收益。时效仍按任务原始相对期限。DDL>21600而未完成的任务属于右删失/期末未完成，不强制到期清空。Q_end只计已ready未发送完的字节，未materialize承诺另列。本版已验证ΔQ_end可非零，不能沿用旧86400终态的零积压结论。

## 方法的实际差异

|公开名称|实现与选择规则|推理质量/实际发送|
|---|---|---|
|GROUND|原B1压缩地面路径；保留contact-aware调度与full-fit规则，无LOCAL分支|32MB输入/8=4MB压缩图；地面延迟4.29s；q=0.8215028271；编码11s×1.4W|
|OFFLOAD|自身LOCAL/GROUND可行选择及延期，先比较地面完成时间|LOCAL用High、固定ROI0.85MB；GROUND发送4MB压缩图、编码11s×6.8W；q=0.8215028271|
|TUT_ADAPTED|原已验证适配策略，固定Balanced，自身产品评分与延期|q=0.697529100765；Metadata/ROI/ROI+Ctx=0.002/0.85/2.7MB；不是原论文完整复现|
|PROP|三模型/三产品，原HV required Direct否则Metadata及既有递进、初次延期|Light/Balanced/High q=0.5697178218/0.7342411587/0.8215028271；产品大小保留原元数据profile|

各方法共享物理、事件、可观察输入、安全边界和固定公共实际计分；保留基线自身选择逻辑和已声明profile差异。GROUND最终地面ROI+Ctx不是星上实际下传产品，绘图和账本明确区分。TUT仍是适配版本，不改High。

## 五消融开关

|公开名称|唯一约定差异|
|---|---|
|A NO_RESOURCE_MODULATION|动态附加价格归零，固定κ仍在，Mode价格作用随之失效|
|B NO_PROGRESSIVE_REFINEMENT|不追加部分交付后的新信息层；保留首次产品/Metadata、首次HV延期重试、已授权分包与跨窗续传|
|C FIXED_HIGH|首次只允许High；不可行可延期，不能退回Balanced；后续沿用缓存推理|
|D REQUIRED_PRODUCT_ONLY|只允许满足最终需求的产品及延期；alert仍可Metadata闭环；不改需求|
|E NO_MODE|mE=mB=1，保留基础动态压力和固定κ|

A/E存在嵌套；D还取消首次部分交付与其补全机会，不能将D/B差值当可相加的独立机制贡献。所有组共享20s宏槽、200s Mode周期、原α/κ/阈值、原物理和原递进定义，未新增Lyapunov队列或理论保证。

## 汇总、主机PROP导入与容差

主机把完整 `outputs_main`（至少每种子PROP的已完成attempt中的 IDENTITY/COMPLETED/AUDIT及RESULT）复制到消融机，执行：

```powershell
python -I run.py import-prop --from-dir copied_outputs_main --out outputs_ablation
python -I run.py summarize --out outputs_ablation
```

导入先验证源码清单、配置、输入 SHA 与审计通过，拒绝旧场景。两台机器均使用本包源版本。参考计数、到达清单、整数bit要求相同；数值比较预先声明time 1e-7s、能耗绝对1e-5J、效用绝对1e-8及相对1e-9。阈值安全判定不放宽；若跨机器漂移改变分支/计数，应报告并检查环境，不能靠增大容差使其通过。

每个RESULT包含 task_accounting.csv（每任务只计最高有效到地产品，满足需求/部分交付/右删失分开）、windows.csv、物理曲线、逐事件工作/TX/地面账本、Mode、控制耗时、候选拒绝分母与独立任务数。候选日志包含可行集、模型、评分、已知/缺失pW、ΔQ_end、拒绝原因；未计算pW不填0。截止前有窗口但没有可执行服务可能同时受ready/容量/热限制，不凭“未发”臆定一种根因。

COMPLETED_COMPARISON.csv仅含完成且审计通过者；PAIRED_DELTA.csv含与同种子PROP的差值。五种子齐全后才写FIVE_SEED_MEAN_SD.csv（样本标准差）；主实验20组齐全后才生成四子图PNG/PDF。负净效用用X标记，气泡面积对应绝对净效用，不能把负值画为正收益。桌面墙钟/CPU/内存不称星载实测开销。
